local n=MogIt.base.AddNPC
n(9056,"Fineous Darkvire")
n(58632,"Armsmaster Harlan")