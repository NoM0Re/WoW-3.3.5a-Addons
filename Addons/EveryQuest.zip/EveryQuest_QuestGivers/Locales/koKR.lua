local L = LibStub("AceLocale-3.0"):NewLocale("EveryQuest", "koKR")
if not L then return end

L[": No longer in DB"] = ": DB에 없습니다."
L["Close"] = "닫기"
L["Create waypoint"] = "웨이포인트 만들기"
L["Data Loading"] = "데이터 불러오기"
-- L["DataLoadWarning"] = ""
L["Enable: "] = "사용:"
-- L["Enables Quest Names in tooltips and category filtering"] = ""
L["Hide Quest Giver"] = "퀘스트 제공자 숨기기"
L["Icon Alpha"] = "아이콘 투명도"
L["Icon Scale"] = "아이콘 크기"
L["Icon Settings"] = "아이콘 세팅"
L["Load Data from EveryQuest database"] = "EveryQuest 데이터를 불러옵니다."
L["Query the EveryQuest database for quest names"] = "EveryQuest 데이터에서 퀘스트 제목들 쿼리하기"
L["Quest Givers"] = "퀘스트 제공자"
L["Show Quest Names in tooltip"] = "툴팁에 퀘스트 제목 표시하기"
-- L["The alpha transparency of the icons"] = ""
L["The scale of the icons"] = "아이콘의 크기"
L["These settings control the look and feel of the Quest Givers icons."] = "이 설정은 퀘스트 제공자 아이콘을 보여줍니다."
-- L["Toggle Showing of Categories"] = ""
-- L["Toggle the display of quests by quest giver based on faction availability."] = ""

