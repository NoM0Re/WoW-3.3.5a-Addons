-- [[ Cheese Options Panel ]] --

CheesePanelOptions = {
	cheeseDisplaySpellActivationOverlays = { text = "CHEESE_DISPLAY_SPELL_ALERTS", default = 1 },
	cheeseSpellActivationOverlayOpacity = { text = "CHEESE_SPELL_ALERT_OPACITY", default = 1.0, minValue = 0.1, maxValue = 1.0, valueStep = 0.05 },
}
