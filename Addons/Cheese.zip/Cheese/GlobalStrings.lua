-- AUTOMATICALLY GENERATED -- DO NOT EDIT!

CHEESE_DISPLAY_SPELL_ALERTS = "Show Spell Alerts";
CHEESE_LABEL = "Cheese";
CHEESE_SPELL_ALERT_OPACITY = "Opacity";
CHEESE_SUBTEXT = "These options affect your character's behaviors in combat, and allow you to change the way combat is displayed in the UI.";
OPTION_TOOLTIP_CHEESE_DISPLAY_SPELL_ALERTS = "Show alerts in the center of your screen when certain important events occur.";
