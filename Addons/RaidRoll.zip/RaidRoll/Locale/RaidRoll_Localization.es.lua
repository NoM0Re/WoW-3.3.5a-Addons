﻿

if (GetLocale() == "esES") then

RAIDROLL_LOCALE["10_Sec_Announce_Winner"] = "10 seg. y anunciar ganador"
RAIDROLL_LOCALE["added_to_marking_list"] = "añadido a lista de marcados."
-- RAIDROLL_LOCALE["All_marks_cleared"] = ""
RAIDROLL_LOCALE["Allow_all_rolls"] = "Cualquier rango (p.ej. 1-50)"
RAIDROLL_LOCALE["Allow_Extra_Rolls"] = "Permitir tiradas extra"
-- RAIDROLL_LOCALE["All_saved_rolls_cleared"] = ""
RAIDROLL_LOCALE["Announce_winner_to_guild"] = "Anunciar ganador a la hermandad"
RAIDROLL_LOCALE["Are_You_Sure"] = "¿Estás seguro de querer dar %s a %s?"
RAIDROLL_LOCALE["Auto_Announce_Count"] = "Auto anunciar cuenta atrás"
RAIDROLL_LOCALE["Auto_Close_Window"] = "Cerrar ventana auto."
RAIDROLL_LOCALE["Automatically_open_window_when_new_loot_is_found"] = "Abrir automáticamente la ventana al encontrar nuevo botín"
RAIDROLL_LOCALE["Awaiting Rolls"] = "Esperando tiradas"
RAIDROLL_LOCALE["Award"] = "Otorgar a %s"
RAIDROLL_LOCALE["BARTOOLTIP"] = [=[Raid Roll

Click Izquierdo para mostrar ventana
Click Derecho para mostrar opciones]=]
-- RAIDROLL_LOCALE["Cancel"] = ""
RAIDROLL_LOCALE["Catch_Unannounced_Rolls"] = "Capturar tiradas sin anunciar"
RAIDROLL_LOCALE["Clear"] = "Limpiar"
-- RAIDROLL_LOCALE["Clear_all_marks"] = ""
-- RAIDROLL_LOCALE["Clear_all_saved_roll_memory"] = ""
-- RAIDROLL_LOCALE["Clear_Data"] = ""
RAIDROLL_LOCALE["Clear_Marks"] = "Quitar marcas"
RAIDROLL_LOCALE["Clear_Rolls"] = "Limpiar tiradas"
-- RAIDROLL_LOCALE["Displaying_Loots_for"] = ""
-- RAIDROLL_LOCALE["Enable_Alt_Mode"] = ""
RAIDROLL_LOCALE["Enable_EPGP_mode"] = "Activar modo EPGP"
RAIDROLL_LOCALE["Enable_threshold_levels"] = "Activar umbrales"
-- RAIDROLL_LOCALE["Everyone_is_here"] = ""
RAIDROLL_LOCALE["Finish_Early"] = "Forzar fin"
RAIDROLL_LOCALE["Finishing_Rolling_Early"] = "Forzando fin de tirada"
RAIDROLL_LOCALE["General_Settings"] = "Ajustes generales"
RAIDROLL_LOCALE["Give_Higher_Ranks_Priority"] = "Dar prioridad a los Rangos mayores"
-- RAIDROLL_LOCALE["Give_to"] = ""
RAIDROLL_LOCALE["Guild_Rank"] = "Rango de Gremio"
RAIDROLL_LOCALE["HELP1"] = "|cFFC41F3BRaid Roll - Comandos:"
RAIDROLL_LOCALE["HELP10"] = " |cFFFFF569/rr enable - Permite seguimiento"
RAIDROLL_LOCALE["HELP11"] = "|cFFFFF569/rr mark [Nombre o IDTirador*] - Marca al tirador con un !"
RAIDROLL_LOCALE["HELP12"] = "|cFFFFF569/rr unmark [Nombre o IDTirador*] - Elimina el ! del tirador"
RAIDROLL_LOCALE["HELP13"] = "|cFFFFF569*IDTirador es el número junto al nombre del tirador en la ventana que se muestra actualmente"
RAIDROLL_LOCALE["HELP2"] = "|cFF2459FF(Realizando tirada de banda)"
RAIDROLL_LOCALE["HELP3"] = " |cFF69CCF0/rr - Realiza una tirada de banda"
RAIDROLL_LOCALE["HELP4"] = "|cFF69CCF0/rr [Enlace Objeto] - Realiza una tirada de banda (Incluye enlace al objeto cuando se anuncia el ganador)"
RAIDROLL_LOCALE["HELP5"] = "|cFF69CCF0/rr re - Repite la tirada"
RAIDROLL_LOCALE["HELP6"] = "|cFF69CCF0/rr re [Enlace Objeto] - Repite la tirada (Incluye enlace al objeto cuando se anuncia el ganador)"
RAIDROLL_LOCALE["HELP7"] = " |cFFFF7D0A(Siguiendo tiradas)"
RAIDROLL_LOCALE["HELP8"] = " |cFFFFF569/rr show - Muestra la ventana de seguimiento de tiradas"
RAIDROLL_LOCALE["HELP9"] = "|cFFFFF569/rr disable - Desactiva el seguimiento"
-- RAIDROLL_LOCALE["ID_Name"] = ""
-- RAIDROLL_LOCALE["item_not_found"] = ""
-- RAIDROLL_LOCALE["Link_Loot"] = ""
-- RAIDROLL_LOCALE["Looter_Name"] = ""
-- RAIDROLL_LOCALE["Loots"] = ""
-- RAIDROLL_LOCALE["Mark"] = ""
RAIDROLL_LOCALE["Marking_list_cleared"] = "Lista de marcados limpiada!"
-- RAIDROLL_LOCALE["Mark_Them"] = ""
-- RAIDROLL_LOCALE["Mob"] = ""
-- RAIDROLL_LOCALE["Multiroll_by"] = ""
-- RAIDROLL_LOCALE["Multi_Rollers"] = ""
RAIDROLL_LOCALE["New_ID"] = "Nueva"
-- RAIDROLL_LOCALE["No"] = ""
RAIDROLL_LOCALE["No_countdown"] = "Sin cuenta atrás"
RAIDROLL_LOCALE["No_Item"] = "No hay Objeto"
-- RAIDROLL_LOCALE["Not_in_Guild"] = ""
-- RAIDROLL_LOCALE["Not_Sure"] = ""
RAIDROLL_LOCALE["No_Winner"] = "No hay Ganador"
RAIDROLL_LOCALE["No_winner_for"] = "No hay ganador para %s."
-- RAIDROLL_LOCALE["Number not required"] = ""
RAIDROLL_LOCALE["Options"] = "Opciones"
RAIDROLL_LOCALE["OPTIONSTITLE"] = "Musou's Raid Roll - Menú de opciones"
-- RAIDROLL_LOCALE["Players_28_yd_from_me"] = ""
-- RAIDROLL_LOCALE["Players_in_another_zone"] = ""
-- RAIDROLL_LOCALE["Possibly"] = ""
RAIDROLL_LOCALE["Priorities"] = "Dar mayor prioridad a:"
-- RAIDROLL_LOCALE["Priority"] = ""
RAIDROLL_LOCALE["RaidRoll_AnnounceWinnerButton"] = "Anunciar ganador"
RAIDROLL_LOCALE["RaidRollCheckBox_ExtraRolls_panel"] = [=[Esto permite seguir tiradas múltiples
realizadas por la gente.
(Las tiradas extra se colorean en azul)

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["RaidRollCheckBox_ShowRanks_panel"] = [=[Mostrar el rango de hermandad del jugador
junto a su nombre

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["Raid_Roll_Display_Settings"] = "Mostrar ajustes"
RAIDROLL_LOCALE["Raid_Roll_EPGP_Settings"] = "Ajustes de EPGP"
-- RAIDROLL_LOCALE["Raid_Rolling"] = ""
-- RAIDROLL_LOCALE["Raid_Rolling_for"] = ""
-- RAIDROLL_LOCALE["Raid_Roll_Misc_Settings"] = ""
RAIDROLL_LOCALE["Receive_loot_messages_from_guild"] = "Recibir mensajes de botín de la hermandad (se recomienda desactivarlo)"
RAIDROLL_LOCALE["removed_from_marking_list"] = "eliminado de lista de marcados."
-- RAIDROLL_LOCALE["Re_Rolling"] = ""
-- RAIDROLL_LOCALE["Re_Rolling_for"] = ""
RAIDROLL_LOCALE["Rolling_Ends_in_10_Sec"] = "La tirada termina en 10 segundos"
RAIDROLL_LOCALE["Rolling_Ends_in_5_Sec"] = "La tirada termina en 5 segundos"
-- RAIDROLL_LOCALE["RR_Enable3Messages"] = ""
-- RAIDROLL_LOCALE["RR_Frame_WotLK_Dung_Only"] = ""
RAIDROLL_LOCALE["RR_Loot_LinkLootButton"] = "Enseñar botín de jefe a la banda"
RAIDROLL_LOCALE["RR_RollCheckBox_AllRolls_panel"] = [=[Mostrará todas las tradas al activarlo.
Si se desactiva sólo muestra del 1-100.

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["RR_RollCheckBox_Auto_Announce"] = [=[Esto anunciará automáticamente cuando
quedan 10 y 5 segundos en el contador
y anunciará el ganador al terminar.

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["RR_RollCheckBox_Auto_Close"] = [=[Esto cierra la ventana automáticamente
cuando entregas el botín a un jugador.

Recomendado: Desactivado]=]
-- RAIDROLL_LOCALE["RR_RollCheckBox_Enable_Alt_Mode"] = ""
RAIDROLL_LOCALE["RR_RollCheckBox_EPGPMode_panel"] = [=[Usa el valor de PR de una persona en
lugar de su tirada para hallar al ganador.
(Para hermandades que usen el EPGP)

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["RR_RollCheckBox_EPGPThreshold_panel"] = [=[Dar a los jugadores con valores de PR
menores al umbral prioridad más baja.
(Los jugadores por encima del umbral
ganan siempre)

Recomendado: Activado]=]
RAIDROLL_LOCALE["RR_RollCheckBox_GuildAnnounce"] = [=[Anuncia el ganador en el chat de
hermandad. 
(Aún anunciará a la banda)

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["RR_RollCheckBox_GuildAnnounce_Officer"] = [=[Usar canal de oficiales en lugar del canal
de hermandad.

Recomendado: Desactivado]=]
-- RAIDROLL_LOCALE["RR_RollCheckBox_Multi_Rollers"] = ""
RAIDROLL_LOCALE["RR_RollCheckBox_No_countdown"] = [=[Elimina la cuenta atrás de 10 segundos cuando
pulsas finalizar tirada.

Recomendado: Desactivado]=]
-- RAIDROLL_LOCALE["RR_RollCheckBox_Num_Not_Req"] = ""
RAIDROLL_LOCALE["RR_RollCheckBox_ShowClassColors_panel"] = [=[Colorear el nombre del tirador con su color
de clase.
(p.ej. Chamán - azul, Paladín - rosa)

Recomendado: Activado]=]
RAIDROLL_LOCALE["RR_RollCheckBox_ShowGroupNumber_panel"] = [=[Mostrar el número de grupo del jugador
junto a su nombre.

Recomendado: Desactivado]=]
-- RAIDROLL_LOCALE["RR_RollCheckBox_Track_Bids"] = ""
-- RAIDROLL_LOCALE["RR_RollCheckBox_Track_EPGPSays"] = ""
RAIDROLL_LOCALE["RR_RollCheckBox_Unannounced_panel"] = [=[Te permite seguir incluso las tiradas
realizadas sin previo anuncio de 
Roll [objeto].

Recomendado: Desactivado]=]
RAIDROLL_LOCALE["RR_Roll_RollButton"] = "Lanzar dados 1-100"
-- RAIDROLL_LOCALE["RR_WotLK_Dung_Only"] = ""
RAIDROLL_LOCALE["Set_Extra_Rank_Width"] = "Aumentar ancho de Rango"
RAIDROLL_LOCALE["Set_Msg1"] = "Definir Mensaje1"
RAIDROLL_LOCALE["Set_Msg2"] = "Definir Mensaje2"
-- RAIDROLL_LOCALE["Set_Msg3"] = ""
RAIDROLL_LOCALE["Set_Rolling_Time"] = "Duración de la tirada"
RAIDROLL_LOCALE["Set_Scale"] = "Tamaño de ventana de tiradas"
RAIDROLL_LOCALE["Show_Class_Colors"] = "Mostrar colores de Clase"
RAIDROLL_LOCALE["Show_Group_Beside_Name"] = "Mostrar Nº de Grupo"
RAIDROLL_LOCALE["Show_Rank_Beside_Name"] = "Mostrar Rango junto al nombre"
-- RAIDROLL_LOCALE["Track_Bids"] = ""
-- RAIDROLL_LOCALE["Track_EPGPSays"] = ""
RAIDROLL_LOCALE["Use_Item_Brackets"] = "Usar [item] para anunciar el objeto (p.ej. Dados para [item] primera espec.)"
RAIDROLL_LOCALE["Use_officer_channel"] = "Usar canal de oficiales"
-- RAIDROLL_LOCALE["Wins"] = ""
RAIDROLL_LOCALE["won_item_PR_value"] = "%s ha ganado %s. Valor PR: %s"
RAIDROLL_LOCALE["won_item_with"] = "%s ha ganado %s con %s."
RAIDROLL_LOCALE["won_PR_value"] = "%s ha ganado. Valor PR: %s"
RAIDROLL_LOCALE["won_with"] = "%s ha ganado con %s"
-- RAIDROLL_LOCALE["Yes"] = ""


end 