local LSM = LibStub('LibSharedMedia-3.0')

if LSM == nil then return end

LSM:Register("background", "AbsorbOverlay", [[Interface\AddOns\ElvUI_ProjectZidras\Media\Textures\RaidFrame\Shield-Overlay]])