local addon, MUI_t = ...

local format = string.format
local select = select
local StopMusic = StopMusic
local _G = _G

local MyPluginName = "|cfffc9803MerfinUI|r"

local E, L, V, P, G = unpack(ElvUI)
MUI_t[1] = E 
MUI_t[2] = L 
MUI_t[3] = V 
MUI_t[4] = P 
MUI_t[5] = G 
_G[addon] = MUI_t

local EP = LibStub("LibElvUIPlugin-1.0")
local MUI = E:NewModule(MyPluginName, "AceHook-3.0", "AceEvent-3.0", "AceTimer-3.0");

P[MyPluginName] = {}

function MUI:Initialize()
	if E.private.install_complete and E.db[MyPluginName].install_version == nil then
		E:GetModule("PluginInstaller"):Queue(MUI_t.InstallerData)
	end

	EP:RegisterPlugin(addon, MUI_t.InsertOptions)
end

E:RegisterModule(MUI:GetName())