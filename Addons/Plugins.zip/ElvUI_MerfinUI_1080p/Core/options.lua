local MUI_t = select(2, ...)
local E, L, V, P, G = unpack(ElvUI)
local MyPluginName = "|cff66ccffMerfinUI|r"

function MUI_t:InsertOptions()
	E.Options.args.MyPluginName = {
		order = 100,
		type = "group",
		name = format("|cff66ccff%s|r", MyPluginName),
		args = {
			header1 = {
				order = 1,
				type = "header",
				name = MyPluginName,
			},
			description1 = {
				order = 2,
				type = "description",
				name = format("%s is a bunch of AddOns profiles, that helps you to Install a whole UI in few clicks without need to deal with SavedVariables folders and Import Codes. It contains settings for such AddOns as ElvUI, WeakAuras, Details, Skada etc.", MyPluginName),
			},
			spacer1 = {
				order = 3,
				type = "description",
				name = "\n",
			},
			header2 = {
				order = 4,
				type = "header",
				name = "Installation",
			},
			description2 = {
				order = 5,
				type = "description",
				name = "The installation guide should pop up automatically after you have completed the ElvUI installation. If you wish to re-run the installation process for this layout then please click the button below.",
			},
			spacer2 = {
				order = 6,
				type = "description",
				name = "",
			},
			install = {
				order = 7,
				type = "execute",
				name = "Install",
				desc = "Run the installation process.",
				func = function() E:GetModule("PluginInstaller"):Queue(MUI_t.InstallerData); E:ToggleOptionsUI(); end,
			},
		},
	}
end