local addon, MUI_t = ...
local E, L, V, P, G = unpack(ElvUI)
local MyPluginName = "|cfffc9803MerfinUI|r"
local Version = GetAddOnMetadata(addon, "Version")

local ReloadUI = ReloadUI
local format = string.format
local StopMusic = StopMusic

function MUI_t:PluginInstallStepComplete(plugin)
	PluginInstallStepComplete:Hide()
    PluginInstallStepComplete.message = string.format("%s Installed!", plugin)
    PluginInstallStepComplete:Show()
end

function MUI_t:InstallComplete()
	if GetCVarBool("Sound_EnableMusic") then
		StopMusic()
	end

	E.db[MyPluginName].install_version = Version
	ReloadUI()
end

MUI_t.InstallerData = {
	Title = format("|cff4beb2c%s %s|r", MyPluginName, "Installation"),
	Name = MyPluginName,
	tutorialImage = "Interface\\AddOns\\ElvUI_MerfinUI_1080p\\Media\\Textures\\logo.tga",
	--tutorialImage = "Interface\\AddOns\\ElvUI_MerfinUI\\Media\\Textures\\logo2.blp",

	Pages = {
		[1] = function()
			PluginInstallFrame.SubTitle:SetFormattedText("Welcome to the installation for %s.", MyPluginName.." "..Version)
			PluginInstallFrame.Desc1:SetText("This is installer that contains profiles for various addons of MerfinUI.")
			PluginInstallFrame.Desc2:SetText("Before you start the installation process i highly recommend you to make a backup of your current WTF folder to save your current settings just in case.")
			PluginInstallFrame.Desc3:SetText("Don't forget to click on Finished on last step, that would reload your UI and all the settings will be applied. Some of the settings such as CombatText new font are applied after game-restart.")
			PluginInstallFrame.Desc4:SetText('WeakAuras are not included in this pack so you need to import them yourself. Auras that are used in this ui are marked with "MerfinUI" on pastebins.')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", MUI_t.InstallComplete)
			PluginInstallFrame.Option1:SetText("Skip Process")
		end,

		[2] = function()
			PluginInstallFrame.SubTitle:SetText("AddOns Check")
			PluginInstallFrame.Desc1:SetText("Checking if you've downloaded and enabled all the AddOns that are needed to bring all functionalities of the UI.")
			PluginInstallFrame.Desc2:SetText(MUI_t:CheckEnabledAddOns())
			PluginInstallFrame.Desc3:SetText("By clicking on Check you can enable all AddOns if it's needed. It will also reload your UI. If you have everything enabled, press Continue")
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:EnableAllAdons() end)
			PluginInstallFrame.Option1:SetText("Enable AddOns")
		end,

		[3] = function()
			PluginInstallFrame.SubTitle:SetText("Account Settings")
			PluginInstallFrame.Desc1:SetText("The World of Warcraft game client stores all of its configurations in console variables (CVars). These variables affect many aspects of the game, such as the graphics, the sound system and the interface. ")
			PluginInstallFrame.Desc2:SetText("Click on Load to change variables located inside Config.wtf for MerfinUI")
			PluginInstallFrame.Desc3:SetText('Importance: |cff4beb2cOptional|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:Set_CVars() end)
			PluginInstallFrame.Option1:SetText("Load CVars")
		end,

		[4] = function()
			PluginInstallFrame.SubTitle:SetText("Chat Settings")
			PluginInstallFrame.Desc1:SetText("This will setup chat windows to look like this:\n\nGNL - CL - LT - GLD - /W - GLB.\nKeep in mind that you'll need to manually set Global channel in GLB chat window settings by right clicking on it.")
			PluginInstallFrame.Desc2:SetText('Importance: |cff4beb2cOptional|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:SetupChat() end)
			PluginInstallFrame.Option1:SetText("Setup Chat")
		end,

		[5] = function()
			PluginInstallFrame.SubTitle:SetText("ElvUI")
			PluginInstallFrame.Desc1:SetText("These are the layouts that are available. Please click a button below to apply the layout of your choosing.")
			PluginInstallFrame.Desc2:SetText("You must have these plugins downloaded and enabled:\nAddOnSkins, Enhanced, Enhanced Friends List, CustomTweaks, Custom Tags, DataText Colors, Datatext Bar 2.")
			PluginInstallFrame.Desc3:SetText('Importance: |cff4beb2cHigh|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:ImportElvUI("DPS") end)
			PluginInstallFrame.Option1:SetText("DPS")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI_t:ImportElvUI("Tank") end)
			PluginInstallFrame.Option2:SetText("Tank")
			PluginInstallFrame.Option3:Show()
			PluginInstallFrame.Option3:SetScript("OnClick", function() MUI_t:ImportElvUI("Healer") end)
			PluginInstallFrame.Option3:SetText("Heal")
		end,

		[6] = function()
			PluginInstallFrame.SubTitle:SetText("Color Theme (ElvUI)")
			PluginInstallFrame.Desc1:SetText("This setting would apply colors for all unit frames")
			PluginInstallFrame.Desc2:SetText('Importance: |cff4beb2cMedium|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:SetElvTheme("NORMAL") end)
			PluginInstallFrame.Option1:SetText("Normal Theme")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI_t:SetElvTheme("DARK") end)
			PluginInstallFrame.Option2:SetText("Dark Theme")
		end,

		[7] = function()
			PluginInstallFrame.SubTitle:SetText("Action Bars (ElvUI)")
			PluginInstallFrame.Desc1:SetText("Action Bars display options. Mine are: 'Show on Mouseover' and 'Show Empty Buttons'. You can pick what you prefer the most.")
			PluginInstallFrame.Desc2:SetText('Importance: |cff4beb2cMedium|r')

			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:ABMouseover(false) end)
			PluginInstallFrame.Option1:SetText("Show Always")

			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI_t:ABMouseover(true) end)
			PluginInstallFrame.Option2:SetText("Show Mouseover")
		end,

		[8] = function()
			PluginInstallFrame.SubTitle:SetText("Damage Meter (Skada)")
			PluginInstallFrame.Desc1:SetText("Click on the button to adjust Skada settings.")
			PluginInstallFrame.Desc3:SetText('Importance: |cff4beb2cHigh|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:ImportSkada('NORMAL THEME') end)
			PluginInstallFrame.Option1:SetText("Normal Theme")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI_t:ImportSkada('DARK THEME') end)
			PluginInstallFrame.Option2:SetText("Dark Theme")
		end,

		[9] = function()
			PluginInstallFrame.SubTitle:SetText("Boss Mods (DBM)")
			PluginInstallFrame.Desc1:SetText("Click on the button to adjust DBM settings.")
			PluginInstallFrame.Desc2:SetText('Importance: |cff4beb2cHigh|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:ImportDBM("DPS/Tank") end)
			PluginInstallFrame.Option1:SetText("DPS/Tank")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI_t:ImportDBM("Healer") end)
			PluginInstallFrame.Option2:SetText("Healer")
		end,

		[10] = function()
			PluginInstallFrame.SubTitle:SetText("Combat Text (xCT+)")
			PluginInstallFrame.Desc1:SetText("Click on the button to adjust xCT+ frame offsets and settings depending on ElvUI profile you use.")
			PluginInstallFrame.Desc2:SetText('Importance: |cff4beb2cHigh|r')
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI_t:Import_xCT("DPS") end)
			PluginInstallFrame.Option1:SetText("DPS")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI_t:Import_xCT("Tank") end)
			PluginInstallFrame.Option2:SetText("Tank")
			PluginInstallFrame.Option3:Show()
			PluginInstallFrame.Option3:SetScript("OnClick", function() MUI_t:Import_xCT("Healer") end)
			PluginInstallFrame.Option3:SetText("Healer")
		end,

		[11] = function()
			PluginInstallFrame.SubTitle:SetText("Installation Complete")
			PluginInstallFrame.Desc1:SetText("You have completed the installation process.")
			PluginInstallFrame.Desc2:SetText("You must click the button below in order to finalize the process and automatically reload your UI.")
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", MUI_t.InstallComplete)
			PluginInstallFrame.Option1:SetText("Finished")
		end
	},

	StepTitles = {
		[1] = "Welcome",
		[2] = "AddOns Check",
		[3] = "Account Settings",
		[4] = "Chat Settings",
		[5] = "ElvUI",
		[6] = "Color Theme (ElvUI)",
		[7] = "Action Bars (ElvUI)",
		[8] = "Damage Meter (Skada)",
		[9] = "Boss Mods (DBM)",
		[10] = "Combat Text (xCT+)",
		[11] = "Installation Complete"
	},

	StepTitlesColor = {1, 1, 1},
	StepTitlesColorSelected = {0, 179/255, 1},
	StepTitleWidth = 200,
	StepTitleButtonWidth = 180,
	StepTitleTextJustification = "RIGHT",
}