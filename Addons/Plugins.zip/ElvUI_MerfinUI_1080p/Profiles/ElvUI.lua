local addon, MUI_t = ...
local E, L, V, P, G = unpack(ElvUI)
local class = select(2, UnitClass("player"))

local function LoadFilters()
    -- Aura Filters
    E.global["unitframe"]["aurafilters"] = E.global["unitframe"]["aurafilters"] or {}


    E.global["unitframe"]["aurafilters"]["Ulduar_RaidDebuffs"] = {
        ["type"] = "Whitelist",
        ["spells"] = {
            [63477] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62469] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63493] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64386] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64771] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62997] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64529] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64152] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64156] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64668] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63549] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62283] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62418] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62930] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62680] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62438] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [65121] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62331] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62589] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63355] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62470] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64125] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64637] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [65026] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [61990] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64153] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64157] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63018] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63276] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62526] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63673] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63169] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [61903] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62042] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62451] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62717] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62602] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63134] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63138] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64412] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62130] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [61888] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62928] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63571] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62055] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64375] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [61969] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64234] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63476] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63322] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64374] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63615] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62039] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62861] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62865] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64126] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62269] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64666] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63472] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63802] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64667] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63147] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63024] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64290] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63612] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64292] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62532] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63042] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63490] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63494] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62548] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64002] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63666] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [63830] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [62310] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [61912] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["VoA_RaidDebuffs"] = {
        ["spells"] = {
            [72004] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67332] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72121] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66684] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72098] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72120] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["TurtleBuffs"] = {
        ["spells"] = {
            [20236] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70654] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70725] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Soulstone Resurrection"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71635] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [19752] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [22842] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [1038] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [2565] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70845] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [64205] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [47891] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [53271] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [12975] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70940] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71586] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Earth Shield"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [1044] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70760] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Innervate"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71638] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["Blacklist"] = {
        ["spells"] = {
            ["Evasion"] = {
                ["enable"] = true,
                ["priority"] = 0,
            },
            ["Quel'Delar's Complusion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Teleport"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Ooze Variable"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Heartbroken"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Frost Aura"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Fury of Frostmourne"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Choking Gas"] = {
                ["enable"] = false,
            },
            [22790] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Harvest Soul"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Malleable Goo"] = {
                ["enable"] = false,
            },
            ["Gas Variable"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Harvest Souls"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Whiteout"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [25771] = {
                ["enable"] = false,
            },
            [42859] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Raise Dead"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Enraged Regeneration"] = {
                ["enable"] = true,
                ["priority"] = 0,
            },
            ["Plague Sickness"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Chill of the Throne"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["ToGC_RaidDebuffs"] = {
        ["spells"] = {
            [67610] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67618] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66237] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67650] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67309] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67071] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66333] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67611] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68127] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67635] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67651] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66770] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66532] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67310] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66683] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67072] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66199] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66334] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67620] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67636] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67652] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66406] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67049] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67311] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67700] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66819] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66335] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68510] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67637] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67050] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67312] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67574] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [65812] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66963] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67479] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68154] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67654] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67297] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67051] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67059] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66821] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66964] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68123] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66869] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66877] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68155] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67655] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67282] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67298] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67060] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66965] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66211] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68124] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68156] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67656] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67283] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66283] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66242] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67061] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66197] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66823] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67847] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66331] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67863] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68125] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67477] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66689] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66336] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67619] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66209] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68128] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67478] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68509] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68126] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66013] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67070] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67609] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67721] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [66012] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
        ["type"] = "Whitelist",
    }

    E.global["unitframe"]["aurafilters"]["CCDebuffs"] = {
        ["spells"] = {
            [53227] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Demoralizing Roar"] = {
                ["enable"] = false,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["BLACKLIST: Debuff Indicators"] = {
        ["type"] = "Blacklist",
        ["spells"] = {
            ["Burning Bile"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Frost Beacon"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mutated Plague"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Touch of Light"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Impaled"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Blazing Aura"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Searing Light"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Nature's Fury"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Frostbite"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Plasma Blast"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Dark Reckoning"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mutated Infection"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Iron Roots"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Malady of the Mind"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Incinerate Flesh"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of Consumption"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Inevitable Doom"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of Combustion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Chill"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Combobulating Spray"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Unbalancing Strike"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Necrotic Plague"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Ice Tomb"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Pact of the Darkfallen"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Gaseous Bloat"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mutating Injection"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Gravity Bomb"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Swarming Shadows"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Static Disruption"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Touch of Darkness"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Penetrating Cold"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Legion Flame"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Fiery Combustion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Arcane Breath"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Web Wrap"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Napalm Shell"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Dominate Mind"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of the Faceless"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Locust Swarm"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Rune of Blood"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Impale"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mortal Wound"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Overwhelming Power"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Poison Bolt Volley"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Boiling Blood"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Pursued by Anub'arak"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Soul Reaper"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Arctic Breath"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Wounding Strike"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Curse of Torpor"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Twin Spike"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Soul Shriek"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Volatile Ooze Adhesive"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Asphyxiation"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Soul Consumption"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Rune Detonation"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Flame Beacon"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Gas Spore"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of the Fallen Champion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Uncontrollable Frenzy"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["Debuff Indicators"] = {
        ["type"] = "Whitelist",
        ["spells"] = {
            ["Soul Shriek"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Frost Beacon"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mutated Plague"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Chill"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Touch of Light"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Nature's Fury"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Impaled"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Necrotic Plague"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Malady of the Mind"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Burning Bile"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Frostbite"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Rune Detonation"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Iron Roots"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mutated Infection"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Flame Beacon"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Combobulating Spray"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Incinerate Flesh"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of Consumption"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Searing Light"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of Combustion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Dark Reckoning"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Unbalancing Strike"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Plasma Blast"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Blazing Aura"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Ice Tomb"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mortal Wound"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Gaseous Bloat"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mutating Injection"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Napalm Shell"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Swarming Shadows"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Static Disruption"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Touch of Darkness"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Penetrating Cold"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Dominate Mind"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Fiery Combustion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Arcane Breath"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Web Wrap"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Gravity Bomb"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Legion Flame"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of the Faceless"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Locust Swarm"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Impale"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Decrepit Fever"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Soul Reaper"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Overwhelming Power"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Poison Bolt Volley"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Boiling Blood"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Pursued by Anub'arak"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Arctic Breath"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Twin Spike"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Wounding Strike"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Curse of Torpor"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Inevitable Doom"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Pact of the Darkfallen"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Volatile Ooze Adhesive"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Asphyxiation"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Soul Consumption"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Frost Blast"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Rune of Blood"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Gas Spore"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mark of the Fallen Champion"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Uncontrollable Frenzy"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["RS_RaidDebuffs"] = {
        ["type"] = "Whitelist",
        ["spells"] = {
            [74367] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [74567] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [74452] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [74502] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [74562] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["EoE_RaidDebuffs"] = {
        ["type"] = "Whitelist",
        ["spells"] = {
            [56272] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [60072] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [57407] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [60936] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["OS_RaidDebuffs"] = {
        ["type"] = "Whitelist",
        ["spells"] = {
            [58936] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [60708] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [39647] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [57491] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["RaidDebuffs"] = {
        ["spells"] = {
            ["Blood Mirror"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Necrotic Aura"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Fungal Creep"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Fire Bomb"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Pain and Suffering"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Slime Puddle"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Web Wrap"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Permafrost"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Remorseless Winter"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Mana Detonation"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["ICC_RaidDebuffs"] = {
        ["spells"] = {
            [70871] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72449] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71222] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73788] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72274] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71525] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72832] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69278] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70346] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70872] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70633] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71733] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72769] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72833] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69279] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70873] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71941] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71208] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [27177] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73790] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72021] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69248] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69774] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71623] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70157] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71257] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72293] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71289] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71624] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70126] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70923] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69409] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72549] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69776] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72868] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71625] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72151] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71163] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72454] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71530] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72837] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72869] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71626] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70877] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72455] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70447] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71738] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72264] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72025] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68981] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69762] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72838] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72854] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71340] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70671] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70432] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73779] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72265] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72026] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72552] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72855] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71341] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70337] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72648] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70879] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70911] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70672] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72999] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73015] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72266] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72553] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72856] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70338] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72649] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72442] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72219] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70450] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73781] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72267] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72650] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72443] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70435] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72491] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [30494] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73033] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71264] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69240] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69766] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71822] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72109] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69065] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72490] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72385] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70541] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72551] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70106] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72492] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70924] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [67934] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71265] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71531] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71807] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70107] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72273] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70835] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72636] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70867] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71237] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71154] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72836] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71951] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72796] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71473] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73019] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71533] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71266] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69242] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72985] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70744] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69290] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70342] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72637] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71277] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72639] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71665] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70766] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70980] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73020] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71474] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70215] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71127] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72797] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71283] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71268] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72798] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72272] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72638] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73913] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71532] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71204] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69651] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71089] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72890] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70949] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72635] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73786] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72017] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69483] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70341] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71267] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73785] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71218] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70838] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73914] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70751] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72022] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73912] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [69778] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73034] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70950] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71221] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73787] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72018] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72133] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73780] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [73789] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72441] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [70823] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [68980] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [72640] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [71911] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
        ["type"] = "Whitelist",
    }

    E.global["unitframe"]["aurafilters"]["BLACKLIST: Raid Debuffs"] = {
        ["type"] = "Blacklist",
        ["spells"] = {
            ["Power of Tenebron"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Profound Darkness"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Sanity"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Power of Shadron"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Rune of Power"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Aura of Despair"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            ["Power of Vesperon"] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
    }

    E.global["unitframe"]["aurafilters"]["Naxx_RaidDebuffs"] = {
        ["spells"] = {
            [28679] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29310] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54835] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55593] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54022] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28622] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28059] = {
                ["enable"] = false,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [27808] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54099] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55550] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55052] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55314] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [27819] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54121] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28832] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28833] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29212] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29213] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29214] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28522] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54836] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28084] = {
                ["enable"] = false,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28085] = {
                ["enable"] = false,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55665] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55604] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28835] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54098] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28786] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28834] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28410] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55011] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55053] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29232] = {
                ["enable"] = false,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28062] = {
                ["enable"] = false,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29865] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28542] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [54378] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28796] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29204] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28776] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28169] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [28794] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29998] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [29306] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [55645] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
            [27825] = {
                ["enable"] = true,
                ["priority"] = 0,
                ["stackThreshold"] = 0,
            },
        },
        ["type"] = "Whitelist",
    }


    E.global["unitframe"]["buffwatch"] = E.global["unitframe"]["buffwatch"] or {}

    E.global["unitframe"]["buffwatch"]["PALADIN"] = {
        [6940] = {
            ["enabled"] = false,
            ["sizeOverride"] = 13,
            ["point"] = "BOTTOMLEFT",
            ["style"] = "texturedIcon",
            ["yOffset"] = -2,
        },
        [10278] = {
            ["enabled"] = false,
            ["sizeOverride"] = 13,
            ["point"] = "BOTTOMLEFT",
            ["style"] = "texturedIcon",
            ["yOffset"] = -2,
        },
        [48066] = {
            ["enabled"] = true,
            ["anyUnit"] = true,
            ["point"] = "TOP",
            ["xOffset"] = 0,
            ["yOffset"] = 0,
            ["style"] = "texturedIcon",
            ["id"] = 48066,
            ["color"] = {
                ["r"] = 1,
                ["g"] = 0,
                ["b"] = 0,
            },
            ["sizeOverride"] = 10,
            ["onlyShowMissing"] = false,
        },
        [1038] = {
            ["enabled"] = false,
            ["sizeOverride"] = 13,
            ["point"] = "BOTTOMLEFT",
            ["style"] = "texturedIcon",
            ["yOffset"] = -2,
        },
        [1044] = {
            ["enabled"] = false,
            ["sizeOverride"] = 13,
            ["point"] = "BOTTOMLEFT",
            ["style"] = "texturedIcon",
            ["yOffset"] = -3,
        },
        [53563] = {
            ["anyUnit"] = false,
            ["style"] = "texturedIcon",
            ["point"] = "BOTTOMLEFT",
            ["color"] = {
                ["r"] = 1,
                ["g"] = 0,
                ["b"] = 0,
            },
            ["sizeOverride"] = 17,
            ["decimalThreshold"] = -1,
        },
        [53601] = {
            ["sizeOverride"] = 17,
            ["point"] = "TOPLEFT",
            ["decimalThreshold"] = -1,
            ["anyUnit"] = false,
            ["style"] = "texturedIcon",
            ["onlyShowMissing"] = false,
        },
    }

    E.global["unitframe"]["buffwatch"]["MAGE"] = {
        [54646] = {
            ["sizeOverride"] = 15,
            ["point"] = "TOPLEFT",
            ["style"] = "texturedIcon",
            ["onlyShowMissing"] = false,
        },
        [48066] = {
            ["enabled"] = true,
            ["sizeOverride"] = 10,
            ["point"] = "TOP",
            ["xOffset"] = 0,
            ["yOffset"] = 0,
            ["style"] = "texturedIcon",
            ["id"] = 48066,
            ["color"] = {
                ["r"] = 1,
                ["g"] = 0,
                ["b"] = 0,
            },
            ["anyUnit"] = true,
            ["onlyShowMissing"] = false,
        },
    }

    E.global["unitframe"]["buffwatch"]["PRIEST"] = {
        [10060] = {
            ["enabled"] = false,
        },
        [48111] = {
            ["sizeOverride"] = 17,
            ["style"] = "texturedIcon",
            ["point"] = "TOPLEFT",
            ["xOffset"] = 18,
            ["decimalThreshold"] = -1,
        },
        [6788] = {
            ["sizeOverride"] = 13,
            ["point"] = "TOP",
            ["style"] = "texturedIcon",
        },
        [48066] = {
            ["anyUnit"] = false,
            ["point"] = "TOPLEFT",
            ["color"] = {
                ["b"] = 0,
                ["g"] = 0,
                ["r"] = 1,
            },
            ["sizeOverride"] = 17,
            ["style"] = "texturedIcon",
            ["onlyShowMissing"] = false,
        },
        [48068] = {
            ["sizeOverride"] = 17,
            ["style"] = "texturedIcon",
            ["decimalThreshold"] = -1,
        },
    }

    E.global["unitframe"]["buffwatch"]["WARLOCK"] = {
        [47883] = {
            ["enabled"] = true,
            ["anyUnit"] = true,
            ["point"] = "TOPLEFT",
            ["xOffset"] = 0,
            ["displayText"] = false,
            ["textThreshold"] = -1,
            ["yOffset"] = 0,
            ["style"] = "texturedIcon",
            ["sizeOverride"] = 15,
            ["color"] = {
                ["b"] = 1,
                ["g"] = 0.41960784313725,
                ["r"] = 0,
            },
            ["id"] = 47883,
        },
        [48066] = {
            ["enabled"] = true,
            ["sizeOverride"] = 10,
            ["point"] = "TOP",
            ["xOffset"] = 0,
            ["yOffset"] = 0,
            ["style"] = "texturedIcon",
            ["id"] = 48066,
            ["color"] = {
                ["r"] = 1,
                ["g"] = 0,
                ["b"] = 0,
            },
            ["anyUnit"] = true,
            ["onlyShowMissing"] = false,
        },
    }

    E.global["unitframe"]["buffwatch"]["SHAMAN"] = {
        [61301] = {
            ["sizeOverride"] = 17,
            ["style"] = "texturedIcon",
            ["decimalThreshold"] = 1,
        },
        [48066] = {
            ["enabled"] = true,
            ["sizeOverride"] = 10,
            ["point"] = "TOP",
            ["xOffset"] = 0,
            ["yOffset"] = 0,
            ["style"] = "texturedIcon",
            ["id"] = 48066,
            ["color"] = {
                ["r"] = 1,
                ["g"] = 0,
                ["b"] = 0,
            },
            ["anyUnit"] = true,
            ["onlyShowMissing"] = false,
        },
        [52000] = {
            ["sizeOverride"] = 17,
            ["style"] = "texturedIcon",
            ["xOffset"] = 18,
            ["decimalThreshold"] = 1,
            ["point"] = "TOPLEFT",
            ["onlyShowMissing"] = false,
        },
        [16237] = {
            ["enabled"] = false,
            ["anyUnit"] = true,
            ["point"] = "TOPLEFT",
            ["xOffset"] = 19,
            ["displayText"] = true,
            ["style"] = "texturedIcon",
            ["decimalThreshold"] = 1,
            ["color"] = {
                ["r"] = 1,
                ["g"] = 0.86274509803922,
                ["b"] = 0,
            },
            ["sizeOverride"] = 15,
            ["onlyShowMissing"] = false,
        },
        [49284] = {
            ["sizeOverride"] = 17,
            ["point"] = "BOTTOMLEFT",
            ["decimalThreshold"] = 1,
            ["color"] = {
                ["r"] = 1,
                ["g"] = 1,
                ["b"] = 1,
            },
            ["anyUnit"] = false,
            ["style"] = "texturedIcon",
            ["onlyShowMissing"] = false,
        },
    }

    E.global["unitframe"]["buffwatch"]["DRUID"] = {
        [53251] = {
            ["sizeOverride"] = 15,
            ["style"] = "texturedIcon",
            ["color"] = {
                ["b"] = 0.72549019607843,
                ["g"] = 0,
                ["r"] = 1,
            },
            ["point"] = "BOTTOMLEFT",
            ["xOffset"] = 16,
            ["textColor"] = {
                ["g"] = 0.90196078431373,
                ["b"] = 0,
            },
        },
        [48451] = {
            ["sizeOverride"] = 15,
            ["style"] = "texturedIcon",
            ["decimalThreshold"] = 0,
            ["color"] = {
                ["b"] = 0,
                ["g"] = 0,
                ["r"] = 1,
            },
            ["anyUnit"] = false,
            ["textColor"] = {
                ["g"] = 0.90196078431373,
                ["b"] = 0,
            },
        },
        [48441] = {
            ["sizeOverride"] = 15,
            ["style"] = "texturedIcon",
            ["textColor"] = {
                ["g"] = 0.90196078431373,
                ["b"] = 0,
            },
            ["color"] = {
                ["b"] = 1,
                ["g"] = 0.75686274509804,
                ["r"] = 0,
            },
            ["decimalThreshold"] = -1,
            ["point"] = "BOTTOMLEFT",
            ["onlyShowMissing"] = false,
        },
        [48443] = {
            ["sizeOverride"] = 15,
            ["style"] = "texturedIcon",
            ["point"] = "TOPLEFT",
            ["xOffset"] = 16,
            ["decimalThreshold"] = -1,
            ["textColor"] = {
                ["g"] = 0.90196078431373,
                ["b"] = 0,
            },
        },
        [48066] = {
            ["enabled"] = true,
            ["anyUnit"] = true,
            ["point"] = "TOP",
            ["xOffset"] = 0,
            ["yOffset"] = 0,
            ["style"] = "texturedIcon",
            ["id"] = 48066,
            ["sizeOverride"] = 10,
            ["color"] = {
                ["b"] = 0,
                ["g"] = 0,
                ["r"] = 1,
            },
            ["onlyShowMissing"] = false,
        },
    }
end

local function LoadNameplateSettings()

    E.db["nameplates"]["threat"]["badScale"] = 1
    E.db["nameplates"]["threat"]["goodScale"] = 1
    E.db["nameplates"]["nonTargetTransparency"] = 0.45
    E.db["nameplates"]["plateSize"]["friendlyHeight"] = 17
    E.db["nameplates"]["plateSize"]["enemyHeight"] = 17
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["countFontSize"] = 10
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["durationFontSize"] = 10
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["countYOffset"] = 0
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["yOffset"] = 4
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["attachTo"] = "FRAME"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["countXOffset"] = 0
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["spacing"] = 2
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["perrow"] = 8
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["filters"]["priority"] = "Blacklist,CCDebuffs,Personal"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["debuffs"]["size"] = 19
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["height"] = 20
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["text"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["text"]["position"] = "BOTTOMRIGHT"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["text"]["enable"] = true
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["text"]["format"] = "CURRENT_PERCENT"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["text"]["xOffset"] = -2
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["text"]["yOffset"] = 15
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["enable"] = true
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["health"]["width"] = 165
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["castbar"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["castbar"]["iconSize"] = 39
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["castbar"]["textPosition"] = "ONBAR"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["castbar"]["height"] = 17
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["castbar"]["width"] = 165
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["name"]["abbrev"] = true
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["name"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["name"]["xOffset"] = 2
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["name"]["useClassColor"] = false
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["name"]["yOffset"] = -15
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["level"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["raidTargetIndicator"]["xOffset"] = 0
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["raidTargetIndicator"]["size"] = 32
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["raidTargetIndicator"]["yOffset"] = 43
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["raidTargetIndicator"]["position"] = "CENTER"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["buffs"]["countFont"] = "Arial Narrow Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["buffs"]["durationFontSize"] = 15
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["buffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_PLAYER"]["buffs"]["enable"] = false
    E.db["nameplates"]["units"]["TARGET"]["glowStyle"] = "style2"
    E.db["nameplates"]["units"]["TARGET"]["arrow"] = "Arrow11"
    E.db["nameplates"]["units"]["TARGET"]["comboPoints"]["enable"] = false
    E.db["nameplates"]["units"]["TARGET"]["arrowSize"] = 37
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["countFontSize"] = 10
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["durationFontSize"] = 10
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["countYOffset"] = 0
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["yOffset"] = 4
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["attachTo"] = "FRAME"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["countXOffset"] = 0
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["spacing"] = 2
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["perrow"] = 8
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["filters"]["priority"] = "Blacklist,CCDebuffs,Personal"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["debuffs"]["size"] = 19
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["castbar"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["castbar"]["iconSize"] = 39
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["castbar"]["textPosition"] = "ONBAR"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["castbar"]["height"] = 17
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["castbar"]["width"] = 165
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["raidTargetIndicator"]["xOffset"] = 0
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["raidTargetIndicator"]["size"] = 32
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["raidTargetIndicator"]["yOffset"] = 43
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["raidTargetIndicator"]["position"] = "CENTER"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["eliteIcon"]["xOffset"] = -11
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["eliteIcon"]["size"] = 25
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["eliteIcon"]["yOffset"] = -1
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["eliteIcon"]["position"] = "LEFT"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["enable"] = true
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["text"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["text"]["position"] = "BOTTOMRIGHT"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["text"]["enable"] = true
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["text"]["format"] = "CURRENT_PERCENT"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["text"]["xOffset"] = -2
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["text"]["yOffset"] = 15
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["height"] = 20
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["health"]["width"] = 165
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["level"]["enable"] = false
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["level"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["name"]["abbrev"] = true
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["name"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["name"]["xOffset"] = 2
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["name"]["yOffset"] = -15
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["buffs"]["countFont"] = "Arial Narrow Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["buffs"]["durationFontSize"] = 15
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["buffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["FRIENDLY_NPC"]["buffs"]["enable"] = false
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["level"]["enable"] = false
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["level"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["countFontSize"] = 10
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["durationFontSize"] = 10
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["countYOffset"] = 0
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["yOffset"] = 4
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["attachTo"] = "FRAME"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["countXOffset"] = 0
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["spacing"] = 2
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["perrow"] = 8
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["filters"]["priority"] = "Blacklist,CCDebuffs,Personal"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["debuffs"]["size"] = 19
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["name"]["abbrev"] = true
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["name"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["name"]["xOffset"] = 2
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["name"]["useClassColor"] = false
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["name"]["yOffset"] = -15
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["castbar"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["castbar"]["iconSize"] = 39
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["castbar"]["textPosition"] = "ONBAR"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["castbar"]["height"] = 17
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["castbar"]["width"] = 165
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["buffs"]["countFont"] = "Arial Narrow Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["buffs"]["durationFontSize"] = 15
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["buffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["buffs"]["enable"] = false
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["buffs"]["filters"]["maxDuration"] = 0
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["buffs"]["filters"]["priority"] = "Blacklist,blockNoDuration,Personal,TurtleBuffs"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["raidTargetIndicator"]["xOffset"] = 0
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["raidTargetIndicator"]["size"] = 32
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["raidTargetIndicator"]["yOffset"] = 43
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["raidTargetIndicator"]["position"] = "CENTER"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["height"] = 20
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["text"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["text"]["position"] = "BOTTOMRIGHT"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["text"]["enable"] = true
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["text"]["format"] = "CURRENT_PERCENT"
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["text"]["xOffset"] = -2
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["text"]["yOffset"] = 15
    E.db["nameplates"]["units"]["ENEMY_PLAYER"]["health"]["width"] = 165
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["countFontSize"] = 10
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["durationFontSize"] = 10
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["countYOffset"] = 0
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["yOffset"] = 4
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["attachTo"] = "FRAME"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["countXOffset"] = 0
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["spacing"] = 2
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["perrow"] = 8
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["filters"]["priority"] = "Blacklist,CCDebuffs,Personal"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["debuffs"]["size"] = 19
    E.db["nameplates"]["units"]["ENEMY_NPC"]["castbar"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["castbar"]["iconSize"] = 39
    E.db["nameplates"]["units"]["ENEMY_NPC"]["castbar"]["textPosition"] = "ONBAR"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["castbar"]["height"] = 17
    E.db["nameplates"]["units"]["ENEMY_NPC"]["castbar"]["width"] = 165
    E.db["nameplates"]["units"]["ENEMY_NPC"]["raidTargetIndicator"]["xOffset"] = 0
    E.db["nameplates"]["units"]["ENEMY_NPC"]["raidTargetIndicator"]["position"] = "CENTER"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["raidTargetIndicator"]["size"] = 32
    E.db["nameplates"]["units"]["ENEMY_NPC"]["raidTargetIndicator"]["yOffset"] = 43
    E.db["nameplates"]["units"]["ENEMY_NPC"]["eliteIcon"]["xOffset"] = -11
    E.db["nameplates"]["units"]["ENEMY_NPC"]["eliteIcon"]["size"] = 25
    E.db["nameplates"]["units"]["ENEMY_NPC"]["eliteIcon"]["yOffset"] = -1
    E.db["nameplates"]["units"]["ENEMY_NPC"]["eliteIcon"]["position"] = "LEFT"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["name"]["abbrev"] = true
    E.db["nameplates"]["units"]["ENEMY_NPC"]["name"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["name"]["xOffset"] = 2
    E.db["nameplates"]["units"]["ENEMY_NPC"]["name"]["yOffset"] = -15
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["height"] = 20
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["text"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["text"]["position"] = "BOTTOMRIGHT"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["text"]["enable"] = true
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["text"]["format"] = "CURRENT_PERCENT"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["text"]["xOffset"] = -2
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["text"]["yOffset"] = 15
    E.db["nameplates"]["units"]["ENEMY_NPC"]["health"]["width"] = 165
    E.db["nameplates"]["units"]["ENEMY_NPC"]["level"]["enable"] = false
    E.db["nameplates"]["units"]["ENEMY_NPC"]["level"]["font"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["buffs"]["countFont"] = "Arial Narrow Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["buffs"]["durationFontSize"] = 15
    E.db["nameplates"]["units"]["ENEMY_NPC"]["buffs"]["durationFont"] = "ArchivoNarrow-Bold"
    E.db["nameplates"]["units"]["ENEMY_NPC"]["buffs"]["enable"] = false
    E.db["nameplates"]["units"]["ENEMY_NPC"]["buffs"]["filters"]["priority"] = "Blacklist,blockNoDuration,Personal,TurtleBuffs"
    E.db["nameplates"]["statusbar"] = "Flatt"
    E.db["nameplates"]["useTargetScale"] = false
    E.db["nameplates"]["targetScale"] = 1.2
    E.db["nameplates"]["fadeIn"] = false

    E.db["nameplates"]["filters"]["Mark_Circle"] = E.db["nameplates"]["filters"]["Mark_Circle"] or {}
    E.db["nameplates"]["filters"]["Mark_Circle"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Circle"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Cross"] = E.db["nameplates"]["filters"]["Mark_Cross"] or {}
    E.db["nameplates"]["filters"]["Mark_Cross"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Cross"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Moon"] = E.db["nameplates"]["filters"]["Mark_Moon"] or {}
    E.db["nameplates"]["filters"]["Mark_Moon"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Moon"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Skull"] = E.db["nameplates"]["filters"]["Mark_Skull"] or {}
    E.db["nameplates"]["filters"]["Mark_Skull"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Skull"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Diamond"] = E.db["nameplates"]["filters"]["Mark_Diamond"] or {}
    E.db["nameplates"]["filters"]["Mark_Diamond"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Diamond"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Star"] = E.db["nameplates"]["filters"]["Mark_Star"] or {}
    E.db["nameplates"]["filters"]["Mark_Star"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Star"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Triangle"] = E.db["nameplates"]["filters"]["Mark_Triangle"] or {}
    E.db["nameplates"]["filters"]["Mark_Triangle"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Triangle"]["triggers"] or {}
    E.db["nameplates"]["filters"]["Mark_Square"] = E.db["nameplates"]["filters"]["Mark_Square"] or {}
    E.db["nameplates"]["filters"]["Mark_Square"]["triggers"] = E.db["nameplates"]["filters"]["Mark_Square"]["triggers"] or {}

    E.global["nameplates"]["filters"] = {
        ["Mark_Circle"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0.90980392156863,
                        ["g"] = 0.32941176470588,
                        ["r"] = 0.28627450980392,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = true,
                    ["diamond"] = false,
                    ["square"] = true,
                    ["moon"] = false,
                    ["star"] = false,
                    ["triangle"] = false,
                    ["skull"] = false,
                    ["cross"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Cross"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0,
                        ["g"] = 0,
                        ["r"] = 1,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = false,
                    ["square"] = false,
                    ["diamond"] = false,
                    ["cross"] = true,
                    ["star"] = false,
                    ["triangle"] = false,
                    ["skull"] = false,
                    ["moon"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Moon"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0.94117647058824,
                        ["g"] = 0.8,
                        ["r"] = 0.41176470588235,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = false,
                    ["square"] = false,
                    ["diamond"] = false,
                    ["moon"] = true,
                    ["star"] = false,
                    ["triangle"] = false,
                    ["skull"] = false,
                    ["cross"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Skull"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0.6156862745098,
                        ["g"] = 0.6156862745098,
                        ["r"] = 0.6156862745098,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = false,
                    ["square"] = false,
                    ["diamond"] = false,
                    ["moon"] = false,
                    ["star"] = false,
                    ["triangle"] = false,
                    ["skull"] = true,
                    ["cross"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Diamond"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 0,
                        ["r"] = 1,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = false,
                    ["square"] = false,
                    ["diamond"] = true,
                    ["moon"] = false,
                    ["star"] = false,
                    ["triangle"] = false,
                    ["skull"] = false,
                    ["cross"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Star"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = false,
                    ["diamond"] = false,
                    ["square"] = false,
                    ["moon"] = false,
                    ["star"] = true,
                    ["triangle"] = false,
                    ["skull"] = false,
                    ["cross"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Triangle"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0,
                        ["g"] = 1,
                        ["r"] = 0,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = false,
                    ["diamond"] = false,
                    ["square"] = false,
                    ["cross"] = false,
                    ["triangle"] = true,
                    ["star"] = false,
                    ["skull"] = false,
                    ["moon"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
        ["Mark_Square"] = {
            ["actions"] = {
                ["iconOnly"] = false,
                ["color"] = {
                    ["health"] = true,
                    ["borderColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["nameColor"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["healthColor"] = {
                        ["a"] = 1,
                        ["b"] = 0.90980392156863,
                        ["g"] = 0.32941176470588,
                        ["r"] = 0.28627450980392,
                    },
                    ["border"] = false,
                    ["name"] = false,
                },
                ["nameOnly"] = false,
                ["alpha"] = -1,
                ["flash"] = {
                    ["color"] = {
                        ["a"] = 1,
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["enable"] = false,
                    ["speed"] = 4,
                },
                ["hide"] = false,
                ["scale"] = 1,
                ["icon"] = false,
                ["texture"] = {
                    ["enable"] = false,
                    ["texture"] = "ElvUI Norm",
                },
            },
            ["triggers"] = {
                ["totems"] = {
                    ["w1"] = true,
                    ["w3"] = true,
                    ["w2"] = true,
                    ["enable"] = false,
                    ["a4"] = true,
                    ["a5"] = true,
                    ["a3"] = true,
                    ["a2"] = true,
                    ["a1"] = true,
                    ["e3"] = true,
                    ["e2"] = true,
                    ["e1"] = true,
                    ["f3"] = true,
                    ["e4"] = true,
                    ["e5"] = true,
                    ["e6"] = true,
                    ["f6"] = true,
                    ["o1"] = true,
                    ["w5"] = true,
                    ["w4"] = true,
                    ["f5"] = true,
                    ["f4"] = true,
                    ["f2"] = true,
                    ["f1"] = true,
                },
                ["uniqueUnits"] = {
                    ["enable"] = false,
                    ["u2"] = true,
                    ["u1"] = true,
                },
                ["isResting"] = false,
                ["healthThreshold"] = false,
                ["level"] = false,
                ["curlevel"] = 0,
                ["healthUsePlayer"] = false,
                ["role"] = {
                    ["tank"] = false,
                    ["damager"] = false,
                    ["healer"] = false,
                },
                ["buffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["maxlevel"] = 0,
                ["cooldowns"] = {
                    ["mustHaveAll"] = false,
                },
                ["priority"] = 1,
                ["outOfCombat"] = false,
                ["instanceType"] = {
                    ["sanctuary"] = false,
                    ["party"] = false,
                    ["pvp"] = false,
                    ["raid"] = false,
                    ["arena"] = false,
                    ["none"] = false,
                },
                ["raidTarget"] = {
                    ["circle"] = true,
                    ["diamond"] = false,
                    ["square"] = true,
                    ["moon"] = false,
                    ["star"] = false,
                    ["triangle"] = false,
                    ["skull"] = false,
                    ["cross"] = false,
                },
                ["debuffs"] = {
                    ["minTimeLeft"] = 0,
                    ["mustHaveAll"] = false,
                    ["missing"] = false,
                    ["maxTimeLeft"] = 0,
                },
                ["underPowerThreshold"] = 0,
                ["nameplateType"] = {
                    ["enemyNPC"] = false,
                    ["friendlyPlayer"] = false,
                    ["enable"] = false,
                    ["enemyPlayer"] = false,
                    ["friendlyNPC"] = false,
                },
                ["minlevel"] = 0,
                ["instanceDifficulty"] = {
                    ["dungeon"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                    ["raid"] = {
                        ["normal"] = false,
                        ["heroic"] = false,
                    },
                },
                ["overHealthThreshold"] = 0,
                ["underHealthThreshold"] = 0,
                ["overPowerThreshold"] = 0,
                ["notTarget"] = false,
                ["powerThreshold"] = false,
                ["reactionType"] = {
                    ["neutral"] = false,
                    ["hostile"] = false,
                    ["friendly"] = false,
                    ["enabled"] = false,
                },
                ["isTarget"] = false,
                ["inCombat"] = false,
            },
        },
    }

    E.db["nameplates"]["filters"]["Mark_Circle"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Cross"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Moon"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Skull"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Diamond"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Star"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Triangle"]["triggers"]["enable"] = true
    E.db["nameplates"]["filters"]["Mark_Square"]["triggers"]["enable"] = true

    E.private["nameplates"]["enable"] = true
end

local function LoadLayoutSettingsGeneral()

    local profile_name = string.format("%s - %s", UnitName("player"), GetRealmName("player"))
    ElvPrivateDB["profiles"] = ElvPrivateDB["profiles"] or {}
    ElvPrivateDB["profiles"][profile_name] = ElvPrivateDB["profiles"][profile_name] or {}
    ElvPrivateDB["profiles"][profile_name]["general"] = ElvPrivateDB["profiles"][profile_name]["general"] or {}
    ElvPrivateDB["profiles"][profile_name]["general"]["totemBar"] = false

    -- Movers
    E.db["movers"] = E.db["movers"] or {}
    E.db["movers"]["TimeManagerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-280"
    E.db["movers"]["AlertFrameMover"] = "TOP,UIParent,TOP,0,-354"
    E.db["movers"]["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-320"  
    E.db["movers"]["AzeriteBarMover"] = "TOP,ElvUIParent,TOP,-311,-371"
    E.db["movers"]["BNETMover"] = "TOPLEFT,UIParent,TOPLEFT,496,-4"
    E.db["movers"]["BagsMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,-763,4"
    E.db["movers"]["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-246,-209"
    E.db["movers"]["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,-200,514"
    E.db["movers"]["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-363"
    E.db["movers"]["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-210,-4"
    E.db["movers"]["ClassBarMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,4,491"
    E.db["movers"]["DTB2_DBT2_LeftBottomBar_Mover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4"
    E.db["movers"]["DTB2_DBT2_RightBottomBar_Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4"
    E.db["movers"]["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-210,-157"
    E.db["movers"]["DurabilityFrameMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-7,430"
    E.db["movers"]["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,29"
    E.db["movers"]["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,281"
    E.db["movers"]["ExperienceBarMover"] = "TOP,UIParent,TOP,0,-4"
    E.db["movers"]["GMMover"] = "TOPLEFT,UIParent,TOPLEFT,284,-4"
    E.db["movers"]["HonorBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,528,-338"
    E.db["movers"]["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29"
    E.db["movers"]["LootFrameMover"] = "TOP,UIParent,TOP,0,-218"
    E.db["movers"]["LossControlMover"] = "TOP,UIParent,TOP,0,-490"
    E.db["movers"]["MawBuffsBelowMinimapMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-4,-335"
    E.db["movers"]["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-238,4"
    E.db["movers"]["MinimapButtonAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-203"
    E.db["movers"]["MinimapMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-4,-4"
    E.db["movers"]["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-34,-253"
    E.db["movers"]["OzCooldownsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-271,-453"
    E.db["movers"]["PrivateAurasMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-210,-208"
    E.db["movers"]["QuestTime rFrameMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-4,-283"
    E.db["movers"]["QuestWatchFrameMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-4,-256"
    E.db["movers"]["RaidMarkerBarAnchor"] = "TOP,UIParent,TOP,0,-4"
    E.db["movers"]["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,29"
    E.db["movers"]["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-208"
    E.db["movers"]["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,404"
    E.db["movers"]["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-62"
    E.db["movers"]["TorghastBuffsMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-4"
    E.db["movers"]["TorghastChoiceToggle"] = "TOPLEFT,UIParent,TOPLEFT,285,-4"
    E.db["movers"]["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,499"
    E.db["movers"]["TotemTrackerMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,404,4"
    E.db["movers"]["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,284,-82"
    E.db["movers"]["VehicleLeaveButton"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,404,134"
    E.db["movers"]["VehicleSeatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,404,4"
    E.db["movers"]["ZoneAbility"] = "TOP,ElvUIParent,TOP,200,-514"
    E.db["movers"]["PetExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-30"
    E.db["movers"]["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,289,-81"
    E.db["movers"]["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-242"

    E.db["general"]["totems"] = E.db["general"]["totems"] or {}
    E.db["general"]["totems"]["font"] = "ArchivoNarrow-Bold"
    E.db["general"]["totems"]["fontSize"] = 15
    E.db["general"]["totems"]["mouseover"] = true
    E.db["general"]["totems"]["spacing"] = 1

    -- Auras
    E.db["auras"]["font"] = "ArchivoNarrow-Bold"
    E.db["auras"]["cooldown"]["hhmmColor"]["b"] = 1
    E.db["auras"]["cooldown"]["hhmmColor"]["g"] = 1
    E.db["auras"]["cooldown"]["hhmmColor"]["r"] = 1
    E.db["auras"]["cooldown"]["secondsColor"]["b"] = 0
    E.db["auras"]["cooldown"]["checkSeconds"] = true
    E.db["auras"]["cooldown"]["mmssColor"]["b"] = 1
    E.db["auras"]["cooldown"]["mmssColor"]["g"] = 1
    E.db["auras"]["cooldown"]["mmssColor"]["r"] = 1
    E.db["auras"]["cooldown"]["override"] = true
    E.db["auras"]["cooldown"]["mmssThreshold"] = 600
    E.db["auras"]["fontOutline"] = "OUTLINE"
    E.db["auras"]["buffs"]["countFontSize"] = 15
    E.db["auras"]["buffs"]["durationFontSize"] = 15
    E.db["auras"]["buffs"]["verticalSpacing"] = 20
    E.db["auras"]["buffs"]["horizontalSpacing"] = 2
    E.db["auras"]["buffs"]["wrapAfter"] = 16
    E.db["auras"]["barTexture"] = "Flatt"
    E.db["auras"]["debuffs"]["horizontalSpacing"] = 3
    E.db["auras"]["debuffs"]["durationFontSize"] = 15
    E.db["auras"]["debuffs"]["size"] = 36

    -- Bags
    E.db["bags"]["bagBar"]["growthDirection"] = "HORIZONTAL"
    E.db["bags"]["bagBar"]["justBackpack"] = true
    E.db["bags"]["bagBar"]["mouseover"] = true
    E.db["bags"]["bagBar"]["size"] = 40
    E.db["bags"]["bagBar"]["spacing"] = -1
    E.db["bags"]["bagButtonSpacing"] = 0
    E.db["bags"]["bagSize"] = 38
    E.db["bags"]["bagWidth"] = 410
    E.db["bags"]["bankSize"] = 42
    E.db["bags"]["bankWidth"] = 464
    E.db["bags"]["clearSearchOnClose"] = true
    E.db["bags"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["bags"]["countFontOutline"] = "OUTLINE"
    E.db["bags"]["countFontSize"] = 16
    E.db["bags"]["countxOffset"] = 1
    E.db["bags"]["countyOffset"] = 1
    E.db["bags"]["itemInfoFont"] = "ArchivoNarrow-Bold"
    E.db["bags"]["itemInfoFontOutline"] = "OUTLINE"
    E.db["bags"]["itemInfoFontSize"] = 16
    E.db["bags"]["itemLevelFont"] = "ArchivoNarrow-Bold"
    E.db["bags"]["itemLevelFontOutline"] = "OUTLINE"
    E.db["bags"]["itemLevelFontSize"] = 16
    E.db["bags"]["itemLevelxOffset"] = 1
    E.db["bags"]["itemLevelyOffset"] = 1
    E.db["bags"]["moneyCoins"] = false
    E.db["bags"]["moneyFormat"] = "CONDENSED"
    E.db["bags"]["split"]["bagSpacing"] = 2

    -- Chat
    E.db["chat"]["editBoxPosition"] = "ABOVE_CHAT_INSIDE"
    E.db["chat"]["font"] = "ArchivoNarrow-Bold"
    E.db["chat"]["panelBackdrop"] = "LEFT"
    E.db["chat"]["panelBackdropNameLeft"] = "Interface\\Addons\\SharedMedia_MyMedia\\MerfinUI_ChatBackground.tga"
    E.db["chat"]["panelColor"]["a"] = 0.67553424835205
    E.db["chat"]["panelColor"]["b"] = 0.058823529411765
    E.db["chat"]["panelColor"]["g"] = 0.058823529411765
    E.db["chat"]["panelColor"]["r"] = 0.058823529411765
    E.db["chat"]["panelHeight"] = 250
    E.db["chat"]["panelHeightRight"] = 270
    E.db["chat"]["panelTabBackdrop"] = true
    E.db["chat"]["panelTabTransparency"] = true
    E.db["chat"]["panelWidth"] = 396
    E.db["chat"]["panelWidthRight"] = 230
    E.db["chat"]["separateSizes"] = true
    E.db["chat"]["showHistory"]["CHANNEL"] = false
    E.db["chat"]["showHistory"]["EMOTE"] = false
    E.db["chat"]["showHistory"]["INSTANCE"] = false
    E.db["chat"]["tabFont"] = "ArchivoNarrow-Bold"
    E.db["chat"]["tabFontSize"] = 13
    E.db["chat"]["tabSelector"] = "ARROW3"
    E.db["chat"]["timeStampFormat"] = "%H:%M:%S "
    
    E.db["convertPages"] = true

    E.db["datatexts"]["leftChatPanel"] = false
    E.db["datatexts"]["rightChatPanel"] = false
    E.db["datatexts"]["panels"]["DTB2_DBT2_RightBottomBar"] = E.db["datatexts"]["panels"]["DTB2_DBT2_RightBottomBar"] or {}
    E.db["datatexts"]["panels"]["DTB2_DBT2_RightBottomBar"]["left"] = "Durability"
    E.db["datatexts"]["panels"]["DTB2_DBT2_RightBottomBar"]["right"] = "Gold"
    E.db["datatexts"]["panels"]["DTB2_DBT2_LeftBottomBar"] = E.db["datatexts"]["panels"]["DTB2_DBT2_LeftBottomBar"] or {}
    E.db["datatexts"]["panels"]["DTB2_DBT2_LeftBottomBar"]["left"] = "System"
    E.db["datatexts"]["panels"]["DTB2_DBT2_LeftBottomBar"]["right"] = "Time"

    E.db["databars"]["experience"]["font"] = "ArchivoNarrow-Bold"
    E.db["databars"]["experience"]["fontOutline"] = "OUTLINE"
    E.db["databars"]["experience"]["textSize"] = 15
    E.db["databars"]["experience"]["height"] = 27
    E.db["databars"]["experience"]["showLevel"] = true
    E.db["databars"]["experience"]["showQuestXP"] = false
    E.db["databars"]["experience"]["textFormat"] = "CURMAX"
    E.db["databars"]["experience"]["width"] = 396
    E.db["databars"]["experience"]["orientation"] = "HORIZONTAL"
    E.db["databars"]["petExperience"]["font"] = "ArchivoNarrow-Bold"
    E.db["databars"]["petExperience"]["textSize"] = 15
    E.db["databars"]["petExperience"]["height"] = 20
    E.db["databars"]["petExperience"]["textFormat"] = "CURMAX"
    E.db["databars"]["petExperience"]["width"] = 300
    E.db["databars"]["reputation"]["fontSize"] = 13
    E.db["datatexts"]["font"] = "ArchivoNarrow-Bold"
    E.db["datatexts"]["fontSize"] = 13

    -- General
    E.db["general"]["afk"] = false
    E.db["general"]["autoAcceptInvite"] = true
    E.db["general"]["autoRepair"] = "PLAYER"
    E.db["general"]["bottomPanel"] = false
    E.db["general"]["font"] = "ArchivoNarrow-Bold"
    E.db["general"]["fontSize"] = 15
    E.db["general"]["minimap"]["clusterBackdrop"] = false
    E.db["general"]["minimap"]["locationFont"] = "ArchivoNarrow-Bold"
    E.db["general"]["minimap"]["size"] = 199
    E.db["general"]["minimap"]["timeFont"] = "ArchivoNarrow-Bold"
    E.db["general"]["minimap"]["timeFontSize"] = 15
    E.db["general"]["totems"]["growthDirection"] = "HORIZONTAL"
    E.db["general"]["totems"]["size"] = 34
    E.db["general"]["totems"]["spacing"] = 1
    E.db["general"]["valuecolor"]["b"] = 0
    E.db["general"]["valuecolor"]["g"] = 0.42352941176471
    E.db["general"]["valuecolor"]["r"] = 1

    -- Tooltip
    E.db["tooltip"]["font"] = "ArchivoNarrow-Bold"
    E.db["tooltip"]["fontOutline"] = "OUTLINE"
    E.db["tooltip"]["headerFont"] = "ArchivoNarrow-Bold"
    E.db["tooltip"]["headerFontOutline"] = "OUTLINE"
    E.db["tooltip"]["healthBar"]["font"] = "ArchivoNarrow-Bold"
    E.db["tooltip"]["healthBar"]["fontSize"] = 14
    E.db["tooltip"]["healthBar"]["text"] = false
    E.db["tooltip"]["smallTextFontSize"] = 13
    E.db["tooltip"]["textFontSize"] = 13

    -- UF threat
    E.db["unitframe"] = E.db["unitframe"] or {}
    E.db["unitframe"]["units"] = E.db["unitframe"]["units"] or {}
    E.db["unitframe"]["units"]["raid1"] = E.db["unitframe"]["units"]["raid1"] or {}
    E.db["unitframe"]["units"]["raid"] = E.db["unitframe"]["units"]["raid"] or {}
    E.db["unitframe"]["units"]["raid40"] = E.db["unitframe"]["units"]["raid40"] or {}
    E.db["unitframe"]["units"]["party"] = E.db["unitframe"]["units"]["party"] or {}

    E.db["unitframe"]["units"]["raid1"]["threatStyle"] = "ICONLEFT"
    E.db["unitframe"]["units"]["raid"]["threatStyle"] = "ICONLEFT"
    E.db["unitframe"]["units"]["raid40"]["threatStyle"] = "ICONLEFT"
    E.db["unitframe"]["units"]["party"]["threatStyle"] = "ICONLEFT"

    -- UF custom text empty tables
    E.db["unitframe"]["units"]["arena"]["customTexts"] = E.db["unitframe"]["units"]["arena"]["customTexts"] or {}
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"] or {}
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"] = E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"] or {}

    E.db["unitframe"]["units"]["focus"]["customTexts"] = E.db["unitframe"]["units"]["focus"]["customTexts"] or {}
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"] = E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"] or {}
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["focustarget"]["customTexts"] = E.db["unitframe"]["units"]["focustarget"]["customTexts"] or {}
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"] or {}

    E.db["unitframe"]["units"]["party"]["customTexts"] = E.db["unitframe"]["units"]["party"]["customTexts"] or {}
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"] = E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"] or {}

    E.db["unitframe"]["units"]["party"]["customTexts"] = E.db["unitframe"]["units"]["party"]["customTexts"] or {}
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"] = E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"] or {}
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["pet"]["customTexts"] = E.db["unitframe"]["units"]["pet"]["customTexts"] or {}
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"] or {}
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"] = E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"] or {}

    E.db["unitframe"]["units"]["player"]["customTexts"] = E.db["unitframe"]["units"]["player"]["customTexts"] or {}
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"] = E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"] or {}
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"] = E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"] or {}
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["raid1"]["customTexts"] = E.db["unitframe"]["units"]["raid1"]["customTexts"] or {}
    E.db["unitframe"]["units"]["raid1"]["customTexts"]["DeadGhostStatus"] = E.db["unitframe"]["units"]["raid1"]["customTexts"]["DeadGhostStatus"] or {}
    E.db["unitframe"]["units"]["raid1"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["raid1"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["raid1"]["customTexts"]["OfflineStatus"] = E.db["unitframe"]["units"]["raid1"]["customTexts"]["OfflineStatus"] or {}
    E.db["unitframe"]["units"]["raid1"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["raid1"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["raid"]["customTexts"] = E.db["unitframe"]["units"]["raid"]["customTexts"] or {}
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"] = E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"] or {}
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"] = E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"] or {}
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["raid40"]["customTexts"] = E.db["unitframe"]["units"]["raid40"]["customTexts"] or {}
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"] = E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"] or {}
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"] = E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"] or {}
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["raidpet"]["customTexts"] = E.db["unitframe"]["units"]["raidpet"]["customTexts"] or {}
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"] or {}

    E.db["unitframe"]["units"]["target"]["customTexts"] = E.db["unitframe"]["units"]["target"]["customTexts"] or {}
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"] = E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"] or {}
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["targettarget"]["customTexts"] = E.db["unitframe"]["units"]["targettarget"]["customTexts"] or {}
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["boss"]["customTexts"] = E.db["unitframe"]["units"]["boss"]["customTexts"] or {}
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"] = E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"] or {}
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"] = E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"] or {}
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"] = E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"] or {}

    E.db["unitframe"]["units"]["party"]["debuffs"]["priority"] = "Blacklist,BLACKLIST: Debuff Indicators,VoA_RaidDebuffs,OS_RaidDebuffs,Naxx_RaidDebuffs,EoE_RaidDebuffs,Ulduar_RaidDebuffs,ToGC_RaidDebuffs,ICC_RaidDebuffs,RS_RaidDebuffs,RaidDebuffs,Dispellable,notCastByUnit"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["priority"] = "Blacklist,BLACKLIST: Debuff Indicators,VoA_RaidDebuffs,OS_RaidDebuffs,Naxx_RaidDebuffs,EoE_RaidDebuffs,Ulduar_RaidDebuffs,ToGC_RaidDebuffs,ICC_RaidDebuffs,RS_RaidDebuffs,Dispellable"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["priority"] = "Blacklist,BLACKLIST: Debuff Indicators,VoA_RaidDebuffs,OS_RaidDebuffs,Naxx_RaidDebuffs,EoE_RaidDebuffs,Ulduar_RaidDebuffs,ToGC_RaidDebuffs,ICC_RaidDebuffs,RS_RaidDebuffs,Dispellable"


    E.db["unitframe"]["colors"]["castColor"]["b"] = 0
    E.db["unitframe"]["colors"]["castColor"]["g"] = 0.67843137254902
    E.db["unitframe"]["colors"]["castColor"]["r"] = 1
    E.db["unitframe"]["colors"]["castNoInterrupt"]["b"] = 0.25098039215686
    E.db["unitframe"]["colors"]["castNoInterrupt"]["g"] = 0.25098039215686
    E.db["unitframe"]["colors"]["castNoInterrupt"]["r"] = 0.78039215686275
    E.db["unitframe"]["colors"]["castbar_backdrop"]["b"] = 0.10588235294118
    E.db["unitframe"]["colors"]["castbar_backdrop"]["g"] = 0.10588235294118
    E.db["unitframe"]["colors"]["castbar_backdrop"]["r"] = 0.2078431372549
    E.db["unitframe"]["colors"]["colorhealthbyvalue"] = false
    E.db["unitframe"]["colors"]["customcastbarbackdrop"] = true
    E.db["unitframe"]["colors"]["customhealthbackdrop"] = true
    E.db["unitframe"]["colors"]["debuffHighlight"]["blendMode"] = "ALPHAKEY"
    E.db["unitframe"]["colors"]["frameGlow"]["mouseoverGlow"]["enable"] = false
    E.db["unitframe"]["colors"]["frameGlow"]["targetGlow"]["enable"] = false
    E.db["unitframe"]["colors"]["health"]["b"] = 0.17254901960784
    E.db["unitframe"]["colors"]["health"]["g"] = 0.17254901960784
    E.db["unitframe"]["colors"]["health"]["r"] = 0.1921568627451
    E.db["unitframe"]["colors"]["health_backdrop"]["b"] = 0.12549019607843
    E.db["unitframe"]["colors"]["health_backdrop"]["g"] = 0.12549019607843
    E.db["unitframe"]["colors"]["health_backdrop"]["r"] = 0.14901960784314
    E.db["unitframe"]["colors"]["health_backdrop_dead"]["b"] = 0.46274509803922
    E.db["unitframe"]["colors"]["health_backdrop_dead"]["g"] = 0.46274509803922
    E.db["unitframe"]["colors"]["health_backdrop_dead"]["r"] = 0.51764705882353
    E.db["unitframe"]["colors"]["healthclass"] = true
    E.db["unitframe"]["colors"]["power"]["MANA"]["b"] = 1
    E.db["unitframe"]["colors"]["power"]["MANA"]["g"] = 0.86274509803922
    E.db["unitframe"]["colors"]["power"]["MANA"]["r"] = 0.019607843137255
    E.db["unitframe"]["cooldown"]["fonts"]["enable"] = true
    E.db["unitframe"]["cooldown"]["fonts"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["cooldown"]["fonts"]["fontSize"] = 21
    E.db["unitframe"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["fontSize"] = 13
    E.db["unitframe"]["statusbar"] = "Flatt"
    E.db["unitframe"]["units"]["arena"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["arena"]["buffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["arena"]["buffs"]["enable"] = false
    E.db["unitframe"]["units"]["arena"]["buffs"]["maxDuration"] = 0
    E.db["unitframe"]["units"]["arena"]["buffs"]["priority"] = "Blacklist,CastByUnit,Dispellable,Whitelist,RaidBuffsElvUI"
    E.db["unitframe"]["units"]["arena"]["buffs"]["sizeOverride"] = 22
    E.db["unitframe"]["units"]["arena"]["buffs"]["yOffset"] = 20
    E.db["unitframe"]["units"]["arena"]["castbar"]["width"] = 215
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["enable"] = true
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["size"] = 15
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["text_format"] = "[power:current]"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["xOffset"] = 0
    E.db["unitframe"]["units"]["arena"]["customTexts"]["PowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["enable"] = true
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current-percent]"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["xOffset"] = -3
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["justifyH"] = "LEFT"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["text_format"] = "[name:abbrev:short]"
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["xOffset"] = 3
    E.db["unitframe"]["units"]["arena"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["arena"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["arena"]["debuffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["arena"]["debuffs"]["desaturate"] = true
    E.db["unitframe"]["units"]["arena"]["debuffs"]["enable"] = false
    E.db["unitframe"]["units"]["arena"]["debuffs"]["maxDuration"] = 0
    E.db["unitframe"]["units"]["arena"]["debuffs"]["priority"] = "Blacklist,Boss,Personal,RaidDebuffs,CastByUnit,Whitelist"
    E.db["unitframe"]["units"]["arena"]["debuffs"]["sizeOverride"] = 22
    E.db["unitframe"]["units"]["arena"]["debuffs"]["yOffset"] = -3
    E.db["unitframe"]["units"]["arena"]["growthDirection"] = "UP"
    E.db["unitframe"]["units"]["arena"]["healPrediction"]["enable"] = false
    E.db["unitframe"]["units"]["arena"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["arena"]["height"] = 44
    E.db["unitframe"]["units"]["arena"]["infoPanel"]["height"] = 16
    E.db["unitframe"]["units"]["arena"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["arena"]["power"]["height"] = 6
    E.db["unitframe"]["units"]["arena"]["power"]["text_format"] = ""
    E.db["unitframe"]["units"]["arena"]["pvpTrinket"]["size"] = 44
    E.db["unitframe"]["units"]["arena"]["spacing"] = -1
    E.db["unitframe"]["units"]["arena"]["width"] = 230
    E.db["unitframe"]["units"]["assist"]["enable"] = false
    E.db["unitframe"]["units"]["boss"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["boss"]["buffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["boss"]["buffs"]["enable"] = false
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["enable"] = true
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["size"] = 15
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["text_format"] = "[power:current]"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["xOffset"] = 0
    E.db["unitframe"]["units"]["boss"]["customTexts"]["PowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["enable"] = true
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current-percent]"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["xOffset"] = -3
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["justifyH"] = "LEFT"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["text_format"] = "[name:abbrev:short]"
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["xOffset"] = 3
    E.db["unitframe"]["units"]["boss"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["boss"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["boss"]["debuffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["boss"]["debuffs"]["enable"] = false
    E.db["unitframe"]["units"]["boss"]["growthDirection"] = "UP"
    E.db["unitframe"]["units"]["boss"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["boss"]["height"] = 44
    E.db["unitframe"]["units"]["boss"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["boss"]["power"]["height"] = 6
    E.db["unitframe"]["units"]["boss"]["power"]["text_format"] = ""
    E.db["unitframe"]["units"]["boss"]["spacing"] = -1
    E.db["unitframe"]["units"]["boss"]["width"] = 230
    E.db["unitframe"]["units"]["focus"]["aurabar"]["detachedWidth"] = 270
    E.db["unitframe"]["units"]["focus"]["aurabar"]["maxBars"] = 6
    E.db["unitframe"]["units"]["focus"]["buffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["focus"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focus"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["focus"]["buffs"]["enable"] = true
    E.db["unitframe"]["units"]["focus"]["buffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["focus"]["buffs"]["maxDuration"] = 0
    E.db["unitframe"]["units"]["focus"]["buffs"]["priority"] = "Blacklist,TurtleBuffs,Dispellable,Enemy:CastByUnit,Enemy:Personal"
    E.db["unitframe"]["units"]["focus"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["focus"]["buffs"]["yOffset"] = -2
    E.db["unitframe"]["units"]["focus"]["castbar"]["height"] = 27
    E.db["unitframe"]["units"]["focus"]["castbar"]["strataAndLevel"]["frameStrata"] = "BACKGROUND"
    E.db["unitframe"]["units"]["focus"]["castbar"]["strataAndLevel"]["useCustomLevel"] = true
    E.db["unitframe"]["units"]["focus"]["castbar"]["spark"] = false
    E.db["unitframe"]["units"]["focus"]["castbar"]["width"] = 150
    E.db["unitframe"]["units"]["focus"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["enable"] = true
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["size"] = 15
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["text_format"] = "[power:current]"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["xOffset"] = 0
    E.db["unitframe"]["units"]["focus"]["customTexts"]["PowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["enable"] = true
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["text_format"] = "[health:percent]"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["xOffset"] = -3
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["justifyH"] = "LEFT"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["text_format"] = "[name:short]"
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["xOffset"] = 3
    E.db["unitframe"]["units"]["focus"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["focus"]["debuffs"]["anchorPoint"] = "LEFT"
    E.db["unitframe"]["units"]["focus"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focus"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["focus"]["debuffs"]["enable"] = false
    E.db["unitframe"]["units"]["focus"]["debuffs"]["perrow"] = 6
    E.db["unitframe"]["units"]["focus"]["debuffs"]["priority"] = "Blacklist,CCDebuffs,Friendly:nonPersonal,Personal"
    E.db["unitframe"]["units"]["focus"]["buffs"]["priority"] = "Blacklist,TurtleBuffs,Dispellable,Enemy:CastByUnit,Enemy:Personal"
    E.db["unitframe"]["units"]["focus"]["debuffs"]["sizeOverride"] = 37
    E.db["unitframe"]["units"]["focus"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["focus"]["debuffs"]["xOffset"] = -7
    E.db["unitframe"]["units"]["focus"]["debuffs"]["yOffset"] = -1
    E.db["unitframe"]["units"]["focus"]["disableTargetGlow"] = true
    E.db["unitframe"]["units"]["focus"]["fader"]["enable"] = false
    E.db["unitframe"]["units"]["focus"]["healPrediction"]["enable"] = false
    E.db["unitframe"]["units"]["focus"]["height"] = 44
    E.db["unitframe"]["units"]["focus"]["infoPanel"]["height"] = 20
    E.db["unitframe"]["units"]["focus"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["focus"]["orientation"] = "RIGHT"
    E.db["unitframe"]["units"]["focus"]["power"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["focus"]["power"]["height"] = 7
    E.db["unitframe"]["units"]["focus"]["power"]["position"] = "CENTER"
    E.db["unitframe"]["units"]["focus"]["threatStyle"] = "NONE"
    E.db["unitframe"]["units"]["focus"]["width"] = 150
    E.db["unitframe"]["units"]["focustarget"]["buffs"]["priority"] = "Blacklist,Personal,PlayerBuffs,Dispellable"
    E.db["unitframe"]["units"]["focustarget"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["focustarget"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["attachTo"] = "BUFFS"
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["perrow"] = 3
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["priority"] = "Blacklist,Personal,Boss,RaidDebuffs,CCDebuffs,Dispellable,Whitelist"
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["focustarget"]["debuffs"]["yOffset"] = 28
    E.db["unitframe"]["units"]["focustarget"]["disableTargetGlow"] = true
    E.db["unitframe"]["units"]["focustarget"]["enable"] = true
    E.db["unitframe"]["units"]["focustarget"]["fader"]["enable"] = false
    E.db["unitframe"]["units"]["focustarget"]["height"] = 30
    E.db["unitframe"]["units"]["focustarget"]["infoPanel"]["height"] = 14
    E.db["unitframe"]["units"]["focustarget"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["focustarget"]["power"]["enable"] = false
    E.db["unitframe"]["units"]["focustarget"]["width"] = 70
    E.db["unitframe"]["units"]["party"]["buffIndicator"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["party"]["buffIndicator"]["enable"] = false
    E.db["unitframe"]["units"]["party"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["party"]["buffs"]["sizeOverride"] = 19
    E.db["unitframe"]["units"]["party"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["party"]["buffs"]["enable"] = true
    E.db["unitframe"]["units"]["party"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["buffs"]["anchorPoint"] = "TOPLEFT"
    E.db["unitframe"]["units"]["party"]["buffs"]["yOffset"] = -19
    E.db["unitframe"]["units"]["party"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["enable"] = true
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["size"] = 15
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["text_format"] = "[namecolor][dead]"
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["party"]["customTexts"]["DeadGhostStatus"]["yOffset"] = 0
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["enable"] = false
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["size"] = 15
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["text_format"] = "[namecolor][offline]"
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["party"]["customTexts"]["OfflineStatus"]["yOffset"] = 0
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["enable"] = false
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["xOffset"] = -5
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["text_format"] = "[name:abbrev:short]"
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["xOffset"] = 3
    E.db["unitframe"]["units"]["party"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["party"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["party"]["debuffs"]["sizeOverride"] = 33
    E.db["unitframe"]["units"]["party"]["debuffs"]["xOffset"] = 5
    E.db["unitframe"]["units"]["party"]["groupBy"] = "ROLE"
    E.db["unitframe"]["units"]["party"]["healPrediction"]["enable"] = true
    E.db["unitframe"]["units"]["party"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["party"]["height"] = 60
    E.db["unitframe"]["units"]["party"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["party"]["petsGroup"]["anchorPoint"] = "LEFT"
    E.db["unitframe"]["units"]["party"]["petsGroup"]["enable"] = true
    E.db["unitframe"]["units"]["party"]["petsGroup"]["height"] = 50
    E.db["unitframe"]["units"]["party"]["petsGroup"]["name"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["party"]["petsGroup"]["width"] = 150
    E.db["unitframe"]["units"]["party"]["petsGroup"]["xOffset"] = -131
    E.db["unitframe"]["units"]["party"]["power"]["height"] = 6
    E.db["unitframe"]["units"]["party"]["power"]["text_format"] = ""
    E.db["unitframe"]["units"]["party"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["party"]["rdebuffs"]["enable"] = true
    E.db["unitframe"]["units"]["party"]["rdebuffs"]["fontSize"] = 13
    E.db["unitframe"]["units"]["party"]["rdebuffs"]["yOffset"] = 17
    E.db["unitframe"]["units"]["party"]["readycheckIcon"]["attachTo"] = "CENTER"
    E.db["unitframe"]["units"]["party"]["readycheckIcon"]["size"] = 20
    E.db["unitframe"]["units"]["party"]["readycheckIcon"]["yOffset"] = 13
    E.db["unitframe"]["units"]["party"]["roleIcon"]["enable"] = false
    E.db["unitframe"]["units"]["party"]["sortDir"] = "DESC"
    E.db["unitframe"]["units"]["party"]["threatStyle"] = "ICONLEFT"
    E.db["unitframe"]["units"]["party"]["verticalSpacing"] = -1
    E.db["unitframe"]["units"]["party"]["width"] = 230
    E.db["unitframe"]["units"]["pet"]["buffs"]["priority"] = "Blacklist,Personal,PlayerBuffs,Dispellable"
    E.db["unitframe"]["units"]["pet"]["castbar"]["enable"] = false
    E.db["unitframe"]["units"]["pet"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["enable"] = true
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["size"] = 16
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["text_format"] = "[power:current]"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["xOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["customTexts"]["PowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["enable"] = true
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["size"] = 16
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current] - [health:max]"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["xOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["enable"] = false
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["size"] = 16
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["text_format"] = "[name:abbrev:short]"
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["debuffs"]["attachTo"] = "BUFFS"
    E.db["unitframe"]["units"]["pet"]["debuffs"]["priority"] = "Blacklist,Personal,Boss,RaidDebuffs,CCDebuffs,Dispellable,Whitelist"
    E.db["unitframe"]["units"]["pet"]["fader"]["enable"] = false
    E.db["unitframe"]["units"]["pet"]["healPrediction"]["enable"] = false
    E.db["unitframe"]["units"]["pet"]["height"] = 44
    E.db["unitframe"]["units"]["pet"]["infoPanel"]["height"] = 14
    E.db["unitframe"]["units"]["pet"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["pet"]["power"]["attachTextTo"] = "Frame"
    E.db["unitframe"]["units"]["pet"]["power"]["height"] = 7
    E.db["unitframe"]["units"]["pet"]["power"]["xOffset"] = 0
    E.db["unitframe"]["units"]["pet"]["threatStyle"] = "NONE"
    E.db["unitframe"]["units"]["pet"]["width"] = 120
    E.db["unitframe"]["units"]["pettarget"]["fader"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["CombatIcon"]["size"] = 23
    E.db["unitframe"]["units"]["player"]["RestIcon"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["aurabar"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["buffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["player"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["player"]["castbar"]["height"] = 35
    E.db["unitframe"]["units"]["player"]["castbar"]["spark"] = false
    E.db["unitframe"]["units"]["player"]["castbar"]["tickWidth"] = 3
    E.db["unitframe"]["units"]["player"]["castbar"]["format"] = "CURRENTMAX"
    E.db["unitframe"]["units"]["player"]["castbar"]["tickColor"]["a"] = 1
    E.db["unitframe"]["units"]["player"]["classbar"]["detachedWidth"] = 220
    E.db["unitframe"]["units"]["player"]["classbar"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["justifyH"] = "LEFT"
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["size"] = 15
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["text_format"] = "[altpowercolor][classpower:current]"
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["xOffset"] = 3
    E.db["unitframe"]["units"]["player"]["customTexts"]["AltPowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["size"] = 15
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["text_format"] = "[power:current]"
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["xOffset"] = 0
    E.db["unitframe"]["units"]["player"]["customTexts"]["PowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["enable"] = true
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["xOffset"] = -2
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["font"] = "Expressway"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["justifyH"] = "LEFT"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["text_format"] = "[name]"
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["xOffset"] = 5
    E.db["unitframe"]["units"]["player"]["customTexts"]["UnitName"]["yOffset"] = 20
    E.db["unitframe"]["units"]["player"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["player"]["debuffs"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["healPrediction"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["player"]["height"] = 44
    E.db["unitframe"]["units"]["player"]["power"]["EnergyManaRegen"] = true
    E.db["unitframe"]["units"]["player"]["power"]["detachFromFrame"] = true
    E.db["unitframe"]["units"]["player"]["power"]["detachedWidth"] = 400
    E.db["unitframe"]["units"]["player"]["power"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["power"]["height"] = 8
    E.db["unitframe"]["units"]["player"]["power"]["powerPrediction"] = true
    E.db["unitframe"]["units"]["player"]["power"]["text_format"] = ""
    E.db["unitframe"]["units"]["player"]["pvp"]["text_format"] = ""
    E.db["unitframe"]["units"]["player"]["raidRoleIcons"]["enable"] = false
    E.db["unitframe"]["units"]["player"]["raidicon"]["attachTo"] = "LEFT"
    E.db["unitframe"]["units"]["player"]["raidicon"]["attachToObject"] = "Health"
    E.db["unitframe"]["units"]["player"]["raidicon"]["size"] = 23
    E.db["unitframe"]["units"]["player"]["raidicon"]["xOffset"] = 5
    E.db["unitframe"]["units"]["player"]["raidicon"]["yOffset"] = 0
    E.db["unitframe"]["units"]["player"]["threatStyle"] = "NONE"
    E.db["unitframe"]["units"]["player"]["width"] = 235
    E.db["unitframe"]["units"]["raidpet"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["growthDirection"] = "UP_RIGHT"
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["size"] = 13
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raidpet"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["sizeOverride"] = 20
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["yOffset"] = -21
    E.db["unitframe"]["units"]["raidpet"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["raidpet"]["height"] = 35
    E.db["unitframe"]["units"]["raidpet"]["horizontalSpacing"] = -1
    E.db["unitframe"]["units"]["raidpet"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["raidpet"]["numGroups"] = 5
    E.db["unitframe"]["units"]["raidpet"]["orientation"] = "LEFT"
    E.db["unitframe"]["units"]["raidpet"]["rdebuffs"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raidpet"]["rdebuffs"]["fontSize"] = 13
    E.db["unitframe"]["units"]["raidpet"]["rdebuffs"]["onlyMatchSpellID"] = false
    E.db["unitframe"]["units"]["raidpet"]["rdebuffs"]["yOffset"] = 5
    E.db["unitframe"]["units"]["raidpet"]["verticalSpacing"] = -1
    E.db["unitframe"]["units"]["raidpet"]["width"] = 70
    E.db["unitframe"]["units"]["tank"]["buffIndicator"]["enable"] = true
    E.db["unitframe"]["units"]["tank"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["tank"]["debuffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["tank"]["enable"] = false
    E.db["unitframe"]["units"]["tank"]["height"] = 45
    E.db["unitframe"]["units"]["tank"]["name"]["text_format"] = "[name:medium]"
    E.db["unitframe"]["units"]["tank"]["rdebuffs"]["enable"] = false
    E.db["unitframe"]["units"]["tank"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["tank"]["targetsGroup"]["enable"] = false
    E.db["unitframe"]["units"]["tank"]["threatStyle"] = "NONE"
    E.db["unitframe"]["units"]["tank"]["verticalSpacing"] = 1
    E.db["unitframe"]["units"]["tank"]["width"] = 100
    E.db["unitframe"]["units"]["target"]["aurabar"]["enable"] = false
    E.db["unitframe"]["units"]["target"]["buffs"]["attachTo"] = "DEBUFFS"
    E.db["unitframe"]["units"]["target"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["target"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["target"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["target"]["buffs"]["yOffset"] = -1
    E.db["unitframe"]["units"]["target"]["castbar"]["spark"] = false
    E.db["unitframe"]["units"]["target"]["castbar"]["height"] = 27
    E.db["unitframe"]["units"]["target"]["castbar"]["width"] = 235
    E.db["unitframe"]["units"]["target"]["castbar"]["format"] = "CURRENTMAX"
    E.db["unitframe"]["units"]["target"]["castbar"]["strataAndLevel"]["frameStrata"] = "BACKGROUND"
    E.db["unitframe"]["units"]["target"]["castbar"]["strataAndLevel"]["useCustomLevel"] = true
    E.db["unitframe"]["units"]["target"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["attachTextTo"] = "Power"
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["enable"] = true
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["size"] = 15
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["text_format"] = "[power:current]"
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["xOffset"] = 0
    E.db["unitframe"]["units"]["target"]["customTexts"]["PowerValue"]["yOffset"] = 0
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["enable"] = true
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current-percent]"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["xOffset"] = -3
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["justifyH"] = "LEFT"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["text_format"] = "[name:medium]"
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["xOffset"] = 3
    E.db["unitframe"]["units"]["target"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["target"]["buffs"]["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,CastByUnit"
    E.db["unitframe"]["units"]["target"]["debuffs"]["priority"] = "Blacklist,CCDebuffs,Friendly:nonPersonal,Personal"
    E.db["unitframe"]["units"]["target"]["debuffs"]["attachTo"] = "FRAME"
    E.db["unitframe"]["units"]["target"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["target"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["target"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["target"]["debuffs"]["yOffset"] = -1
    E.db["unitframe"]["units"]["target"]["fader"]["enable"] = false
    E.db["unitframe"]["units"]["target"]["fader"]["range"] = false
    E.db["unitframe"]["units"]["target"]["healPrediction"]["enable"] = false
    E.db["unitframe"]["units"]["target"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["target"]["height"] = 44
    E.db["unitframe"]["units"]["target"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["target"]["power"]["height"] = 7
    E.db["unitframe"]["units"]["target"]["power"]["text_format"] = ""
    E.db["unitframe"]["units"]["target"]["raidicon"]["attachTo"] = "CENTER"
    E.db["unitframe"]["units"]["target"]["raidicon"]["attachToObject"] = "Health"
    E.db["unitframe"]["units"]["target"]["raidicon"]["size"] = 23
    E.db["unitframe"]["units"]["target"]["raidicon"]["yOffset"] = 0
    E.db["unitframe"]["units"]["target"]["smartAuraPosition"] = "FLUID_BUFFS_ON_DEBUFFS"
    E.db["unitframe"]["units"]["target"]["threatStyle"] = "NONE"
    E.db["unitframe"]["units"]["target"]["width"] = 235
    E.db["unitframe"]["units"]["targettarget"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["targettarget"]["buffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["targettarget"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["enable"] = false
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["text_format"] = "[health:percent]"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["xOffset"] = -3
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["text_format"] = "[name:short]"
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["targettarget"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["attachTo"] = "FRAME"
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["countFontSize"] = 13
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["priority"] = "Blacklist,Personal,RaidDebuffs,CCDebuffs,Friendly:Dispellable"
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["targettarget"]["debuffs"]["yOffset"] = -1
    E.db["unitframe"]["units"]["targettarget"]["fader"]["enable"] = false
    E.db["unitframe"]["units"]["targettarget"]["fader"]["range"] = false
    E.db["unitframe"]["units"]["targettarget"]["height"] = 44
    E.db["unitframe"]["units"]["targettarget"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["targettarget"]["power"]["enable"] = false
    E.db["unitframe"]["units"]["targettarget"]["width"] = 120
    E.db["unitframe"]["units"]["targettargettarget"]["debuffs"]["enable"] = false
    E.db["unitframe"]["units"]["targettargettarget"]["fader"]["enable"] = false

    E.db["unitframe"]["units"]["party"]["buffIndicator"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid"]["buffIndicator"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid40"]["buffIndicator"]["countFontSize"] = 15

    -- Action Bars
    E.db["actionbar"]["bar1"]["enabled"] = true
    E.db["actionbar"]["bar2"]["enabled"] = false
    E.db["actionbar"]["bar3"]["enabled"] = true
    E.db["actionbar"]["bar4"]["enabled"] = true
    E.db["actionbar"]["bar5"]["enabled"] = true
    E.db["actionbar"]["bar6"]["enabled"] = false

    E.db["actionbar"]["bar3"]["alpha"] = 0.8
    E.db["actionbar"]["bar3"]["visibility"] = ""
    E.db["actionbar"]["bar3"]["buttons"] = 12
    E.db["actionbar"]["bar3"]["buttonspacing"] = -1
    E.db["actionbar"]["bar3"]["buttonsPerRow"] = 12
    E.db["actionbar"]["bar3"]["mouseover"] = true
    E.db["actionbar"]["bar3"]["backdropSpacing"] = 0
    E.db["actionbar"]["bar4"]["alpha"] = 0.8
    E.db["actionbar"]["bar4"]["backdrop"] = false
    E.db["actionbar"]["bar4"]["visibility"] = ""
    E.db["actionbar"]["bar4"]["buttonspacing"] = -1
    E.db["actionbar"]["bar4"]["buttonsPerRow"] = 12
    E.db["actionbar"]["bar4"]["backdropSpacing"] = 0
    E.db["actionbar"]["bar4"]["mouseover"] = true
    E.db["actionbar"]["cooldown"]["hhmmColor"]["b"] = 1
    E.db["actionbar"]["cooldown"]["hhmmColor"]["g"] = 1
    E.db["actionbar"]["cooldown"]["hhmmColor"]["r"] = 1
    E.db["actionbar"]["cooldown"]["checkSeconds"] = true
    E.db["actionbar"]["cooldown"]["mmssColor"]["b"] = 1
    E.db["actionbar"]["cooldown"]["mmssColor"]["g"] = 1
    E.db["actionbar"]["cooldown"]["mmssColor"]["r"] = 1
    E.db["actionbar"]["cooldown"]["threshold"] = -1
    E.db["actionbar"]["cooldown"]["fonts"]["enable"] = true
    E.db["actionbar"]["cooldown"]["fonts"]["font"] = "ArchivoNarrow-Bold"
    E.db["actionbar"]["cooldown"]["fonts"]["fontSize"] = 17
    E.db["actionbar"]["cooldown"]["mmssThreshold"] = 300
    E.db["actionbar"]["hotkeyTextPosition"] = "TOPLEFT"
    E.db["actionbar"]["desaturateOnCooldown"] = true
    E.db["actionbar"]["fontOutline"] = "OUTLINE"
    E.db["actionbar"]["macrotext"] = true
    E.db["actionbar"]["countTextPosition"] = "BOTTOMLEFT"
    E.db["actionbar"]["microbar"]["buttonSize"] = 16
    E.db["actionbar"]["microbar"]["buttonSpacing"] = 0
    E.db["actionbar"]["microbar"]["symbolic"] = true
    E.db["actionbar"]["microbar"]["backdropSpacing"] = 0
    E.db["actionbar"]["microbar"]["enabled"] = true
    E.db["actionbar"]["microbar"]["mouseover"] = true
    E.db["actionbar"]["microbar"]["transparentBackdrop"] = true
    E.db["actionbar"]["microbar"]["alpha"] = 0.7
    E.db["actionbar"]["transparentBackdrops"] = true
    E.db["actionbar"]["fontSize"] = 13
    E.db["actionbar"]["transparentButtons"] = true
    E.db["actionbar"]["bar2"]["enabled"] = true
    E.db["actionbar"]["bar2"]["alpha"] = 0.8
    E.db["actionbar"]["bar2"]["buttonspacing"] = -1
    E.db["actionbar"]["bar2"]["visibility"] = ""
    E.db["actionbar"]["bar2"]["mouseover"] = true
    E.db["actionbar"]["bar2"]["backdropSpacing"] = 0
    E.db["actionbar"]["bar1"]["buttonspacing"] = -1
    E.db["actionbar"]["bar1"]["alpha"] = 0.8
    E.db["actionbar"]["bar1"]["mouseover"] = true
    E.db["actionbar"]["countTextYOffset"] = 1
    E.db["actionbar"]["bar5"]["point"] = "BOTTOMRIGHT"
    E.db["actionbar"]["bar5"]["buttons"] = 12
    E.db["actionbar"]["bar5"]["buttonspacing"] = -1
    E.db["actionbar"]["bar5"]["alpha"] = 0.85
    E.db["actionbar"]["bar5"]["mouseover"] = true
    E.db["actionbar"]["bar5"]["buttonsPerRow"] = 12
    E.db["actionbar"]["bar5"]["backdropSpacing"] = 6
    E.db["actionbar"]["bar5"]["visibility"] = ""
    E.db["actionbar"]["font"] = "ArchivoNarrow-Bold"
    E.db["actionbar"]["barTotem"]["buttonsize"] = 28
    E.db["actionbar"]["barTotem"]["flyoutDirection"] = "DOWN"
    E.db["actionbar"]["barTotem"]["alpha"] = 0.6
    E.db["actionbar"]["hotkeyTextXOffset"] = 1
    E.db["actionbar"]["hotkeyTextYOffset"] = -1
    E.db["actionbar"]["stanceBar"]["enabled"] = false
    E.db["actionbar"]["stanceBar"]["point"] = "BOTTOMLEFT"
    E.db["actionbar"]["stanceBar"]["style"] = "classic"
    E.db["actionbar"]["stanceBar"]["alpha"] = 0.7
    E.db["actionbar"]["stanceBar"]["buttonsize"] = 26
    E.db["actionbar"]["barPet"]["buttonsize"] = 30
    E.db["actionbar"]["barPet"]["backdropSpacing"] = 0
    E.db["actionbar"]["barPet"]["point"] = "TOPLEFT"
    E.db["actionbar"]["barPet"]["mouseover"] = true
    E.db["actionbar"]["barPet"]["buttonspacing"] = -1
    E.db["actionbar"]["barPet"]["buttonsPerRow"] = 10
    E.db["actionbar"]["barPet"]["alpha"] = 0.8
    E.db["actionbar"]["barPet"]["backdrop"] = false
    E.db["actionbar"]["countTextXOffset"] = 1

    for i = 1, 6 do
        E.db["actionbar"]["bar"..i]["showGrid"] = false
    end

    E.db["actionbar"]["barPet"]["showGrid"] = false

    for i = 1, 6 do
        E.db["actionbar"]["bar"..i]["mouseover"] = true
    end

    E.db["actionbar"]["barPet"]["mouseover"] = true
    E.db["actionbar"]["stanceBar"]["mouseover"] = true
end

local function LoadLayoutSettingsDPS()

    -- Movers
    E.db["movers"] = E.db["movers"] or {}
    E.db["movers"]["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,-186,4"
    E.db["movers"]["ElvAB_10"] = "TOPLEFT,ElvUIParent,TOPLEFT,82,-414"
    E.db["movers"]["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,186,4"
    E.db["movers"]["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-186,35"
    E.db["movers"]["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,186,35"
    E.db["movers"]["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,186,35"
    E.db["movers"]["ElvUF_FocusCastbarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-403,-430"
    E.db["movers"]["ElvUF_FocusMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-404,-387"
    E.db["movers"]["ElvUF_FocusTargetMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-325,-400"
    E.db["movers"]["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,434,-349"
    E.db["movers"]["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,197"
    E.db["movers"]["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,434,310"
    E.db["movers"]["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,214"
    E.db["movers"]["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-285,310"
    E.db["movers"]["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,281"
    E.db["movers"]["ElvUF_Raid40Mover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,281"
    E.db["movers"]["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-403"
    E.db["movers"]["ElvUF_TankMover"] = "BOTTOM,ElvUIParent,BOTTOM,-303,49"
    E.db["movers"]["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,285,284"
    E.db["movers"]["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,285,310"
    E.db["movers"]["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-434,310"
    E.db["movers"]["ElvBar_Pet"] = "BOTTOM,ElvUIParent,BOTTOM,0,66"
    E.db["movers"]["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,0,95"
    
    -- UnitFrames
    E.db["unitframe"]["units"]["player"]["castbar"]["displayTarget"] = false
    E.db["unitframe"]["units"]["player"]["castbar"]["width"] = 335

    E.db["unitframe"]["units"]["raidpet"]["enable"] = false


    E.db["unitframe"]["units"]["raid"]["buffs"]["anchorPoint"] = "BOTTOMRIGHT"
    E.db["unitframe"]["units"]["raid"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid"]["buffs"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["buffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["buffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid"]["buffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid"]["buffs"]["yOffset"] = 17
    E.db["unitframe"]["units"]["raid"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["raid"]["customName"] = "Raid-25"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["size"] = 13
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["text_format"] = "[namecolor][dead]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["yOffset"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["text_format"] = "[namecolor][offline]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["xOffset"] = -5
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid"]["debuffs"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["debuffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid"]["debuffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid"]["debuffs"]["yOffset"] = -17
    E.db["unitframe"]["units"]["raid"]["fader"]["smooth"] = 0.1
    E.db["unitframe"]["units"]["raid"]["groupBy"] = "ROLE"
    E.db["unitframe"]["units"]["raid"]["growthDirection"] = "RIGHT_UP"
    E.db["unitframe"]["units"]["raid"]["healPrediction"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["health"]["position"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid"]["health"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["height"] = 44
    E.db["unitframe"]["units"]["raid"]["horizontalSpacing"] = -1
    E.db["unitframe"]["units"]["raid"]["infoPanel"]["height"] = 15
    E.db["unitframe"]["units"]["raid"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid"]["orientation"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["power"]["height"] = 4
    E.db["unitframe"]["units"]["raid"]["power"]["position"] = "RIGHT"
    E.db["unitframe"]["units"]["raid"]["power"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["raidRoleIcons"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["raidRoleIcons"]["yOffset"] = 3
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["fontSize"] = 13
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["onlyMatchSpellID"] = false
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["showDispellableDebuff"] = false
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["yOffset"] = 11
    E.db["unitframe"]["units"]["raid"]["readycheckIcon"]["attachTo"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["readycheckIcon"]["size"] = 20
    E.db["unitframe"]["units"]["raid"]["readycheckIcon"]["yOffset"] = 13
    E.db["unitframe"]["units"]["raid"]["roleIcon"]["damager"] = false
    E.db["unitframe"]["units"]["raid"]["roleIcon"]["healer"] = false
    E.db["unitframe"]["units"]["raid"]["verticalSpacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["buffs"]["anchorPoint"] = "BOTTOMRIGHT"
    E.db["unitframe"]["units"]["raid40"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid40"]["buffs"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["buffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["buffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid40"]["buffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid40"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["buffs"]["yOffset"] = 17
    E.db["unitframe"]["units"]["raid40"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["raid40"]["customName"] = "Raid-40"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["size"] = 13
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["text_format"] = "[namecolor][dead]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["yOffset"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["text_format"] = "[namecolor][offline]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["xOffset"] = -5
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["yOffset"] = -17
    E.db["unitframe"]["units"]["raid40"]["fader"]["smooth"] = 0.1
    E.db["unitframe"]["units"]["raid40"]["groupBy"] = "ROLE"
    E.db["unitframe"]["units"]["raid40"]["growthDirection"] = "RIGHT_UP"
    E.db["unitframe"]["units"]["raid40"]["healPrediction"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["health"]["position"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid40"]["health"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["height"] = 44
    E.db["unitframe"]["units"]["raid40"]["horizontalSpacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["infoPanel"]["height"] = 15
    E.db["unitframe"]["units"]["raid40"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid40"]["numGroups"] = 5
    E.db["unitframe"]["units"]["raid40"]["groupsPerRowCol"] = 1
    E.db["unitframe"]["units"]["raid40"]["orientation"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["power"]["height"] = 4
    E.db["unitframe"]["units"]["raid40"]["power"]["position"] = "RIGHT"
    E.db["unitframe"]["units"]["raid40"]["power"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["raidRoleIcons"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["raidRoleIcons"]["yOffset"] = 3
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["fontSize"] = 13
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["onlyMatchSpellID"] = false
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["showDispellableDebuff"] = false
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["yOffset"] = 11
    E.db["unitframe"]["units"]["raid40"]["readycheckIcon"]["attachTo"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["readycheckIcon"]["size"] = 20
    E.db["unitframe"]["units"]["raid40"]["readycheckIcon"]["yOffset"] = 13
    E.db["unitframe"]["units"]["raid40"]["verticalSpacing"] = -1
    E.db["unitframe"]["units"]["raidpet"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["height"] = 35
    E.db["unitframe"]["units"]["raidpet"]["width"] = 47
    E.db["unitframe"]["units"]["raidpet"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["height"] = 35
    E.db["unitframe"]["units"]["raidpet"]["width"] = 47
end

local function LoadLayoutSettingsHeal()

    E.db["movers"] = E.db["movers"] or {}
    E.db["movers"]["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,-186,4"
    E.db["movers"]["ElvAB_10"] = "TOPLEFT,ElvUIParent,TOPLEFT,82,-414"
    E.db["movers"]["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,186,4"
    E.db["movers"]["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-186,35"
    E.db["movers"]["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,186,35"
    E.db["movers"]["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,186,35"
    E.db["movers"]["ElvUF_FocusCastbarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-483,-448"
    E.db["movers"]["ElvUF_FocusMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-484,-405"
    E.db["movers"]["ElvUF_FocusTargetMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-406,-418"
    E.db["movers"]["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,484,-360"
    E.db["movers"]["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,197"
    E.db["movers"]["ElvUF_PetMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,402,173"
    E.db["movers"]["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,76"
    E.db["movers"]["ElvUF_PlayerMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,478,310"
    E.db["movers"]["ElvUF_RaidpetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,1207,108"
    E.db["movers"]["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,712,354"
    E.db["movers"]["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,712,354"
    E.db["movers"]["ElvUF_TankMover"] = "BOTTOM,ElvUIParent,BOTTOM,-303,49"
    E.db["movers"]["ElvUF_TargetCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-478,284"
    E.db["movers"]["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-478,310"
    E.db["movers"]["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-352,310"
    E.db["movers"]["ElvBar_Pet"] = "BOTTOM,ElvUIParent,BOTTOM,0,66"
    E.db["movers"]["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,0,95"

    E.db["unitframe"]["units"]["player"]["castbar"]["spark"] = false
    E.db["unitframe"]["units"]["player"]["castbar"]["tickWidth"] = 3
    E.db["unitframe"]["units"]["player"]["castbar"]["tickColor"]["a"] = 1
    E.db["unitframe"]["units"]["player"]["castbar"]["displayTarget"] = true
    E.db["unitframe"]["units"]["player"]["castbar"]["height"] = 33
    E.db["unitframe"]["units"]["player"]["castbar"]["format"] = "CURRENTMAX"
    E.db["unitframe"]["units"]["player"]["castbar"]["icon"] = false
    E.db["unitframe"]["units"]["player"]["castbar"]["width"] = 497

    E.db["unitframe"]["units"]["raidpet"]["enable"] = true

    E.db["unitframe"]["units"]["raid"]["buffIndicator"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid"]["buffIndicator"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["buffs"]["anchorPoint"] = "BOTTOMRIGHT"
    E.db["unitframe"]["units"]["raid"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid"]["buffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["buffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid"]["buffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid"]["buffs"]["yOffset"] = 17
    E.db["unitframe"]["units"]["raid"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["text_format"] = "[namecolor][dead]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["DeadGhostStatus"]["yOffset"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["text_format"] = "[namecolor][offline]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["OfflineStatus"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["xOffset"] = -5
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid"]["debuffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["debuffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid"]["debuffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid"]["debuffs"]["yOffset"] = -17
    E.db["unitframe"]["units"]["raid"]["fader"]["smooth"] = 0.1
    E.db["unitframe"]["units"]["raid"]["groupBy"] = "ROLE"
    E.db["unitframe"]["units"]["raid"]["healPrediction"]["enable"] = true
    E.db["unitframe"]["units"]["raid"]["health"]["position"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid"]["health"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["height"] = 50
    E.db["unitframe"]["units"]["raid"]["horizontalSpacing"] = -1
    E.db["unitframe"]["units"]["raid"]["infoPanel"]["height"] = 15
    E.db["unitframe"]["units"]["raid"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid"]["orientation"] = "LEFT"
    E.db["unitframe"]["units"]["raid"]["power"]["height"] = 4
    E.db["unitframe"]["units"]["raid"]["power"]["position"] = "RIGHT"
    E.db["unitframe"]["units"]["raid"]["power"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid"]["raidRoleIcons"]["enable"] = false
    E.db["unitframe"]["units"]["raid"]["raidRoleIcons"]["yOffset"] = 3
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["fontSize"] = 13
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["onlyMatchSpellID"] = false
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["showDispellableDebuff"] = false
    E.db["unitframe"]["units"]["raid"]["rdebuffs"]["yOffset"] = 11
    E.db["unitframe"]["units"]["raid"]["readycheckIcon"]["attachTo"] = "CENTER"
    E.db["unitframe"]["units"]["raid"]["readycheckIcon"]["size"] = 20
    E.db["unitframe"]["units"]["raid"]["readycheckIcon"]["yOffset"] = 13
    E.db["unitframe"]["units"]["raid"]["roleIcon"]["damager"] = false
    E.db["unitframe"]["units"]["raid"]["roleIcon"]["healer"] = false
    E.db["unitframe"]["units"]["raid"]["threatStyle"] = "ICONLEFT"
    E.db["unitframe"]["units"]["raid"]["verticalSpacing"] = -1
    E.db["unitframe"]["units"]["raid"]["width"] = 100
    E.db["unitframe"]["units"]["raid40"]["buffIndicator"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid40"]["buffIndicator"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["buffs"]["anchorPoint"] = "BOTTOMRIGHT"
    E.db["unitframe"]["units"]["raid40"]["buffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["buffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid40"]["buffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["buffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid40"]["buffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid40"]["buffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["buffs"]["yOffset"] = 17
    E.db["unitframe"]["units"]["raid40"]["colorOverride"] = "FORCE_ON"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["text_format"] = "[namecolor][dead]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["DeadGhostStatus"]["yOffset"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["text_format"] = "[namecolor][offline]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["OfflineStatus"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["justifyH"] = "RIGHT"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["text_format"] = "[health:current]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["xOffset"] = -5
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitHealth"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["attachTextTo"] = "Health"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["fontOutline"] = "OUTLINE"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["justifyH"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["size"] = 15
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["xOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["customTexts"]["UnitName"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["anchorPoint"] = "TOPRIGHT"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["countFont"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["countFontSize"] = 15
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["growthX"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["perrow"] = 4
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["sizeOverride"] = 17
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["spacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["debuffs"]["yOffset"] = -17
    E.db["unitframe"]["units"]["raid40"]["fader"]["smooth"] = 0.1
    E.db["unitframe"]["units"]["raid40"]["groupBy"] = "ROLE"
    E.db["unitframe"]["units"]["raid40"]["healPrediction"]["enable"] = true
    E.db["unitframe"]["units"]["raid40"]["health"]["position"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["health"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid40"]["health"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["height"] = 50
    E.db["unitframe"]["units"]["raid40"]["horizontalSpacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["infoPanel"]["height"] = 15
    E.db["unitframe"]["units"]["raid40"]["name"]["text_format"] = ""
    E.db["unitframe"]["units"]["raid40"]["numGroups"] = 5
    E.db["unitframe"]["units"]["raid40"]["orientation"] = "LEFT"
    E.db["unitframe"]["units"]["raid40"]["power"]["height"] = 4
    E.db["unitframe"]["units"]["raid40"]["power"]["position"] = "RIGHT"
    E.db["unitframe"]["units"]["raid40"]["power"]["yOffset"] = 0
    E.db["unitframe"]["units"]["raid40"]["raidRoleIcons"]["enable"] = false
    E.db["unitframe"]["units"]["raid40"]["raidRoleIcons"]["yOffset"] = 3
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["font"] = "ArchivoNarrow-Bold"
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["fontSize"] = 13
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["onlyMatchSpellID"] = false
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["showDispellableDebuff"] = false
    E.db["unitframe"]["units"]["raid40"]["rdebuffs"]["yOffset"] = 11
    E.db["unitframe"]["units"]["raid40"]["readycheckIcon"]["attachTo"] = "CENTER"
    E.db["unitframe"]["units"]["raid40"]["readycheckIcon"]["size"] = 20
    E.db["unitframe"]["units"]["raid40"]["readycheckIcon"]["yOffset"] = 13
    E.db["unitframe"]["units"]["raid40"]["threatStyle"] = "ICONLEFT"
    E.db["unitframe"]["units"]["raid40"]["verticalSpacing"] = -1
    E.db["unitframe"]["units"]["raid40"]["width"] = 100
end

local function LoadLayoutSettings(layout)

    if layout == "DPS" or layout == "Tank" then
        E.data:SetProfile('MerfinUI (DPS/Tank) v' .. GetAddOnMetadata(addon, "Version"))
        LoadLayoutSettingsGeneral()
        LoadLayoutSettingsDPS()
    elseif layout == "Healer" then
        E.data:SetProfile('MerfinUI (Healer) v' .. GetAddOnMetadata(addon, "Version"))
        LoadLayoutSettingsGeneral()
        LoadLayoutSettingsHeal()
    end 

    local unitFrames = { 'party', 'raid1', 'raid', 'raid40' }

    for _, unitFrame in ipairs(unitFrames) do
        E.db["unitframe"]["units"][unitFrame] = E.db["unitframe"]["units"][unitFrame] or {}
        E.db["unitframe"]["units"][unitFrame]["buffIndicator"] = E.db["unitframe"]["units"][unitFrame]["buffIndicator"] or {}
        E.db["unitframe"]["units"][unitFrame]["debuffs"] = E.db["unitframe"]["units"][unitFrame]["debuffs"] or {}
        E.db["unitframe"]["units"][unitFrame]["buffs"] = E.db["unitframe"]["units"][unitFrame]["buffs"] or {}
        E.db["unitframe"]["units"][unitFrame]["rdebuffs"] = E.db["unitframe"]["units"][unitFrame]["rdebuffs"] or {}

        E.db["unitframe"]["units"][unitFrame]["buffIndicator"]["enable"] = true
        E.db["unitframe"]["units"][unitFrame]["debuffs"]["enable"] = true
        E.db["unitframe"]["units"][unitFrame]["buffs"]["enable"] = true
        E.db["unitframe"]["units"][unitFrame]["rdebuffs"]["enable"] = true
    end

    E.db["unitframe"]["units"]["raidpet"]["buffIndicator"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["debuffs"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["buffs"]["enable"] = false
    E.db["unitframe"]["units"]["raidpet"]["rdebuffs"]["enable"] = false
end

local function LoadPrivateSettings()

    E.private["general"]["chatBubbleFontSize"] = 11
    E.private["general"]["chatBubbles"] = "backdrop_noborder"
    E.private["general"]["namefont"] = "ArchivoNarrow-Bold"
    E.private["general"]["normTex"] = "Flatt"
    E.private["general"]["glossTex"] = "Flatt"
    E.private["general"]["chatBubbleFont"] = "ArchivoNarrow-Bold"
    E.private["general"]["chatBubbleName"] = true
    E.private["general"]["dmgfont"] = "ArchivoNarrow-Bold"
    
    E.private["nameplates"]["enable"] = false

    if E.private["CustomTweaks"] then
        E.private["CustomTweaks"]["CastbarFont"] = false
        E.private["CustomTweaks"]["BagButtons"] = true
        E.private["CustomTweaks"]["RaidControl"] = true
        E.private["CustomTweaks"]["AuraIconSpacing"] = true
        E.private["CustomTweaks"]["CastbarText"] = false
    end

    if E.private["enhanced"] then
        E.private["enhanced"]["deathRecap"] = true
        E.private["enhanced"]["character"] = E.private["enhanced"]["character"] or {}
        E.private["enhanced"]["character"]["modelFrames"] = true
        E.private["enhanced"]["character"]["player"] = E.private["enhanced"]["character"]["player"] or {}
        E.private["enhanced"]["character"]["player"]["orderName2"] = ""
        E.private["enhanced"]["character"]["player"]["collapsedName1"] = E.private["enhanced"]["character"]["player"]["collapsedName1"] or {}
        E.private["enhanced"]["character"]["player"]["collapsedName"]["MELEE_COMBAT"] = true
        E.private["enhanced"]["character"]["player"]["collapsedName"]["RANGED_COMBAT"] = true
        E.private["enhanced"]["character"]["player"]["collapsedName2"] = E.private["enhanced"]["character"]["player"]["collapsedName2"] or {}
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["DEFENSES"] = false
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["RANGED_COMBAT"] = false
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["ITEM_LEVEL"] = false
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["RESISTANCE"] = false
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["SPELL_COMBAT"] = false
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["MELEE_COMBAT"] = false
        E.private["enhanced"]["character"]["player"]["collapsedName2"]["BASE_STATS"] = false
        E.private["enhanced"]["character"]["enable"] = true
        E.private["enhanced"]["actionbar"]["keyPressAnimation"] = true
        E.private["enhanced"]["minimapButtonGrabber"] = true
        E.private["enhanced"]["animatedAchievementBars"] = true
    end
end

local function LoadDBSettings()

    --E.db["hideTutorial"] = 1
    --E.db["currentTutorial"] = 7

end

local function LoadPluginSettings()
    
    local plugins = {
        ["AddOnSkins"] = IsAddOnLoaded("ElvUI_AddOnSkins"),
        ["Enhanced"] = IsAddOnLoaded("ElvUI_Enhanced"),
        ["Custom Tweaks"] = IsAddOnLoaded("ElvUI_CustomTweaks"),
        ["Enhanced Frienst List"] = IsAddOnLoaded("ElvUI_EnhancedFriendsList"),
        ["DataText Bar 2"] = IsAddOnLoaded("ElvUI_DTBars2"),
        ["DataText Colors"] = IsAddOnLoaded("ElvUI_DataTextColors"),
        ["Custom Tags"] = IsAddOnLoaded("ElvUI_CustomTags"),
    }

    if plugins["AddOnSkins"] then
        E.db["addOnSkins"]["dbmTemplate"] = "Transparent"
        E.db["addOnSkins"]["dbmFontOutline"] = "NONE"
        E.db["addOnSkins"]["dbmFont"] = "ArchivoNarrow-Bold"
        E.db["addOnSkins"]["skadaTitleTemplate"] = "Transparent"
        E.db["addOnSkins"]["dbmBarHeight"] = 27
        E.db["addOnSkins"]["dbmFontSize"] = 13
        E.db["addOnSkins"]["skadaTemplate"] = "Transparent"
        E.db["addOnSkins"]["omenTemplateGloss"] = true
        E.db["addOnSkins"]["embed"]["rightWindow"] = "Omen"
        E.db["addOnSkins"]["embed"]["leftWindowWidth"] = 190
        E.db["addOnSkins"]["embed"]["leftWindow"] = "Skada"
        E.db["addOnSkins"]["skadaTemplateGloss"] = true
    end
    
    if plugins["DataText Bar 2"] then
        E.db["dtbars"] = E.db["dtbars"] or {}
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"] = E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"] or {}
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"] = E.db["dtbars"]["DTB2_DBT2_RightBottomBar"] or {}

        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["enable"] = true
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["growth"] = "HORIZONTAL"
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["width"] = 396
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["combatHide"] = false
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["transparent"] = true
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["height"] = 22
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["mouseover"] = false
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["vehicleHide"] = false
        E.db["dtbars"]["DTB2_DBT2_LeftBottomBar"]["border"] = true
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["enable"] = true
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["growth"] = "HORIZONTAL"
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["width"] = 232
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["combatHide"] = false
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["transparent"] = true
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["height"] = 22
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["mouseover"] = false
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["vehicleHide"] = false
        E.db["dtbars"]["DTB2_DBT2_RightBottomBar"]["border"] = true

    end

    if plugins["Custom Tweaks"] then
        E.db["CustomTweaks"]["CastbarFont"]["Player"]["text"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Player"]["text"]["fontSize"] = 15
        E.db["CustomTweaks"]["CastbarFont"]["Player"]["text"]["fontOutline"] = "OUTLINE"
        E.db["CustomTweaks"]["CastbarFont"]["Player"]["duration"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Player"]["duration"]["fontSize"] = 15
        E.db["CustomTweaks"]["CastbarFont"]["Player"]["duration"]["fontOutline"] = "OUTLINE"
        E.db["CustomTweaks"]["CastbarFont"]["Focus"]["text"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Focus"]["text"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Focus"]["text"]["fontOutline"] = "OUTLINE"
        E.db["CustomTweaks"]["CastbarFont"]["Focus"]["duration"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Focus"]["duration"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Focus"]["duration"]["fontOutline"] = "OUTLINE"
        E.db["CustomTweaks"]["CastbarFont"]["Target"]["text"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Target"]["text"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Target"]["text"]["fontOutline"] = "OUTLINE"
        E.db["CustomTweaks"]["CastbarFont"]["Target"]["duration"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Target"]["duration"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Target"]["duration"]["fontOutline"] = "OUTLINE"
        E.db["CustomTweaks"]["CastbarFont"]["Arena"]["text"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Arena"]["text"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Arena"]["text"]["fontOutline"] = "NONE"
        E.db["CustomTweaks"]["CastbarFont"]["Arena"]["duration"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Arena"]["duration"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Arena"]["duration"]["fontOutline"] = "NONE"
        E.db["CustomTweaks"]["CastbarFont"]["Pet"]["text"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Pet"]["text"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Pet"]["text"]["fontOutline"] = "NONE"
        E.db["CustomTweaks"]["CastbarFont"]["Pet"]["duration"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Pet"]["duration"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Pet"]["duration"]["fontOutline"] = "NONE"
        E.db["CustomTweaks"]["CastbarFont"]["Boss"]["text"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Boss"]["text"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Boss"]["text"]["fontOutline"] = "NONE"
        E.db["CustomTweaks"]["CastbarFont"]["Boss"]["duration"]["font"] = "ArchivoNarrow-Bold"
        E.db["CustomTweaks"]["CastbarFont"]["Boss"]["duration"]["fontSize"] = 13
        E.db["CustomTweaks"]["CastbarFont"]["Boss"]["duration"]["fontOutline"] = "NONE"
        E.db["CustomTweaks"]["AuraIconSpacing"]["units"]["party"] = false
        E.db["CustomTweaks"]["AuraIconSpacing"]["units"]["raid"] = false
        E.db["CustomTweaks"]["AuraIconSpacing"]["units"]["raid40"] = false
        E.db["CustomTweaks"]["AuraIconSpacing"]["units"]["raidpet"] = false
        E.db["CustomTweaks"]["AuraIconSpacing"]["spacing"] = -1
        E.db["CustomTweaks"]["BagButtons"]["stackButton"] = true
        E.db["CustomTweaks"]["RaidControl"]["hide"] = true
        E.db["CustomTweaks"]["CastbarText"]["Player"]["text"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Player"]["text"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Player"]["text"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Player"]["duration"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Player"]["duration"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Player"]["duration"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Focus"]["text"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Focus"]["text"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Focus"]["text"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Focus"]["duration"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Focus"]["duration"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Focus"]["duration"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Target"]["text"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Target"]["text"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Target"]["text"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Target"]["duration"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Target"]["duration"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Target"]["duration"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Arena"]["text"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Arena"]["text"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Arena"]["text"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Arena"]["duration"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Arena"]["duration"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Arena"]["duration"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Pet"]["text"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Pet"]["text"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Pet"]["text"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Pet"]["duration"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Pet"]["duration"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Pet"]["duration"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Boss"]["text"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Boss"]["text"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Boss"]["text"]["color"]["r"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Boss"]["duration"]["color"]["b"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Boss"]["duration"]["color"]["g"] = 1
        E.db["CustomTweaks"]["CastbarText"]["Boss"]["duration"]["color"]["r"] = 1
    end

    if plugins["Enhanced Frienst List"] then
        E.db["enhanceFriendsList"]["nameFontSize"] = 13
        E.db["enhanceFriendsList"]["Online"]["enhancedName"] = true
        E.db["enhanceFriendsList"]["Online"]["colorizeNameOnly"] = true
        E.db["enhanceFriendsList"]["Online"]["sameZone"] = true
        E.db["enhanceFriendsList"]["Online"]["enhancedZone"] = true
        E.db["enhanceFriendsList"]["Online"]["shortLevel"] = true
        E.db["enhanceFriendsList"]["Online"]["classIcon"] = true
        E.db["enhanceFriendsList"]["zoneFontSize"] = 13
        E.db["enhanceFriendsList"]["nameFont"] = "ArchivoNarrow-Bold"
        E.db["enhanceFriendsList"]["Offline"]["enhancedName"] = true
        E.db["enhanceFriendsList"]["Offline"]["classIcon"] = true
        E.db["enhanceFriendsList"]["showStatusIcon"] = false
        E.db["enhanceFriendsList"]["zoneFont"] = "ArchivoNarrow-Bold"
    end

    if plugins["Enhanced"] then
        E.db["enhanced"]["map"]["fogClear"]["enable"] = true
        E.db["enhanced"]["general"]["trainAllSkills"] = true
        E.db["enhanced"]["general"]["showQuestLevel"] = true
        E.db["enhanced"]["general"]["altBuyMaxStack"] = true
        E.db["enhanced"]["general"]["hideZoneText"] = true
        E.db["enhanced"]["character"]["desaturateCharacter"] = true
        E.db["enhanced"]["character"]["desaturateInspect"] = true
        E.db["enhanced"]["character"]["companionBackground"] = true
        E.db["enhanced"]["character"]["inspectBackground"] = true
        E.db["enhanced"]["character"]["characterBackground"] = true
        E.db["enhanced"]["character"]["desaturateCompanion"] = true
        E.db["enhanced"]["character"]["petBackground"] = true
        E.db["enhanced"]["character"]["animations"] = true
        E.db["enhanced"]["blizzard"]["takeAllMail"] = true
        E.db["enhanced"]["tooltip"]["itemQualityBorderColor"] = true
        E.db["enhanced"]["tooltip"]["tooltipIcon"]["enable"] = true
        E.db["enhanced"]["loseControl"]["compactMode"] = true
        E.db["enhanced"]["loseControl"]["Root"] = true
        E.db["enhanced"]["loseControl"]["Snare"] = true
        E.db["enhanced"]["chat"]["dpsLinks"] = true
        E.db["enhanced"]["equipment"]["font"] = "ArchivoNarrow-Bold"
        E.db["enhanced"]["equipment"]["fontOutline"] = "OUTLINE"
        E.db["enhanced"]["equipment"]["enable"] = true
        E.db["enhanced"]["equipment"]["fontSize"] = 13
        E.db["enhanced"]["actionbar"]["keyPressAnimation"]["scale"] = 1
        E.db["enhanced"]["minimap"]["location"] = true
        E.db["enhanced"]["minimap"]["buttonGrabber"]["mouseover"] = true
        E.db["enhanced"]["minimap"]["buttonGrabber"]["buttonsPerRow"] = 10
        E.db["enhanced"]["minimap"]["buttonGrabber"]["buttonSpacing"] = -1
        E.db["enhanced"]["minimap"]["buttonGrabber"]["insideMinimap"]["xOffset"] = 0
        E.db["enhanced"]["minimap"]["buttonGrabber"]["insideMinimap"]["yOffset"] = 0
        E.db["enhanced"]["minimap"]["buttonGrabber"]["insideMinimap"]["position"] = "BOTTOMRIGHT"
    end

    local chat_error_msg = false
    for pluginName, enabled in pairs(plugins) do
        if not enabled then
            if not chat_error_msg then
                chat_error_msg = string.format("Couldn't find next plugins: |cff00c3ff%s|r", pluginName)
            else
                chat_error_msg = string.format("%s, |cff00c3ff%s|r", chat_error_msg, pluginName)
            end
        end
    end

    if chat_error_msg then
        chat_error_msg = string.format("%s. Please, download and enable them in-game. After that re-install the layout again to get all the features!", chat_error_msg)
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000MerfinUI Installation:|r")
        DEFAULT_CHAT_FRAME:AddMessage(chat_error_msg)
    end

end

local function LoadGlobalSettings()

    LoadFilters()

    E.global["unitframe"]["raidDebuffIndicator"] = {
        ["otherFilter"] = "Debuff Indicators",
        ["instanceFilter"] = "Debuff Indicators",
    }

    E.global["dtbarsSetup"] = E.global["dtbarsSetup"] or {}
    E.global["dtbarsSetup"]["strata"] = "HIGH"
    E.global["dtbarsSetup"]["name"] = "DBT2_RightBottomBar"
    E.global["dtbarsSetup"]["transparent"] = true
    E.global["dtbarsSetup"]["width"] = 380
    E.global["dtbarsSetup"]["slots"] = 2
    E.global["dtbarsSetup"]["advanced"] = true

    E.global["dtbars"] = E.global["dtbars"] or {}
    E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"] = E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"] or {}
    E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"]["strata"] = "HIGH"
    E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"]["point"] = "CENTER"
    E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"]["anchor"] = "CENTER"
    E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"]["slots"] = 2
    E.global["dtbars"]["DTB2_DBT2_LeftBottomBar"]["hide"] = false
    E.global["dtbars"]["DTB2_DBT2_RightBottomBar"] = E.global["dtbars"]["DTB2_DBT2_RightBottomBar"] or {}
    E.global["dtbars"]["DTB2_DBT2_RightBottomBar"]["strata"] = "HIGH"
    E.global["dtbars"]["DTB2_DBT2_RightBottomBar"]["point"] = "CENTER"
    E.global["dtbars"]["DTB2_DBT2_RightBottomBar"]["anchor"] = "CENTER"
    E.global["dtbars"]["DTB2_DBT2_RightBottomBar"]["slots"] = 2
    E.global["dtbars"]["DTB2_DBT2_RightBottomBar"]["hide"] = false
end

local function DKClassColorFix()
    if ClassColorsDB then
        ClassColorsDB["DEATHKNIGHT"] = {
            ["b"] = 0.2509803921568627,
            ["colorStr"] = "ffff3f3f",
            ["g"] = 0.2509803921568627,
            ["r"] = 1,
        }
    end
end

function MUI_t:ABMouseover(mouseover)

    for i = 1, 6 do
        E.db["actionbar"]["bar"..i]["mouseover"] = mouseover
    end

    E.db["actionbar"]["barPet"]["mouseover"] = mouseover
    --E.db["actionbar"]["microbar"]["mouseover"] = mouseover
    E.db["actionbar"]["stanceBar"]["mouseover"] = mouseover
    E.db["general"]["totems"] = E.db["general"]["totems"] or {}
    E.db["general"]["totems"]["mouseover"] = mouseover
    E:UpdateAll(true)
end

function MUI_t:SetElvTheme(theme)

    local groupFrames = { 'party', 'raid', 'raid40', 'boss' }
    local individualFrames = { 'targettarget', 'focus', 'focustarget' }

    if theme == 'DARK' then

        for unitFrame in pairs(E.db["unitframe"]["units"]) do
            E.db["unitframe"]["units"][unitFrame]["colorOverride"] = "FORCE_OFF"
        end
    
        E.db["unitframe"]["colors"]["useDeadBackdrop"] = true

        E.db["unitframe"]["colors"]["health"]["b"] = 0.22352941176471
        E.db["unitframe"]["colors"]["health"]["g"] = 0.22352941176471
        E.db["unitframe"]["colors"]["health"]["r"] = 0.25098039215686
        E.db["unitframe"]["colors"]["health_backdrop"]["b"] = 0.69803921568627
        E.db["unitframe"]["colors"]["health_backdrop"]["g"] = 0.69803921568627
        E.db["unitframe"]["colors"]["health_backdrop"]["r"] = 0.83137254901961
        E.db["unitframe"]["colors"]["health_backdrop_dead"]["b"] = 0.25098039215686
        E.db["unitframe"]["colors"]["health_backdrop_dead"]["g"] = 0.25098039215686
        E.db["unitframe"]["colors"]["health_backdrop_dead"]["r"] = 1

        for _, groupFrame in ipairs(groupFrames) do
            if E.db["unitframe"]["units"][groupFrame]["customTexts"] then
                if E.db["unitframe"]["units"][groupFrame]["customTexts"]["UnitName"] then
                    E.db["unitframe"]["units"][groupFrame]["customTexts"]["UnitName"]["text_format"] = "[namecolor][name:veryshort]"
                end
            end
        end

        for _, individualFrame in ipairs(individualFrames) do
            if E.db["unitframe"]["units"][individualFrame]["customTexts"] then
                if E.db["unitframe"]["units"][individualFrame]["customTexts"]["UnitName"] then
                    E.db["unitframe"]["units"][individualFrame]["customTexts"]["UnitName"]["text_format"] = "[namecolor][name:medium]"
                end
            end
        end

        MUI_t:PluginInstallStepComplete("Dark Theme Applied")

    elseif theme == 'NORMAL' then

        for unitFrame in pairs(E.db["unitframe"]["units"]) do
            E.db["unitframe"]["units"][unitFrame]["colorOverride"] = "FORCE_ON"
        end

        E.db["unitframe"]["colors"]["useDeadBackdrop"] = false
    
        E.db["unitframe"]["colors"]["health"]["b"] = 0.17254901960784
        E.db["unitframe"]["colors"]["health"]["g"] = 0.17254901960784
        E.db["unitframe"]["colors"]["health"]["r"] = 0.1921568627451
        E.db["unitframe"]["colors"]["health_backdrop"]["b"] = 0.12549019607843
        E.db["unitframe"]["colors"]["health_backdrop"]["g"] = 0.12549019607843
        E.db["unitframe"]["colors"]["health_backdrop"]["r"] = 0.14901960784314
        E.db["unitframe"]["colors"]["health_backdrop_dead"]["b"] = 0.46274509803922
        E.db["unitframe"]["colors"]["health_backdrop_dead"]["g"] = 0.46274509803922
        E.db["unitframe"]["colors"]["health_backdrop_dead"]["r"] = 0.51764705882353

        for _, groupFrame in ipairs(groupFrames) do
            if E.db["unitframe"]["units"][groupFrame]["customTexts"]["UnitName"] then 
                E.db["unitframe"]["units"][groupFrame]["customTexts"]["UnitName"]["text_format"] = "[name:veryshort]"
            end
        end

        for _, groupFrame in ipairs(individualFrames) do
            if E.db["unitframe"]["units"][groupFrame]["customTexts"]["UnitName"] then
                E.db["unitframe"]["units"][groupFrame]["customTexts"]["UnitName"]["text_format"] = "[name:medium]"
            end
        end

        MUI_t:PluginInstallStepComplete("Normal Theme Applied")

    end

    E:UpdateAll(true)
end

function MUI_t:ImportElvUI(layout)
    LoadGlobalSettings()
    LoadPrivateSettings()
    LoadDBSettings()

    LoadLayoutSettings(layout)

    LoadNameplateSettings()
    LoadPluginSettings()
    DKClassColorFix()

    E:UpdateAll(true)
    MUI_t:PluginInstallStepComplete(string.format("%s Layout", layout))
end