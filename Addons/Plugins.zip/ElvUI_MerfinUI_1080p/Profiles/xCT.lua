local addon, MUI_t = ...
local E = MUI_t[1]

function MUI_t:Import_xCT(layout)
    if IsAddOnLoaded("xCT+") then
        local profile_name = string.format("%s - %s", UnitName("player"), GetRealmName("player"))

        xCTSavedDB["profiles"] = xCTSavedDB["profiles"] or {}
        xCTSavedDB["profileKeys"] = xCTSavedDB["profileKeys"] or {}

		local newProfileName

		if layout == "DPS" or layout == "Tank" then
			newProfileName = 'MerfinUI (DPS/Tank) v' .. GetAddOnMetadata(addon, "Version")
			xCTSavedDB["profiles"][newProfileName] = {
				["spells"] = {
					["mergeDontMergeCriticals"] = false,
					["mergeCriticalsByThemselves"] = true,
					["items"] = {
						["Quiver"] = {
							["Quiver"] = false,
							["Ammo Pouch"] = false,
						},
						["Weapon"] = {
							["One-Handed Axes"] = false,
							["One-Handed Swords"] = false,
							["Staves"] = false,
							["Crossbows"] = false,
							["Polearms"] = false,
							["One-Handed Maces"] = false,
							["Bows"] = false,
							["Two-Handed Swords"] = false,
							["Miscellaneous"] = false,
							["Fishing Poles"] = false,
							["Daggers"] = false,
							["Guns"] = false,
							["Fist Weapons"] = false,
							["Thrown"] = false,
							["Wands"] = false,
							["Two-Handed Maces"] = false,
							["Two-Handed Axes"] = false,
						},
						["Glyph"] = {
							["Warrior"] = false,
							["Paladin"] = false,
							["Shaman"] = false,
							["Rogue"] = false,
							["Mage"] = false,
							["Warlock"] = false,
							["Priest"] = false,
							["Hunter"] = false,
							["Death Knight"] = false,
							["Druid"] = false,
						},
						["Trade Goods"] = {
							["Other"] = false,
							["Elemental"] = false,
							["Herb"] = false,
							["Jewelcrafting"] = false,
							["Metal & Stone"] = false,
							["Parts"] = false,
							["Devices"] = false,
							["Leather"] = false,
							["Armor Enchantment"] = false,
							["Explosives"] = false,
							["Enchanting"] = false,
							["Cloth"] = false,
							["Materials"] = false,
							["Meat"] = false,
							["Weapon Enchantment"] = false,
						},
						["Miscellaneous"] = {
							["Other"] = false,
							["Reagent"] = false,
							["Mount"] = false,
							["Holiday"] = false,
							["Pet"] = false,
							["Junk"] = false,
						},
						["Recipe"] = {
							["Inscription"] = false,
							["Blacksmithing"] = false,
							["Alchemy"] = false,
							["First Aid"] = false,
							["Book"] = false,
							["Cooking"] = false,
							["Jewelcrafting"] = false,
							["Fishing"] = false,
							["Engineering"] = false,
							["Leatherworking"] = false,
							["Tailoring"] = false,
							["Enchanting"] = false,
						},
						["Consumable"] = {
							["Other"] = false,
							["Elixir"] = false,
							["Potion"] = false,
							["Item Enhancement"] = false,
							["Scroll"] = false,
							["Flask"] = false,
							["Bandage"] = false,
							["Food & Drink"] = false,
						},
						["Gem"] = {
							["Simple"] = false,
							["Blue"] = false,
							["Meta"] = false,
							["Prismatic"] = false,
							["Purple"] = false,
							["Green"] = false,
							["Yellow"] = false,
							["Orange"] = false,
							["Red"] = false,
						},
						["version"] = 1,
						["Armor"] = {
							["Totems"] = false,
							["Shields"] = false,
							["Librams"] = false,
							["Miscellaneous"] = false,
							["Leather"] = false,
							["Idols"] = false,
							["Mail"] = false,
							["Plate"] = false,
							["Cloth"] = false,
							["Sigils"] = false,
						},
						["Projectile"] = {
							["Arrow"] = false,
							["Bullet"] = false,
						},
						["Quest"] = {
							["Quest"] = false,
						},
						["Container"] = {
							["Bag"] = false,
							["Mining Bag"] = false,
							["Soul Bag"] = false,
							["Gem Bag"] = false,
							["Engineering Bag"] = false,
							["Herb Bag"] = false,
							["Inscription Bag"] = false,
							["Leatherworking Bag"] = false,
							["Enchanting Bag"] = false,
						},
					},
					["merge"] = {
						[56488] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3.5,
							["class"] = "ITEM",
							["desc"] = "Global Sapper Charge (Explosion)",
						},
						[54968] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 1,
							["class"] = "PALADIN",
						},
						[33763] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[11366] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53595] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[42931] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55262] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53365] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 4,
						},
						[980] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55536] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[2812] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "PALADIN",
						},
						[53385] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "PALADIN",
						},
						[52000] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[58735] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[27086] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 4,
						},
						[61291] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[61295] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[56350] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 5,
							["class"] = "ITEM",
							["desc"] = "Saronite Bomb (Explosion)",
						},
						[47468] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 4,
						},
						[31803] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 6,
							["class"] = "PALADIN",
						},
						[43813] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[27243] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[47893] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 10,
						},
						[49941] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[1449] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[20153] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53652] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[47818] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 6,
						},
						[47822] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[20167] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[47834] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[33745] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[54172] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[71829] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "ITEM",
							["desc"] = "Arctic Cold (Valithria trash Mind controlled mob)",
						},
						[348] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[71904] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3.5,
							["class"] = "ITEM",
							["desc"] = "Chaos Bane (Shadowmourne)",
						},
						[20187] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[42917] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[42921] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42925] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 4,
						},
						[53190] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.8,
						},
						[44457] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[44461] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[52212] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42945] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[69766] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "ITEM",
							["desc"] = "Unchained Magic (Sindragosa)",
						},
						[48445] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[64801] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[49184] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[53227] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[48819] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 8,
							["class"] = "PALADIN",
						},
						[8936] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[48438] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[774] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55050] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[63106] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[62078] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[72672] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "ITEM",
							["desc"] = "Mutated Plague (Putricide)",
						},
						[172] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[54181] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55459] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[55078] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42463] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[25504] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[52042] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 4,
						},
						[31935] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[50526] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[5570] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[47994] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[50288] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[8921] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42926] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 4,
						},
						[8050] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[30294] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42938] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55095] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[20267] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 5,
							["class"] = "PALADIN",
						},
						[42950] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[61654] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[1822] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[49271] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[48466] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[50590] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 11,
						},
						[48562] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[1079] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 2,
						},
						[50475] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[61840] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[12654] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[59159] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[30108] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[61290] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[20424] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 1,
							["class"] = "PALADIN",
						},
						[47857] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
					},
				},
				["frames"] = {
					["general"] = {
						["fontSize"] = 15,
						["showBuffs"] = false,
						["showDispells"] = false,
						["showPartyKills"] = false,
						["showDebuffs"] = false,
						["Y"] = 385,
						["font"] = "ArchivoNarrow-Bold",
						["colors"] = {
							["dispells"] = {
								["colors"] = {
									["dispellBuffs"] = {
										["color"] = {
											0, -- [1]
											1, -- [2]
											0.5, -- [3]
										},
									},
									["dispellStolen"] = {
										["color"] = {
											0.31, -- [1]
											0.71, -- [2]
											1, -- [3]
										},
									},
									["dispellDebuffs"] = {
										["color"] = {
											1, -- [1]
											0, -- [2]
											0.5, -- [3]
										},
									},
								},
							},
							["lowResources"] = {
								["colors"] = {
									["lowResourcesMana"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
									["lowResourcesHealth"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["combat"] = {
								["colors"] = {
									["combatLeaving"] = {
										["color"] = {
											0.1, -- [1]
											1, -- [2]
											0.1, -- [3]
										},
									},
									["combatEntering"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["interrupts"] = {
								["color"] = {
									1, -- [1]
									0.5, -- [2]
									0, -- [3]
								},
							},
							["reputation"] = {
								["colors"] = {
									["reputationGain"] = {
										["color"] = {
											0.1, -- [1]
											0.1, -- [2]
											1, -- [3]
										},
									},
									["reputationLoss"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["killingBlow"] = {
								["color"] = {
									0.2, -- [1]
									1, -- [2]
									0.2, -- [3]
								},
							},
							["honorGains"] = {
								["color"] = {
									0.1, -- [1]
									0.1, -- [2]
									1, -- [3]
								},
							},
							["auras"] = {
								["colors"] = {
									["debuffsGained"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
									["buffsGained"] = {
										["color"] = {
											1, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["buffsFaded"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["debuffsFaded"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
								},
							},
						},
						["showHonorGains"] = false,
						["showInterrupts"] = false,
						["showRepChanges"] = false,
						["showLowManaHealth"] = false,
					},
					["power"] = {
						["enabledFrame"] = false,
					},
					["healing"] = {
						["enableRealmNames"] = false,
						["fontSize"] = 13,
						["enabledFrame"] = false,
						["Y"] = 213,
						["X"] = -403,
						["colors"] = {
							["healingTakenCritical"] = {
								["color"] = {
									0.1, -- [1]
									1, -- [2]
									0.1, -- [3]
								},
							},
							["healingTaken"] = {
								["color"] = {
									0.1, -- [1]
									0.75, -- [2]
									0.1, -- [3]
								},
							},
							["shieldTaken"] = {
								["color"] = {
									0.6, -- [1]
									0.65, -- [2]
									1, -- [3]
								},
							},
							["healingTakenPeriodic"] = {
								["color"] = {
									0.1, -- [1]
									0.5, -- [2]
									0.1, -- [3]
								},
							},
						},
						["font"] = "ArchivoNarrow-Bold",
					},
					["outgoing"] = {
						["fontSize"] = 16,
						["insertText"] = "top",
						["Width"] = 186,
						["Y"] = -339,
						["font"] = "Hooge",
						["colors"] = {
							["misstypesOut"] = {
								["color"] = {
									0.5, -- [1]
									0.5, -- [2]
									0.5, -- [3]
								},
							},
							["healingSpells"] = {
								["colors"] = {
									["healingOutPeriodic"] = {
										["color"] = {
											0.1, -- [1]
											0.5, -- [2]
											0.1, -- [3]
										},
									},
									["shieldOut"] = {
										["color"] = {
											0.6, -- [1]
											0.65, -- [2]
											1, -- [3]
										},
									},
									["healingOut"] = {
										["color"] = {
											0.1, -- [1]
											0.75, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["spellSchools"] = {
								["colors"] = {
									["SpellSchool_Nature"] = {
										["color"] = {
											0.3, -- [1]
											1, -- [2]
											0.3, -- [3]
										},
									},
									["SpellSchool_Arcane"] = {
										["color"] = {
											1, -- [1]
											0.5, -- [2]
											1, -- [3]
										},
									},
									["SpellSchool_Frost"] = {
										["color"] = {
											0.5, -- [1]
											1, -- [2]
											1, -- [3]
										},
									},
									["SpellSchool_Fire"] = {
										["color"] = {
											1, -- [1]
											0.5, -- [2]
											0, -- [3]
										},
									},
									["SpellSchool_Shadow"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											1, -- [3]
										},
									},
									["SpellSchool_Holy"] = {
										["color"] = {
											1, -- [1]
											0.9, -- [2]
											0.5, -- [3]
										},
									},
									["SpellSchool_Physical"] = {
										["color"] = {
											1, -- [1]
											1, -- [2]
											0, -- [3]
										},
									},
								},
							},
							["genericDamage"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
						},
						["Height"] = 147,
						["X"] = 309,
					},
					["critical"] = {
						["fontSize"] = 16,
						["secondaryFrame"] = 2,
						["enabledFrame"] = false,
						["insertText"] = "top",
						["Y"] = -358,
						["X"] = 411,
						["colors"] = {
							["genericDamageCritical"] = {
								["color"] = {
									1, -- [1]
									1, -- [2]
									0, -- [3]
								},
							},
							["healingSpells"] = {
								["colors"] = {
									["healingOutCritical"] = {
										["color"] = {
											0.1, -- [1]
											1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
						},
						["font"] = "Hooge",
					},
					["procs"] = {
						["enabledFrame"] = false,
						["colors"] = {
							["spellReactive"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
							["spellProc"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
						},
					},
					["loot"] = {
						["enabledFrame"] = false,
					},
					["class"] = {
						["colors"] = {
							["comboPoints"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
							["comboPointsMax"] = {
								["color"] = {
									0, -- [1]
									0.82, -- [2]
									1, -- [3]
								},
							},
						},
						["enabledFrame"] = false,
					},
					["damage"] = {
						["fontSize"] = 15,
						["Width"] = 160,
						["Y"] = -336,
						["font"] = "ArchivoNarrow-Bold",
						["colors"] = {
							["missTypesTaken"] = {
								["colors"] = {
									["missTypeBlock"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeMiss"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeReflect"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeDeflect"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeParry"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeEvade"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeResist"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeAbsorb"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeDodge"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeImmune"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
								},
							},
							["damageTakenCritical"] = {
								["color"] = {
									1, -- [1]
									0.1, -- [2]
									0.1, -- [3]
								},
							},
							["spellDamageTaken"] = {
								["enabled"] = true,
								["color"] = {
									0.75, -- [1]
									0.3, -- [2]
									0.85, -- [3]
								},
							},
							["damageTaken"] = {
								["enabled"] = true,
								["color"] = {
									0.75, -- [1]
									0.1, -- [2]
									0.1, -- [3]
								},
							},
							["spellDamageTakenCritical"] = {
								["color"] = {
									0.75, -- [1]
									0.3, -- [2]
									0.85, -- [3]
								},
							},
						},
						["Height"] = 140,
						["showDodgeParryMiss"] = false,
						["X"] = -321,
					},
				},
			}
			xCTSavedDB["profileKeys"][profile_name] = newProfileName
		elseif layout == "Healer" then
			newProfileName = 'MerfinUI (Heal) v' .. GetAddOnMetadata(addon, "Version")
			xCTSavedDB["profiles"][newProfileName] = {
				["spells"] = {
					["mergeDontMergeCriticals"] = false,
					["mergeCriticalsByThemselves"] = true,
					["items"] = {
						["Quiver"] = {
							["Quiver"] = false,
							["Ammo Pouch"] = false,
						},
						["Container"] = {
							["Bag"] = false,
							["Mining Bag"] = false,
							["Soul Bag"] = false,
							["Gem Bag"] = false,
							["Engineering Bag"] = false,
							["Herb Bag"] = false,
							["Inscription Bag"] = false,
							["Leatherworking Bag"] = false,
							["Enchanting Bag"] = false,
						},
						["Quest"] = {
							["Quest"] = false,
						},
						["Trade Goods"] = {
							["Other"] = false,
							["Elemental"] = false,
							["Weapon Enchantment"] = false,
							["Jewelcrafting"] = false,
							["Meat"] = false,
							["Explosives"] = false,
							["Devices"] = false,
							["Leather"] = false,
							["Armor Enchantment"] = false,
							["Materials"] = false,
							["Enchanting"] = false,
							["Cloth"] = false,
							["Parts"] = false,
							["Metal & Stone"] = false,
							["Herb"] = false,
						},
						["Miscellaneous"] = {
							["Other"] = false,
							["Reagent"] = false,
							["Mount"] = false,
							["Holiday"] = false,
							["Pet"] = false,
							["Junk"] = false,
						},
						["Recipe"] = {
							["Inscription"] = false,
							["Blacksmithing"] = false,
							["Alchemy"] = false,
							["First Aid"] = false,
							["Book"] = false,
							["Cooking"] = false,
							["Jewelcrafting"] = false,
							["Tailoring"] = false,
							["Engineering"] = false,
							["Leatherworking"] = false,
							["Fishing"] = false,
							["Enchanting"] = false,
						},
						["Consumable"] = {
							["Other"] = false,
							["Elixir"] = false,
							["Potion"] = false,
							["Food & Drink"] = false,
							["Scroll"] = false,
							["Flask"] = false,
							["Bandage"] = false,
							["Item Enhancement"] = false,
						},
						["Gem"] = {
							["Simple"] = false,
							["Blue"] = false,
							["Meta"] = false,
							["Prismatic"] = false,
							["Purple"] = false,
							["Green"] = false,
							["Yellow"] = false,
							["Orange"] = false,
							["Red"] = false,
						},
						["Armor"] = {
							["Totems"] = false,
							["Shields"] = false,
							["Librams"] = false,
							["Miscellaneous"] = false,
							["Leather"] = false,
							["Idols"] = false,
							["Mail"] = false,
							["Plate"] = false,
							["Sigils"] = false,
							["Cloth"] = false,
						},
						["Projectile"] = {
							["Bullet"] = false,
							["Arrow"] = false,
						},
						["version"] = 1,
						["Glyph"] = {
							["Warrior"] = false,
							["Paladin"] = false,
							["Shaman"] = false,
							["Rogue"] = false,
							["Mage"] = false,
							["Warlock"] = false,
							["Priest"] = false,
							["Hunter"] = false,
							["Druid"] = false,
							["Death Knight"] = false,
						},
						["Weapon"] = {
							["One-Handed Axes"] = false,
							["One-Handed Swords"] = false,
							["Staves"] = false,
							["Crossbows"] = false,
							["Polearms"] = false,
							["One-Handed Maces"] = false,
							["Bows"] = false,
							["Two-Handed Swords"] = false,
							["Miscellaneous"] = false,
							["Fishing Poles"] = false,
							["Two-Handed Maces"] = false,
							["Guns"] = false,
							["Fist Weapons"] = false,
							["Thrown"] = false,
							["Wands"] = false,
							["Daggers"] = false,
							["Two-Handed Axes"] = false,
						},
					},
					["merge"] = {
						[56488] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3.5,
							["class"] = "ITEM",
							["desc"] = "Global Sapper Charge (Explosion)",
						},
						[54968] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 1,
							["class"] = "PALADIN",
						},
						[33763] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[11366] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53595] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[42931] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55262] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53365] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 4,
						},
						[980] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55536] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[2812] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "PALADIN",
						},
						[53385] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "PALADIN",
						},
						[52000] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[58735] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[27086] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 4,
						},
						[61291] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[61295] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[56350] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 5,
							["class"] = "ITEM",
							["desc"] = "Saronite Bomb (Explosion)",
						},
						[47468] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 4,
						},
						[31803] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 6,
							["class"] = "PALADIN",
						},
						[43813] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[27243] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[47893] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 10,
						},
						[49941] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[1449] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[20153] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53652] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[47818] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 6,
						},
						[47822] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[20167] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[47834] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[33745] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[47857] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[71829] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "ITEM",
							["desc"] = "Arctic Cold (Valithria trash Mind controlled mob)",
						},
						[20424] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 1,
							["class"] = "PALADIN",
						},
						[61290] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[20187] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[42917] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[42921] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42925] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 4,
						},
						[30108] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[44457] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[44461] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[52212] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42945] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[69766] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "ITEM",
							["desc"] = "Unchained Magic (Sindragosa)",
						},
						[59159] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[64801] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[49184] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[12654] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[61840] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[50475] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[48438] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[1079] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 2,
						},
						[55050] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[63106] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[62078] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[72672] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 0.5,
							["class"] = "ITEM",
							["desc"] = "Mutated Plague (Putricide)",
						},
						[172] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[54181] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[49271] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[55078] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42463] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[61654] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[52042] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 4,
						},
						[47994] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[50526] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[5570] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[31935] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
						[8921] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[50288] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42926] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 4,
						},
						[55095] = {
							["enabled"] = true,
							["class"] = "DEATHKNIGHT",
							["prep"] = 0,
							["interval"] = 3,
						},
						[30294] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[42938] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 3,
						},
						[8050] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 3,
						},
						[20267] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 5,
							["class"] = "PALADIN",
						},
						[42950] = {
							["enabled"] = true,
							["class"] = "MAGE",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[25504] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[1822] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[55459] = {
							["enabled"] = true,
							["class"] = "SHAMAN",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[48466] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[50590] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 11,
						},
						[48562] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[774] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[8936] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[48819] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 8,
							["class"] = "PALADIN",
						},
						[53227] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.5,
						},
						[48445] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 3,
						},
						[53190] = {
							["enabled"] = true,
							["class"] = "DRUID",
							["prep"] = 0,
							["interval"] = 0.8,
						},
						[71904] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3.5,
							["class"] = "ITEM",
							["desc"] = "Chaos Bane (Shadowmourne)",
						},
						[348] = {
							["enabled"] = true,
							["class"] = "WARLOCK",
							["prep"] = 0,
							["interval"] = 3,
						},
						[54172] = {
							["enabled"] = true,
							["prep"] = 0,
							["interval"] = 3,
							["class"] = "PALADIN",
						},
					},
				},
				["frames"] = {
					["general"] = {
						["fontSize"] = 15,
						["showBuffs"] = false,
						["showDispells"] = false,
						["showPartyKills"] = false,
						["showDebuffs"] = false,
						["Y"] = 385,
						["font"] = "ArchivoNarrow-Bold",
						["colors"] = {
							["auras"] = {
								["colors"] = {
									["debuffsGained"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
									["buffsGained"] = {
										["color"] = {
											1, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["buffsFaded"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["debuffsFaded"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
								},
							},
							["killingBlow"] = {
								["color"] = {
									0.2, -- [1]
									1, -- [2]
									0.2, -- [3]
								},
							},
							["combat"] = {
								["colors"] = {
									["combatLeaving"] = {
										["color"] = {
											0.1, -- [1]
											1, -- [2]
											0.1, -- [3]
										},
									},
									["combatEntering"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["interrupts"] = {
								["color"] = {
									1, -- [1]
									0.5, -- [2]
									0, -- [3]
								},
							},
							["reputation"] = {
								["colors"] = {
									["reputationGain"] = {
										["color"] = {
											0.1, -- [1]
											0.1, -- [2]
											1, -- [3]
										},
									},
									["reputationLoss"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["lowResources"] = {
								["colors"] = {
									["lowResourcesMana"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
									["lowResourcesHealth"] = {
										["color"] = {
											1, -- [1]
											0.1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["honorGains"] = {
								["color"] = {
									0.1, -- [1]
									0.1, -- [2]
									1, -- [3]
								},
							},
							["dispells"] = {
								["colors"] = {
									["dispellBuffs"] = {
										["color"] = {
											0, -- [1]
											1, -- [2]
											0.5, -- [3]
										},
									},
									["dispellStolen"] = {
										["color"] = {
											0.31, -- [1]
											0.71, -- [2]
											1, -- [3]
										},
									},
									["dispellDebuffs"] = {
										["color"] = {
											1, -- [1]
											0, -- [2]
											0.5, -- [3]
										},
									},
								},
							},
						},
						["showHonorGains"] = false,
						["showLowManaHealth"] = false,
						["showRepChanges"] = false,
						["showInterrupts"] = false,
					},
					["power"] = {
						["enabledFrame"] = false,
					},
					["healing"] = {
						["enableRealmNames"] = false,
						["fontSize"] = 13,
						["enabledFrame"] = false,
						["Y"] = 213,
						["font"] = "ArchivoNarrow-Bold",
						["colors"] = {
							["healingTakenCritical"] = {
								["color"] = {
									0.1, -- [1]
									1, -- [2]
									0.1, -- [3]
								},
							},
							["healingTaken"] = {
								["color"] = {
									0.1, -- [1]
									0.75, -- [2]
									0.1, -- [3]
								},
							},
							["shieldTaken"] = {
								["color"] = {
									0.6, -- [1]
									0.65, -- [2]
									1, -- [3]
								},
							},
							["healingTakenPeriodic"] = {
								["color"] = {
									0.1, -- [1]
									0.5, -- [2]
									0.1, -- [3]
								},
							},
						},
						["X"] = -403,
					},
					["outgoing"] = {
						["fontSize"] = 16,
						["insertText"] = "top",
						["Width"] = 186,
						["Y"] = -436,
						["font"] = "Hooge",
						["colors"] = {
							["genericDamage"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
							["healingSpells"] = {
								["colors"] = {
									["healingOut"] = {
										["color"] = {
											0.1, -- [1]
											0.75, -- [2]
											0.1, -- [3]
										},
									},
									["shieldOut"] = {
										["color"] = {
											0.6, -- [1]
											0.65, -- [2]
											1, -- [3]
										},
									},
									["healingOutPeriodic"] = {
										["color"] = {
											0.1, -- [1]
											0.5, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
							["spellSchools"] = {
								["colors"] = {
									["SpellSchool_Nature"] = {
										["color"] = {
											0.3, -- [1]
											1, -- [2]
											0.3, -- [3]
										},
									},
									["SpellSchool_Arcane"] = {
										["color"] = {
											1, -- [1]
											0.5, -- [2]
											1, -- [3]
										},
									},
									["SpellSchool_Frost"] = {
										["color"] = {
											0.5, -- [1]
											1, -- [2]
											1, -- [3]
										},
									},
									["SpellSchool_Physical"] = {
										["color"] = {
											1, -- [1]
											1, -- [2]
											0, -- [3]
										},
									},
									["SpellSchool_Shadow"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											1, -- [3]
										},
									},
									["SpellSchool_Holy"] = {
										["color"] = {
											1, -- [1]
											0.9, -- [2]
											0.5, -- [3]
										},
									},
									["SpellSchool_Fire"] = {
										["color"] = {
											1, -- [1]
											0.5, -- [2]
											0, -- [3]
										},
									},
								},
							},
							["misstypesOut"] = {
								["color"] = {
									0.5, -- [1]
									0.5, -- [2]
									0.5, -- [3]
								},
							},
						},
						["Height"] = 147,
						["X"] = 623,
					},
					["critical"] = {
						["fontSize"] = 16,
						["secondaryFrame"] = 2,
						["enabledFrame"] = false,
						["insertText"] = "top",
						["Y"] = -358,
						["font"] = "Hooge",
						["colors"] = {
							["genericDamageCritical"] = {
								["color"] = {
									1, -- [1]
									1, -- [2]
									0, -- [3]
								},
							},
							["healingSpells"] = {
								["colors"] = {
									["healingOutCritical"] = {
										["color"] = {
											0.1, -- [1]
											1, -- [2]
											0.1, -- [3]
										},
									},
								},
							},
						},
						["X"] = 411,
					},
					["procs"] = {
						["enabledFrame"] = false,
						["colors"] = {
							["spellReactive"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
							["spellProc"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
						},
					},
					["loot"] = {
						["enabledFrame"] = false,
					},
					["class"] = {
						["colors"] = {
							["comboPoints"] = {
								["color"] = {
									1, -- [1]
									0.82, -- [2]
									0, -- [3]
								},
							},
							["comboPointsMax"] = {
								["color"] = {
									0, -- [1]
									0.82, -- [2]
									1, -- [3]
								},
							},
						},
						["enabledFrame"] = false,
					},
					["damage"] = {
						["fontSize"] = 15,
						["Width"] = 160,
						["Y"] = -340,
						["font"] = "ArchivoNarrow-Bold",
						["colors"] = {
							["missTypesTaken"] = {
								["colors"] = {
									["missTypeBlock"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeMiss"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeImmune"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeDodge"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeParry"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeResist"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeEvade"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeAbsorb"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeDeflect"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
									["missTypeReflect"] = {
										["color"] = {
											0.5, -- [1]
											0.5, -- [2]
											0.5, -- [3]
										},
									},
								},
							},
							["damageTakenCritical"] = {
								["color"] = {
									1, -- [1]
									0.1, -- [2]
									0.1, -- [3]
								},
							},
							["spellDamageTaken"] = {
								["enabled"] = true,
								["color"] = {
									0.75, -- [1]
									0.3, -- [2]
									0.85, -- [3]
								},
							},
							["damageTaken"] = {
								["enabled"] = true,
								["color"] = {
									0.75, -- [1]
									0.1, -- [2]
									0.1, -- [3]
								},
							},
							["spellDamageTakenCritical"] = {
								["color"] = {
									0.75, -- [1]
									0.3, -- [2]
									0.85, -- [3]
								},
							},
						},
						["Height"] = 140,
						["showDodgeParryMiss"] = false,
						["X"] = -396,
					},
				},
			}
			xCTSavedDB["profileKeys"][profile_name] = newProfileName
		end


        MUI_t:PluginInstallStepComplete("xCT+")
    else
        DEFAULT_CHAT_FRAME:AddMessage("|cffbefc03MerfinUI:|r You need to enable xCT to apply profile settings!")
    end
end