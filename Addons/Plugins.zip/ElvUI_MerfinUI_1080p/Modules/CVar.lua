
local MUI_t = select(2, ...)
local E = MUI_t[1]
local SetCVar = SetCVar

function MUI_t:Set_CVars()
    local CVars = {
        ["autoLootDefault"] = 1,
        ["cameraPivot"] = 1,
        ["cameraSmoothStyle"] = 0,
        ["cameraDistanceMax"] = 50,
        ["cameraPitchMoveSpeed"] = 70,
        ["cameraYawMoveSpeed"] = 160,
        ["CombatLogPeriodicSpells"] = 0,
        ["chatStyle"] = "classic",
        ["scriptErrors"] = 1,
        ["showTutorials"] = 0,
        ["showItemLevel"] = 1,
        ["ShowAllSpellRanks"] = 0,
        ["showNewbieTips"] = 0,
        ["ShowAllSpellRanks"] = 0,
        ["ShowAllSpellRanks"] = 0,
        ["ShowAllSpellRanks"] = 0,
        ["UnitNameNonCombatCreatureName"] = 1,
        ["UnitNameFriendlyTotemName"] = 1,
        ["UnitNameFriendlyGuardianName"] = 1,
        ["UnitNameEnemyTotemName"] = 1,
        ["UnitNameEnemyGuardianName"] = 1,
        ["UnitNameNPC"] = 1,
        ["UnitNameOwn"] = 1,
        ["alwaysShowActionBars"] = 1,
        ["ShowVKeyCastbar"] = 1
    }

    for CVar, variable in pairs(CVars) do
        SetCVar(CVar, variable)
    end

    MUI_t:PluginInstallStepComplete("Account Settings")
end