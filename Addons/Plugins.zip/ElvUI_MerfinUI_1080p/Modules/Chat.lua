local MUI_t = select(2, ...)

local E = MUI_t[1]
local CH = E:GetModule('Chat')

local _G = _G
local ipairs = ipairs
local SetCVar = SetCVar

local FCF_SetWindowName = FCF_SetWindowName
local FCF_OpenNewWindow = FCF_OpenNewWindow
local FCF_ResetChatWindows = FCF_ResetChatWindows
local FCFDock_SelectWindow = FCFDock_SelectWindow
local FCF_SetChatWindowFontSize = FCF_SetChatWindowFontSize

local ChatFrame_AddMessageGroup = ChatFrame_AddMessageGroup
local ChatFrame_RemoveMessageGroup = ChatFrame_RemoveMessageGroup
local ChatFrame_RemoveAllMessageGroups = ChatFrame_RemoveAllMessageGroups

function MUI_t:SetupChat()

    -- Reset to default
    FCF_ResetChatWindows()
    
    -- Create new windows
    FCF_OpenNewWindow() -- id 3
    FCF_OpenNewWindow() -- id 4
    FCF_OpenNewWindow() -- id 5
    FCF_OpenNewWindow() -- id 6

    -- Rename all windows
	for _, name in ipairs(_G.CHAT_FRAMES) do
		local frame = _G[name]
		local id = frame:GetID()

		-- Update tab colors
        if E.private.chat.enable then
            CH:UpdateChatTabs()
			--CH:FCFTab_UpdateColors(CH:GetTab(_G[name]))
		end

		-- Set font size
		FCF_SetChatWindowFontSize(nil, frame, 13)

		if id == 1 then
			FCF_SetWindowName(frame, 'GNL')
		elseif id == 2 then
			FCF_SetWindowName(frame, 'CL')
		elseif id == 3 then
			FCF_SetWindowName(frame, 'LT')
		elseif id == 4 then
			FCF_SetWindowName(frame, 'GLD')
		elseif id == 5 then
			FCF_SetWindowName(frame, '/W')
        elseif id == 6 then
            FCF_SetWindowName(frame, 'GLB')
        end
    end


    -- Tab setup: LT (Loot)
    local chats = { 'LOOT', 'MONEY'}
    ChatFrame_RemoveAllMessageGroups(_G.ChatFrame3)
    for _, k in ipairs(chats) do
        ChatFrame_AddMessageGroup(_G.ChatFrame3, k)
    end

    -- Tab setup: GLD (Guild)
    local chats = { 'GUILD', 'OFFICER', 'GUILD_ACHIEVEMENT'}
    ChatFrame_RemoveAllMessageGroups(_G.ChatFrame4)
    for _, k in ipairs(chats) do
        ChatFrame_AddMessageGroup(_G.ChatFrame4, k)
    end

    
    -- Tab setup: /W (Whisper)
    local chats = { 'WHISPER', 'WHISPER_INFORM' }
    ChatFrame_RemoveAllMessageGroups(_G.ChatFrame5)
    for _, k in ipairs(chats) do
        ChatFrame_AddMessageGroup(_G.ChatFrame5, k)
    end

    -- Tab setup: RAID
    local chats = {  'GLOBAL', 'GENERAL' }
    ChatFrame_RemoveAllMessageGroups(_G.ChatFrame6)
    for _, k in ipairs(chats) do
        ChatFrame_AddMessageGroup(_G.ChatFrame6, k)
    end

    -- Jump back to General tab
    FCFDock_SelectWindow(_G.GENERAL_CHAT_DOCK, _G.ChatFrame1)
    
    -- Turning off some channels in General tab
	--ChatFrame_RemoveMessageGroup(_G.ChatFrame1, 'WHISPER')
	--ChatFrame_RemoveMessageGroup(_G.ChatFrame1, 'BN_WHISPER')
    ChatFrame_RemoveMessageGroup(_G.ChatFrame1, 'GENERAL')
    ChatFrame_RemoveMessageGroup(_G.ChatFrame1, 'GLOBAL')

    MUI_t:PluginInstallStepComplete("Chat Settings")
end