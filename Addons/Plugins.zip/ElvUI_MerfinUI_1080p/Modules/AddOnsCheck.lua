local MUI_t = select(2, ...)

local function GetAddOnReason()

    local AddOnsList = {
        "ElvUI_OptionsUI",
        "ElvUI_AddOnSkins",
        "ElvUI_Enhanced",
        "ElvUI_CustomTweaks",
        "ElvUI_EnhancedFriendsList",
        "ElvUI_DTBars2",
        "ElvUI_DataTextColors",
        "ElvUI_CustomTags",
        "DBM-Core",
        "xCT+",
        "WeakAuras",
        "SharedMedia"
    }

    local AddOnsInfo = {}
    for _, AddOnName in ipairs(AddOnsList) do
        local reason = select(6, GetAddOnInfo(AddOnName))
        AddOnsInfo[AddOnName] = reason
    end

    return AddOnsInfo
end

function MUI_t:CheckEnabledAddOns()
    local AddOnsInfo = GetAddOnReason()
    local report_missing, report_disabled = false, false
    for AddOnName, reason in pairs(AddOnsInfo) do
        if reason == "MISSING" then
            if not report_missing then
                report_missing = string.format("You forgot to download and put next addons: %s", AddOnName)
            else
                report_missing = string.format("%s, %s", report_missing, AddOnName)
            end
        elseif reason == "DISABLED" then
            if not report_disabled then
                report_disabled = string.format("You have these addons, but you forgot to enable them: %s", AddOnName)
            else
                report_disabled = string.format("%s, %s", report_disabled, AddOnName)
            end
        end
    end

    if report_missing then
        return string.format("|cffff0000%s|r\n|cffffae00%s|r", report_missing, report_disabled or "")
    elseif report_disabled then
        return string.format("|cffffae00%s|r", report_disabled)
    else
        return "Great! You have all the UI AddOns installed and enabled!"
    end
end

function MUI_t:EnableAllAdons()
    local AddOnsInfo = GetAddOnReason()
    local flag = false
    for AddOnName, reason in pairs(AddOnsInfo) do
        if reason == "DISABLED" then
            EnableAddOn(AddOnName)
            if not flag then flag = true end
        end
    end

    if flag then
        ReloadUI()
    else
        PluginInstallStepComplete:Hide()
        PluginInstallStepComplete.message = string.format("AddOns are enabled!")
        PluginInstallStepComplete:Show()
    end
end