# LibEditModeOverride

## [1.0.10](https://github.com/plusmouse/LibEditModeOverride/tree/1.0.10) (2022-12-31)
[Full Changelog](https://github.com/plusmouse/LibEditModeOverride/compare/1.0.9...1.0.10) 

- Add check for when library already created to avoid an error  
- [Fixes #1] Fix invalid type validations for dropdown settings (#2)  
- README fixes  
- Add 2 missing functions to the README  
