-- Spanish localization file for esES and esMX.
local L = ElvUI[1].Libs.ACL:NewLocale("ElvUI", "esMX")
if not L then return end

L["Player SwingBar"] = true
L["Show Swing Bar (Dual Wield)"] = true
L["Show Swing Bar"] = true
L["Swing Bar"] = true