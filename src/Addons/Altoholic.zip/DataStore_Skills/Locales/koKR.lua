﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Skills", "koKR" )

if not L then return end

L["Professions"] = "전문 기술"
L["Secondary Skills"] = "보조 기술"
L["Riding"] = "탈것 타기"
