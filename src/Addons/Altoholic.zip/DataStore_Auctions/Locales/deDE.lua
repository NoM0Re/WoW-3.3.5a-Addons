local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Auctions", "deDE" )

if not L then return end


