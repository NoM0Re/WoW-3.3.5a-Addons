local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Crafts", "deDE" )

if not L then return end

L["Professions"] = "Berufe"
L["Secondary Skills"] = "Sekundäre Fertigkeiten"

