--------------------------------------------------------------------------
-- GTFO_Fail_Generic.lua 
--------------------------------------------------------------------------
--[[
GTFO Fail List - Generic
Author: Zensunim of Malygos

Change Log:
	v2.5.1
		- Added Cleave (Dragon Bosses)

]]--

GTFO.SpellID["19983"] = {
	--desc = "Cleave (Dragon Bosses)";
	tankSound = 0;
	sound = 3;
};

