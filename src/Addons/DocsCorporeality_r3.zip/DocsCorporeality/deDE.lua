--[[
�	\195\164	J�ger = J\195\164ger
�	\195\132	�rger = \195\132rger
�	\195\182	sch�n = sch\195\182n
�	\195\150	�dipus = \195\150dipus
�	\195\188	R�stung = R\195\188stung
�	\195\156	�bung = \195\156bung
�	\195\159	Stra�e = Stra\195\159e 
]]
local L = LibStub("AceLocale-3.0"):NewLocale("DocsCorporeality", "deDE")
if not L then return end

L["Halion"] = "Halion"
L["Ok"] = "Ok"
L["Slower"] = "Langsamer"
L["STOP"] = "HALT"
L["More"] = "Mehr"
L["MUCH MORE"] = "VIEL MEHR"