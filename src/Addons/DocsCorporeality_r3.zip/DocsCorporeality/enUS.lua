local L = LibStub("AceLocale-3.0"):NewLocale("DocsCorporeality", "enUS", true)
if not L then return end

L["Halion"] = true
L["Ok"] = true
L["Slower"] = true
L["STOP"] = true
L["More"] = true
L["MUCH MORE"] = true





