﻿local L = LibStub("AceLocale-3.0"):NewLocale("SmartTrack", "enUS", true);
if not L then return end

L["Humanoid"] = GetSpellInfo(19883)
L["Beast"] = GetSpellInfo(1494)
L["Demon"] = GetSpellInfo(19878)
L["Dragonkin"] = GetSpellInfo(19879)
L["Elemental"] = GetSpellInfo(19880)
L["Giant"] = GetSpellInfo(19882)
L["Undead"] = GetSpellInfo(19884)