﻿local L = LibStub("AceLocale-3.0"):NewLocale("SmartTrack", "deDE");
if not L then return end

L["Humanoid"] = GetSpellInfo(19883)
L["Wildtier"] = GetSpellInfo(1494)
L["D\195\164mon"] = GetSpellInfo(19878)
L["Drachkin"] = GetSpellInfo(19879)
L["Elementar"] = GetSpellInfo(19880)
L["Riese"] = GetSpellInfo(19882)
L["Untoter"] = GetSpellInfo(19884)