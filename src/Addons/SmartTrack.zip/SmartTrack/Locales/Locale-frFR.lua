﻿local L = LibStub("AceLocale-3.0"):NewLocale("SmartTrack", "frFR");
if not L then return end

L["Humano\195\175de"] = GetSpellInfo(19883)
L["B\195\170te"] = GetSpellInfo(1494)
L["D\195\169mon"] = GetSpellInfo(19878)
L["Draconien"] = GetSpellInfo(19879)
L["El\195\169mentaire"] = GetSpellInfo(19880)
L["G\195\169ant"] = GetSpellInfo(19882)
L["Mort-vivant"] = GetSpellInfo(19884)