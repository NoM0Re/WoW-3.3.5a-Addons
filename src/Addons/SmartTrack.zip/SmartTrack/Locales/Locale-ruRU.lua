﻿local L = LibStub("AceLocale-3.0"):NewLocale("SmartTrack", "ruRU");
if not L then return end

L["Гуманоид"] = GetSpellInfo(19883)
L["Животное"] = GetSpellInfo(1494)
L["Демон"] = GetSpellInfo(19878)
L["Дракон"] = GetSpellInfo(19879)
L["Элементаль"] = GetSpellInfo(19880)
L["Великан"] = GetSpellInfo(19882)
L["Нежить"] = GetSpellInfo(19884)