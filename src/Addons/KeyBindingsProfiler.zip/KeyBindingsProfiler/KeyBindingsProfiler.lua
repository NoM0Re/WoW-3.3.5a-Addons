-- author: zimeng

SLASH_KBP1 = '/kbp';

function SlashCmdList.KBP(msg, editbox)
	cmd, args = string.split(" ", msg, 2);
	cmd = string.lower(cmd or "")
	args = string.lower(args or "")
	
	if cmd == "save" and args ~= "" then
		print("Save profile: "..args);
		save_keybindings(args);
	elseif cmd == "restore" and args~="" then
		print("Restore profile: "..args..". binding count: "..restore_keybindings(args));
	elseif cmd == "delete" and args~="" then
		if delete_profile(args) == true then
			print("Profile: "..args.." deleted.")
		else
			print("Failed to delete profile: "..args..".")
		end
	elseif cmd == "list" then
		list_profiles();
	elseif cmd == "clear" then
		clear_profiles();
		print("Saved key bindings on this account are cleared.");
	else
		usage();
	end	
end

function save_keybindings(profile_name)
	bindingCount = GetNumBindings();
	bindings = {};
	i = 0;
	
	while i < bindingCount do
		command, key1, key2 = GetBinding(i);
		
		binding={};
		
		if command == nil then
			binding["command"] = "_NULL";
		else
			binding["command"] = command;
		end
		
		if key1 == nil then
			binding["key1"] = "_NULL";
		else
			binding["key1"] = key1;
		end
		
		if key2 == nil then
			binding["key2"] = "_NULL";
		else
			binding["key2"] = key2;
		end
		
		bindings[i+1] = binding;
		
		i = i+1;
	end
	
	saved_keybindings[profile_name] = bindings;
	SaveBindings(1);
end

function restore_keybindings(profile_name)
	bindings = saved_keybindings[profile_name];		
	
	if bindings == nill or bindings == "" then
		bindingCount = 0;
		return bindingCount;
	else
		bindingCount = #bindings;
	end;
	
	i = 1;
	while i <= bindingCount do
		if bindings[i].key1 ~= "_NULL" then
			SetBinding(bindings[i].key1, bindings[i].command);
		end
		
		if bindings[i].key2 ~= "_NULL" then
			SetBinding(bindings[i].key2, bindings[i].command);
		end
		i = i+1;
	end;
	
	SaveBindings(1);
	return bindingCount;
end

function list_profiles()
	print("Key Binding List:");
	for key,value in pairs(saved_keybindings) do 
		print(key);
	end
end

function usage()
	print("Key Binding Profiler 1.0 usage:")
	print("/kbp save <profile name> - Save your current key bindings.")
	print("/kbp restore <profile name> - Restore your key bindings.")
	print("/kbp list - List your key bindings on this account.")
	print("/kbp delete <profile name> - Delete a profile.");
	print("/kbp clear - Clear saved key bindings on this account.")
	print("/kbp - Display this help.")
	
end

function clear_profiles()
	wipe(saved_keybindings)
end

function delete_profile(profile_name)
	if saved_keybindings[profile_name] == nil then
		return false
	else
		saved_keybindings[profile_name] = nil
		return true
	end
end

function init()
	if saved_keybindings == nil then
		saved_keybindings = {}
	end
end

local frame = CreateFrame("FRAME")
frame:RegisterEvent("ADDON_LOADED")

function frame:OnEvent(event, arg1)
 if event == "ADDON_LOADED" and arg1 == "KeyBindingsProfiler" then
	init()
 end
end
frame:SetScript("OnEvent", frame.OnEvent);


