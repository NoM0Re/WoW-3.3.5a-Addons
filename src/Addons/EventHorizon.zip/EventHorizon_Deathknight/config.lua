local config = EventHorizon.config

function EventHorizon:InitializeClass()

	self.config.gcdSpellID = 49895		-- Death Coil
	
	-- Icy Touch
	self:NewSpell({
		spellID = 55095,
		debuff = true,
		dot = 3,
	})
  
	-- Plague Strike
	self:NewSpell({
		spellID = 55078,
		debuff = true,
		dot = 3,
	})
	
	-- Blade Barrier
	self:NewSpell({
		spellID = 49182,
		playerbuff = true,
		requiredTalent = {{1,3},{2,3}},
	})
  
	-- Death Coil (talented)
	self:NewSpell({
		spellID = 49194,
		debuff = true,
--		dot = 1,
		requiredTalent = {3,14},
	})
  
	-- Unbreakable Armor
	self:NewSpell({
		spellID = 51271,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {2,24},
	})
  
	-- Vampiric Blood
	self:NewSpell({
		spellID = 55233,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {1,23},
	})
  
	-- Icebound Fortitude
	self:NewSpell({
		spellID = 48792,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {{1,3},{2,3}},
	})
	
	-- Rune Tap
	self:NewSpell({
		spellID = 48982,
		cooldown = true,
		requiredTalent = {1,10}, -- Improved Rune Tap
	})
	
	-- Blood Tap (tank)
	self:NewSpell({
		spellID = 45529,
		playerbuff = 70654,	-- Blood Armor (t10 tank bonus)
		cooldown = true,
		requiredTalent = {{1,3},{2,3}},
	})
	
	-- Blood Tap (DPS)
	self:NewSpell({
		spellID = 45529,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {{1,3,0},{2,3,0}},
	})
  
	-- Bone Shield
	self:NewSpell({
		spellID = 49222,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {3,26},
	})
  
	-- Hungering Cold
	self:NewSpell({
		spellID = 49203,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {2,20},
	})
    
	-- Hysteria
	self:NewSpell({
		spellID = 49016,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {1,19},
	})
	
	return true
end