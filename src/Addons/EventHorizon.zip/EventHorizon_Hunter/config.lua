local config = EventHorizon.config

function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 1978
	-- Serpent Sting
	self:NewSpell({
		spellID = 27016,
		debuff = true,
		dot = 3,
	})
	-- Black Arrow
	self:NewSpell({
		spellID = 3674,
		cooldown = true,
		debuff = true,
		dot = 3,
		requiredTalent = {3,25},
	})
	-- Chimera Shot
	self:NewSpell({
		spellID = 53209,
		cooldown = true,
		requiredTalent = {2,27},
	})
	-- Explosive Shot
	self:NewSpell({
		spellID = 53301,
		debuff = true,
		dot = 1,
		cooldown = true,
		requiredTalent = {3,28},
	})
	-- Multi Shot
	self:NewSpell({
		spellID = 2643,
		debuff = 20900,		-- Track Aimed Shot debuff as well. No need for an Aimed Shot bar, these share a CD.
		cooldown = true,
	})
	-- Steady Shot
	self:NewSpell({
		spellID = 34120,
		cast = true,
		playerbuff = {53220,56453}, -- Improved Steady Shot, Lock and Load
	})
	-- Arcane Shot
	self:NewSpell({
		spellID = 3044,
		cooldown = true,
		requiredTalent = {3,28,0}, -- Only show if ES is untalented
	})
	-- Kill Shot
	self:NewSpell({
		spellID = 53351,
		cooldown = true,
	})
	--[[
	-- Mend Pet
	self:NewSpell({
		spellID = 136,
		playerbuff = true,
		auraunit = "pet",
		dot = 3,
	})]]--
end
