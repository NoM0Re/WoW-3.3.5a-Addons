local config = EventHorizon.config


local usemouseover = true	-- Make this false or nil (or just delete the line altogether) to make your healing bars not change when you mouse over something.


function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 1243 -- Power Word: Fortitude

	-- Devouring Plague
	self:NewSpell({
		spellID = 25467,
		debuff = true,
		cooldown = true,
		dot = 3,
		refreshable = true,
		stance = 1,
		requiredTalent = {3,19}, 
		hasted = {3,19},
		expectedTicks = 8,
	})
	
	-- Vampiric Touch
	self:NewSpell({
		spellID = 48160,
		cast = true,
		debuff = true,
		dot = 3,
		stance = 1,
		requiredTalent = {3,24},
		hasted = {3,19},
		expectedTicks = 7,
	})
	
	-- Mind Blast
	self:NewSpell({
		spellID = 8092,
		cast = true,
		cooldown = true,
		stance = 1,
		requiredTalent = {3,19}, 
	})
	
	-- Mind Flay
	self:NewSpell({
		spellID = 48156,
		channeled = true,
		numhits = 3,
		stance = 1,
		requiredTalent = {3,19}, 
	})

	-- Shadow Word: Death
	self:NewSpell({
		spellID = 32379,
		cooldown = true,
		stance = 1,
		requiredTalent = {3,19}, 
	})

	-- Shadow Word: Pain
	self:NewSpell({
		spellID = 10892,
		debuff = true,
		dot = 3,
		refreshable = true,
		requiredTalent = {3,19}, 
	})
	--[[ Shadow Weaving
	self:NewSpell({
		spellID = 15332,
		playerbuff = true,
		requiredTalent = {3,12},
	})--]]

	-- Renew
	self:NewSpell({
		spellID = 139,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		dot = 3,
		stance = 0,
	})
	
	-- Prayer of Mending
	self:NewSpell({
		spellID = 48113,
		playerbuff = true,
		cooldown = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		stance = 0,
	})
	
	-- Penance (including Grace) -- Also EASILY the longest spell entry in EventHorizon to date. Uses an absurd amount of nonstandard types!
	self:NewSpell({
		spellID = 53005,
		playerbuff = 47930,
		auraunit = usemouseover and 'mouseover' or 'target',
		channeled = true,
		numhits = 2,
		cooldown = true,
		stance = 0,
		requiredTalent = {1,28},
		cleu = 'SPELL_HEAL', -- Usage of config.cleu (alias: config.event)
		keepIcon = true,
	})
	
	-- Lesser Heal (including Surge of Light)
	self:NewSpell({
		spellID = 2061,
		playerbuff = 33151,
		cast = true,
		stance = 0,
	})
	
	-- Greater Heal (including Serendipity)
	self:NewSpell({
		spellID = 2060,
		playerbuff = 63731,
		unique = true,
		cast = true,
		stance = 0,
	})
	
	-- Circle of Healing
	self:NewSpell({
		spellID = 34863,
		--playerbuff = -- There's a buff I want to show here, I just haven't decided what.
		cooldown = true,
		stance = 0,
		requiredTalent = {2,24},
	})


	-- Weakened Soul (Disc - Can't track PW:S on the same bar yet)
	self:NewSpell({
		spellID = 6788,
		debuff = true,
		unique = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		stance = 0,
		requiredTalent = {1,15}, -- Soul Warding
	})

	return true
end

