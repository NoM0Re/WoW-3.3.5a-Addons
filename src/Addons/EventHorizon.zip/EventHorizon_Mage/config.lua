local config = EventHorizon.config

function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 1459 -- Arcane Intellect

	----------
	-- Fire --
	----------	
	-- Scorch
	self:NewSpell({
		spellID = 2948,
		cast = true,
		debuff = {22959, 12579, 17803}, -- Improved Scorch, Winter's Chill, ISB
		unique = true,
		requiredTalent = {2,11}, -- Imp. Scorch
	})
	
	-- FFB
	self:NewSpell({
		spellID = 44614,
		cast = true,
		requiredTalent = {{3,2,0}, {3,8,3}}, -- no points in Imp Frostbolt, 3 points in Piercing Ice
	})
	
	-- Fireball
	self:NewSpell({
		spellID = 42833,
		cast = true,
		requiredTalent = {{3,2,0}, {3,8,0}, {2,18,5},}, -- no points in Imp Frostbolt, no points in Piercing Ice, but 5 points in Fire Power
	})
	
	-- Pyroblast
	self:NewSpell({
		spellID = 12505,
		cast = true,
		playerbuff = 44448, -- Hot Streak
		requiredTalent = {2,26}, -- Hot Streak
		-- debuff = true,
		-- dot = 3,
	})
	
	-- Living Bomb
	self:NewSpell({
		spellID = 44457,
		debuff = true,
		dot = 3,
		requiredTalent = {2,28},
	})
	
	------------
	-- Arcane --
	------------
	-- Arcane Blast
	self:NewSpell({
		spellID = 42897,
		cast = true,
		debuff = 36032, -- Arcane Blast debuff
		auraunit = 'player',
		minstacks = 4,
		requiredTalent = {1,30}, -- ABar
	})
	
	-- Arcane Barrage
	self:NewSpell({
		spellID = 44781,
		cast = true,
		cooldown = true,
		requiredTalent = {1,30},
	})
	
	-- Arcane Missiles
	self:NewSpell({
		spellID = 42846,
		channeled = true,
		numhits = 5,
		playerbuff = 44401, -- Missile Barrage
		requiredTalent = {1,27}, -- Missile Barrage
	})
	
	-- Arcane Power
	self:NewSpell({
		spellID = 12042,
		playerbuff = true, -- Arcane Power
		cooldown = true,
		requiredTalent = {1,22},
	})
	
	-- Presence of Mind
	self:NewSpell({
		spellID = 12043,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {1,16},
	})
	
	-----------
	-- Frost --
	-----------
	-- Frostbolt
	self:NewSpell({
		spellID = 38697,
		cast = true,
		debuff = {12579, 22959, 17803}, -- Winter's Chill, Improved Scorch, ISB
		unique = true,
		requiredTalent = {3,2,5}, -- Imp Frostbolt
	})
	
	-- Brain Freeze proc (Fireball! buff)
	self:NewSpell({
		spellID = 57761,
		playerbuff = true,
		requiredTalent = {3,24},--Brain Freeze
	})
	
	-- Deep Freeze
	self:NewSpell({
		spellID = 44572,
		debuff = true,
		cooldown = true,
		requiredTalent = {3,28}, -- Deep Freeze
	})
	
	-- Fingers of Frost
	self:NewSpell({
		spellID = 44544,
		playerbuff = true,
		requiredTalent = {3,23}, -- FoF
	})
	
	-- Freeze effects
	self:NewSpell({
		spellID = 33395,
		debuff = {33395,42917,12494,55080},
		unique = true,
		requiredTalent = {3,13}, -- Shatter
	})

	--[[ Blizzard
	self:NewSpell({
		spellID = 42940,
		channeled = true,
		numhits = 8,
	})--]]

	-- Long cooldowns:
	--[[ Icy Veins
	self:NewSpell({
		spellID = 12472,
		cast = true, 
		playerbuff = 12472, -- Icy Veins
		cooldown = true,
	})--]]

	--[[ Mirror Image
	self:NewSpell({
		spellID = 55342,
		cast = true, 
		cooldown = true,
	})--]]
end

