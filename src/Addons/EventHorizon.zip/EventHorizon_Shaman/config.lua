local config = EventHorizon.config


local usemouseover = true	-- Make this false or nil (or just delete the line altogether) to make your healing bars not change when you mouse over something.


function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 57960 -- Water Shield

	-- Flame Shock
	self:NewSpell({
		spellID = 49233,
		debuff = true,
		dot = 3,
		cooldown = true,
		requiredTalent = {3,10,0}, -- We just don't need it as resto.
	})
	
	-- Stormstrike
	self:NewSpell({
		spellID = 17364,
		cooldown = true,
		requiredTalent = {2,21},
	})
	
	-- Lava Lash
	self:NewSpell({
		spellID = 60103,
		cooldown = true,
		requiredTalent = {2,23},
	})
	
	-- Maelstrom Weapon
	self:NewSpell({
		spellID = 53817,
		playerbuff = true,
		requiredTalent = {2,28},
	})

	-- Lava Burst
	self:NewSpell({
		spellID = 60043,
		cast = true,
		cooldown = true,
		requiredTalent = {1,15},
	})
	
	-- Lightning Bolt
	self:NewSpell({
		spellID = 49238,
		cast = true,
		requiredTalent = {1,15},
	})
	
	-- Chain Lightning
	self:NewSpell({
		spellID = 49271,
		cast = true,
		cooldown = true,
		requiredTalent = {1,15},
	})
		
	-- Earthliving Weapon
	self:NewSpell({
		spellID = 52000,
		playerbuff = true,
		refreshable = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		requiredTalent = {3,17},
	})
	
	-- Riptide
	self:NewSpell({
		spellID = 61300,
		playerbuff = true,
		cooldown = true,
		dot = 3,
		auraunit = usemouseover and 'mouseover' or 'target',
		requiredTalent = {3,26},
	})

	-- Chain Heal (including Tidal Waves)
	self:NewSpell({
		spellID = 1064,
		playerbuff = 53390,
		auraunit = usemouseover and 'mouseover' or 'target',
		cast = true,
		requiredTalent = {3,17},
	})
	
	-- Lesser Healing Wave (including Ancestral Fortitude/Inspiration)
	self:NewSpell({
		spellID = 10468,
		playerbuff = {15359, 16237},
		auraunit = usemouseover and 'mouseover' or 'target',
		cast = true,
		requiredTalent = {3,17},
	})
	
	-- Healing Wave, secondary effect TBA
	self:NewSpell({
		spellID = 25357,
		cast = true,
		requiredTalent = {3,17},
	})
	
	-- Earth Shield
	self:NewSpell({
		spellID = 49284,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		requiredTalent = {3,23},
	})
	
	-- Fire Nova
	self:NewSpell({
		spellID = 1535,
		cooldown = true,
		playerbuff = 16246,
		requiredTalent = {3,10,0},
	})
	
	-- Elemental Mastery
	self:NewSpell({
		spellID = 16166,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {1,15},
	})
	return true

end

