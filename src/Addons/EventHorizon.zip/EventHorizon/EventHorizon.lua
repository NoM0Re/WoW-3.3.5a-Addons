--local DEBUG = true
EventHorizon = {}
local EventHorizon = EventHorizon
EventHorizon.defaultDB = {
	point = {'CENTER', 'UIParent', 'CENTER'},
	isActive = true,
	version = 2,
}
EventHorizon.db = {
	point = {'CENTER', 'UIParent', 'CENTER'},
	isActive = true,
	version = 2,
}
EventHorizon.frames = {
	config = {},
	frames = {},
	active = {},
	shown = {},
	mouseover = {},
}
EventHorizon.config = {Redshift = {}}
EventHorizon.layouts = {}
EventHorizon.colors = {}
EventHorizon.glyphs = {}
EventHorizon.otherIDs = {}
EventHorizon.modules = {}

local UnitDebuff = UnitDebuff
local UnitBuff = UnitBuff

local SpellFrame = {}

local eventhandler
local EventHorizonFrame = CreateFrame('Frame','EventHorizonFrame',UIParent)
local mainframe = CreateFrame('Frame',nil,EventHorizonFrame)
local frame = CreateFrame('Frame')
local frame2 = CreateFrame('Frame')

local gcdIndicator, gcdSpellName, gcdend, handle, nowI, nowIndicator, castLine

--mainframe:SetAllPoints()
EventHorizon.mainframe = mainframe

local isMouseover, isUsingMouseover
local playerguid
local onepixelwide = 1
local visibleFrame = true
local numframes = 0

local function printhelp(...) if select('#',...)>0 then return tostring((select(1,...))), printhelp(select(2,...)) end end
local function debug(...)
	print(...)
end
local function print(...)
	ChatFrame1:AddMessage('EventHorizon: '..strjoin(',',printhelp(...)))
end

local drawingorder = {'default', 'cooldown', 'debuff', 'debuffmine', 'playerbuff', 'casting', 'sent', 'tick','now'}

local typeids = {
	['tick'] = true,
	['cantcast'] = true,
	['debuff'] = true,
	['playerbuff'] = true,
	['debuffmine'] = true,
}

local customColors = {
	["debuff"] = true,
	["debuffmine"] = true,
	["playerbuff"] = true,
}

local exemptColors = {
	["default"] = true,
	["sent"] = true,
	["tick"] = true,
	["castLine"] = true,
	["nowLine"] = true,
	["bgcolor"] = true,
	["bordercolor"] = true,
	["gcdColor"] = true,
}

local equipSlots = {
	["ChestSlot"] = 5,
	["FeetSlot"] = 8,
	["Finger0Slot"] = 11,
	["Finger1Slot"] = 12,
	["HandsSlot"] = 10,
	["HeadSlot"] = 1,
	["LegsSlot"] = 7,
	["MainHandSlot"] = 16,
	["NeckSlot"] = 2,
	["RangedSlot"] = 18,
	["SecondaryHandSlot"] = 17,
	["ShirtSlot"] = 4,
	["ShoulderSlot"] = 3,
	["TabardSlot"] = 19,
	["Trinket0Slot"] = 13,
	["Trinket1Slot"] = 14,
	["WaistSlot"] = 6,
	["WristSlot"] = 9,
}

local mainframeEvents = {
	['COMBAT_LOG_EVENT_UNFILTERED'] = true,
	['PLAYER_TALENT_UPDATE'] = true,
	['UPDATE_SHAPESHIFT_FORM'] = true,
	['UPDATE_SHAPESHIFT_FORMS'] = true,
	['SPELL_UPDATE_COOLDOWN'] = true,
}

local reloadEvents = {
	['GLYPH_ADDED'] = true,
	['GLYPH_ENABLED'] = true,
	['GLYPH_REMOVED'] = true,
	['GLYPH_UPDATED'] = true,
	['GLYPH_DISABLED'] = true,
	['PLAYER_REGEN_DISABLED'] = true,
	['PLAYER_REGEN_ENABLED'] = true,
	['ZONE_CHANGED_NEW_AREA'] = true,
	['ZONE_CHANGED_INDOORS'] = true,
}

local tickevents = {
	['SPELL_PERIODIC_DAMAGE'] = true,
	['SPELL_PERIODIC_HEAL'] = true,
	['SPELL_PERIODIC_ENERGIZE'] = true,
	['SPELL_PERIODIC_DRAIN'] = true,
	['SPELL_PERIODIC_LEACH'] = true,	
	['SPELL_DAMAGE'] = true,
	['SPELL_HEAL'] = true,
	--['SPELL_AURA_APPLIED'] = true,
}

-- Dispatch event to method of the event's name.
local EventHandler = function (self, event, ...)
	local f = self[event]
	if f then 
		f(self,...) 
	end 
end

local Clone = function (t)
	local new = {}
	local i, v = next(t, nil)	-- i is an index of t, v = t[i]
	while i do
		new[i] = v
		i, v = next(t, i)
	end
	return new
end

-- Since Blizzard doesn't provide the ability to look up a slot name from a slotID...
local GetSlotName = function (slot)
	for k,v in pairs(equipSlots) do
		if v == slot then return k end
	end
end

-- Helper function for unique debuffs that accepts a list of aura names.
-- Intended usage is for unique debuffs like Mangle - Cat/Mangle - Bear/Trauma, which overwrite each other.
local UnitDebuffUnique = function (unitid, auras, unique)
	if unique == true then
		for i,auraname in ipairs(auras) do
			local name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = UnitDebuff(unitid, auraname)
			if name then
				return name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID
			end
		end
	else
		for i,auraname in ipairs(auras) do
			local name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = UnitDebuff(unitid, auraname)
			if name and (source == 'player') then
				return name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID
			end
		end
	end
end

local UnitBuffUnique = function (unitid, auras, unique)
	if unique == true then
		for i,auraname in ipairs(auras) do
			local name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = UnitBuff(unitid, auraname)
			if name then
				return name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID
			end
		end
	else
		if type(auras) == 'table' then
			for i,auraname in ipairs(auras) do
				local name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = UnitBuff(unitid, auraname)
				if name and (source == 'player') then
					return name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID
				end
			end
		else
			local name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = UnitBuff(unitid, auras)
			if name and (source == 'player') then
				return name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID
			end
		end
	end
end


-- SpellFrame - All spell bar frames inherit from this class.

--Indicators represent a point or range of time. There are different types. The type determines the color and position.

local past, future
local barwidth, barheight, barspacing, scale
local bartexture, barbgcolor
local texturedbars

local classburn
local classalpha

local typeparent = {}

local SpellFrame_NotInteresting = function (self, unitid, spellname) 
	return unitid ~= 'player' or spellname ~= self.spellname
end

local SpellFrame_AddIndicator = function (self, typeid, layoutid, time, usetexture)
	local indicator
	local parent = typeparent[typeid]
	local ndtex, ndcol
	if usetexture and self.bartexture then ndtex = self.bartexture end
	if typeid and customColors[typeid] then
		if self.barcolorunique and typeid == 'debuff' then
			ndcol = self.barcolorunique
		elseif self.barcolor then
			ndcol = self.barcolor
		end			
	end
	
	if not parent then
		parent = CreateFrame("Frame", nil, mainframe)
		local framelevel = parent:GetFrameLevel()
		for i,t in ipairs(drawingorder) do
			if t==typeid then
				framelevel = framelevel+i
				break
			end
		end
		parent:SetFrameLevel(framelevel)
		parent.unused = {}
		typeparent[typeid] = parent
		--if DEBUG and typeid=='tick'  then parent.numchildren=0 end--]]
	end
	if #parent.unused>0 then
		indicator = tremove(parent.unused)
		indicator:ClearAllPoints()
		indicator.time = nil
		indicator.start = nil
		indicator.stop = nil
		indicator.happened = nil
		--if DEBUG and typeid=='tick'  then debug('reusing indicator',indicator.frameindex) end--]]
	else
		indicator = parent:CreateTexture(nil, 'ARTWORK')
		indicator.parent = parent
		--if DEBUG and typeid=='tick' then parent.numchildren=parent.numchildren+1 indicator.frameindex=parent.numchildren debug('adding indicator',indicator.frameindex) end--]]
	end
	-- Layout
	local layouts = EventHorizon.layouts
	local layout = layouts[layoutid] or layouts.default
	local color = ndcol or EventHorizon.colors[typeid] or EventHorizon.colors.default
	if layoutid == 'frameline' then
		color = typeid == 'sent' and EventHorizon.colors.castLine or EventHorizon.colors[typeid]
		indicator:SetPoint('TOP',EventHorizon.mainframe)
		indicator:SetPoint('BOTTOM',EventHorizon.mainframe)
	else
		indicator:SetPoint('TOP',self, 'TOP', 0, -layout.top*barheight)
		indicator:SetPoint('BOTTOM',self, 'TOP', 0, -layout.bottom*barheight)
	end
	
	if usetexture then
		indicator:SetTexture(ndtex or bartexture)
		indicator:SetTexCoord(unpack(layout.texcoords))
	else
		indicator:SetTexture(1,1,1,1)
	end
	indicator:SetVertexColor(unpack(ndcol or color))

	indicator:Hide()
	indicator:SetWidth(onepixelwide)
	indicator.time = time
	indicator.typeid = typeid
	indicator.layoutid = layoutid
	if indicator then
		tinsert(self.indicators, indicator)
	end
	return indicator
end

local SpellFrame_AddSegment = function (self, typeid, layoutid, start, stop, start2)
	local start,stop = start,stop
	if (start2 and stop<start) then start = start2 end
	if stop<start then return end
	local indicator = self:AddIndicator(typeid, layoutid, start, texturedbars)
	indicator.time = nil
	indicator.start = start
	indicator.stop = stop
	--debug(start,stop)
	return indicator
end

local SpellFrame_Remove = function (self,indicator)
	if type(indicator)=='number' then
		local index, indicator = indicator, self.indicators[indicator]
		indicator:Hide()
		--if DEBUG and indicator.typeid=='tick' then debug('deleting',indicator.frameindex) end--]]
		tinsert(indicator.parent.unused, tremove(self.indicators, index))
	else
		for index=1,#self.indicators do
			if self.indicators[index]==indicator then
				indicator:Hide()
				--if DEBUG and indicator.typeid=='tick' then debug('deleting',indicator.frameindex) end--]]
				tinsert(indicator.parent.unused, tremove(self.indicators,index))
				break
			end
		end
	end
end

local SpellFrame_OnUpdate = function (self,elapsed)
	local now = GetTime()
	local diff = now+past

	-- spellframe.nexttick is used to schedule the creation of predicted ticks as soon as they scroll past now+future.
	local nexttick = self.nexttick
	if nexttick and nexttick <= now+future then
		if nexttick<=self.lasttick then
			self:AddIndicator('tick', 'tick', nexttick)
			self.latesttick = nexttick
			self.nexttick = nexttick + (self.dotMod or self.dot)
		else
			self.nexttick = nil
		end
	end
	for k=#self.indicators,1,-1 do
		local indicator = self.indicators[k]
		local time = indicator.time
		if time then
			-- Example: 
			-- [-------|------->--------]
			-- past    now     time     future
			-- now=795, time=800, past=-3, then time is time-now-past after past.
			local p = (time-diff)*scale
			local remove = p<0 or (time<=now and indicator.typeid=='tick' and not indicator.happened)
			if remove then
				indicator:Hide()
				--if DEBUG and indicator.typeid=='tick' then debug('deleting',indicator.frameindex) end--]]
				tinsert(indicator.parent.unused, tremove(self.indicators,k))
			elseif p<=1 then
				indicator:SetPoint('LEFT', self, 'LEFT', p*barwidth, 0)
				indicator:Show()
			end
		else
			local start, stop = indicator.start, indicator.stop
			local p1 = (start-diff)*scale
			local p2 = (stop-diff)*scale
			if p2<0 then
				indicator:Hide()
				--if DEBUG and indicator.typeid=='tick' then debug('deleting',indicator.frameindex) end--]]
				tinsert(indicator.parent.unused, tremove(self.indicators,k))
			elseif 1<p1 then
				indicator:Hide()
			else
				indicator:Show()
				indicator:SetPoint('LEFT', self, 'LEFT', 0<=p1 and p1*barwidth or 0, 0)
				indicator:SetPoint('RIGHT', self, 'LEFT', p2<=1 and p2*barwidth+1 or barwidth, 0)
			end
		end
	end
end
-- /run e.mf:AddIndicator(GetTime())

local SpellFrame_UNIT_SPELLCAST_SENT = function (self, unitid, spellname, spellrank, spelltarget)
	--debug('UNIT_SPELLCAST_SENT',unitid, spellname, spellrank, spelltarget)
	local now = GetTime()
	if self:NotInteresting(unitid, spellname) then return end
	self:AddIndicator('sent', 'default', now)
end

local SpellFrame_UNIT_SPELLCAST_CHANNEL_START = function (self, unitid, spellname, spellrank)
	if self:NotInteresting(unitid, spellname) then return end
	local _,_,_,_,startTime,endTime,_ = UnitChannelInfo(unitid)
	if not(startTime and endTime) then return end
	startTime, endTime = startTime/1000, endTime/1000
	self.casting = self:AddSegment('casting', 'default', startTime, endTime)
	if self.numhits then
		local casttime = endTime - startTime
		local tick = casttime/self.numhits
		for i=1,self.numhits do
			self:AddIndicator('tick', 'tick', startTime + i*tick)
		end
	end
	if castLine and (endTime - startTime > castLine) then
		self.castLine = self:AddIndicator('sent', 'frameline', endTime)
	end
end

local SpellFrame_UNIT_SPELLCAST_CHANNEL_UPDATE = function (self, unitid, spellname, spellrank)
	--debug('UNIT_SPELLCAST_CHANNEL_UPDATE',unitid, spellname, spellrank)
	if self:NotInteresting(unitid, spellname) then return end
	local _,_,_,_,startTime,endTime,_ = UnitChannelInfo(unitid)
	if not (startTime and endTime) then return end
	startTime, endTime = startTime/1000, endTime/1000
	if self.casting then
		self.casting.stop = endTime
		if castLine and self.castLine then
			self.castLine.time = endTime
		end
	end
	self:RemoveTicksAfter(endTime)
end

local SpellFrame_UNIT_SPELLCAST_CHANNEL_STOP = function (self, unitid, spellname, spellrank)
	if self:NotInteresting(unitid, spellname) then return end
	local now = GetTime()
	if self.casting then
		self.casting.stop = now
		if castLine and self.castLine then
			self.castLine.time = now
		end
		self.casting = nil
	end
	self:RemoveTicksAfter(now)
end

local SpellFrame_UNIT_SPELLCAST_START = function (self, unitid, spellname, spellrank, target)
	if self:NotInteresting(unitid, spellname) then return end
	local _,_,_,_,startTime,endTime,_ = UnitCastingInfo(unitid)
	if not(startTime and endTime) then return end
	startTime, endTime = startTime/1000, endTime/1000
	self.casting = self:AddSegment('casting', 'default', startTime, endTime)
	if castLine and (endTime - startTime > castLine) then
		self.castLine = self:AddIndicator('sent', 'frameline', endTime)
	end
end

local SpellFrame_UNIT_SPELLCAST_STOP = function (self, unitid, spellname, spellrank)
	local now = GetTime()
	if self:NotInteresting(unitid, spellname) then return end
	if self.casting then
		self.casting.stop = now
		if castLine and self.castLine then
			self.castLine.time = now
		end
		self.casting = nil
	end
end

local SpellFrame_UNIT_SPELLCAST_DELAYED = function (self, unitid, spellname, spellrank)
	--debug('UNIT_SPELLCAST_CHANNEL_UPDATE',unitid, spellname, spellrank)
	if self:NotInteresting(unitid, spellname) then return end
	local _,_,_,_,startTime,endTime,_ = UnitCastingInfo(unitid)
	if not(startTime and endTime) then return end
	startTime, endTime = startTime/1000, endTime/1000
	if self.casting.stop then
		self.casting.stop = endTime
		if castLine and self.castLine then
			self.castLine.time = endTime
		end
	end
end

local SpellFrame_UNIT_SPELLCAST_SUCCEEDED = function (self, unitid, spellname, spellrank)
	if self:NotInteresting(unitid, spellname) then return end
	self.succeeded = GetTime()
end

local SpellFrame_UNIT_AURA = function (self, unitid)
	if unitid~=self.auraunit then return end
	local name, rank, icon, count, debuffType, duration, expirationTime, source, spellID, _ --= self.AuraFunction(self.auraunit, self.auraname)
	if (type(self.auraname) == 'table') and self.unique then
		name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = self.AuraFunction(self.auraunit, self.auraname, true)
	else
		name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = self.AuraFunction(self.auraunit, self.auraname)
	end
		
	local afflicted = name and (self.unique or source=='player') and (not self.minstacks or count>=self.minstacks)
	local addnew
	local now = GetTime()
	local start
	local targ = UnitName(self.auraunit)
	
	if self.uniqueID and self.uniqueID ~= spellID then
		return
	end
		
	
	if self.aurasegment and expirationTime == 0 and duration == 0 then	-- Timeless aura, bar exists (Overkill)
		for i = #self.indicators,1,-1 do
			self:Remove(i)
		end
		self.aurasegment = nil
		self.nexttick = nil
		self.stacks:SetText()
		return
	end
	
	if expirationTime == 0 then
		return
	end
	
	if afflicted then
		start = expirationTime-duration
		if icon and not(self.cast or self.slotID or self.keepIcon) then self.icon:SetTexture(icon) end
		if self.aurasegment and (self.aurasegment.lastunit == targ) then
			-- The aura is currently displayed
			if expirationTime~=self.aurasegment.stop then
				if self.alwaysrefresh and not self.cast then -- alwaysrefresh = buff. Cast + buff - HoT = BAD. Buffs with cast time and no HoT component are treated much differently.
					if self.dot then -- ...check to see if it's a HoT. If so, it's treated as a DoT.
						self.aurasegment.stop = start-0.2
						if self.cast and self.useSmalldebuff then
							self.cantcast.stop = start-0.2
						end
						self:RemoveTicksAfter(start)
						addnew = true
					else
						-- If it's a buff with no cast time or HoT component, no special handling needed, move along.
						self.aurasegment.stop = expirationTime
					end
				else
					-- The aura was replaced.
					self.aurasegment.stop = start-0.2
					if self.cast and self.useSmalldebuff then
						self.cantcast.stop = start-0.2
					end
					self:RemoveTicksAfter(start)
					addnew = true
				end
				if self.internalcooldown and type(self.internalcooldown) == 'number' then
					self:AddSegment('cooldown', 'cooldown', now + expirationTime, now + self.internalcooldown, now)
				end
			end
		else
			addnew = true
			if self.internalcooldown and type(self.internalcooldown) == 'number' then
				self:AddSegment('cooldown', 'cooldown', now + expirationTime, now + self.internalcooldown, now)
			end
		end
		if count>0 then
			self.stacks:SetFormattedText('%d',count)
		end
	else
		if self.aurasegment then
			if math.abs(self.aurasegment.stop - now)>0.3 then
				self.aurasegment.stop = now
				if self.cast and self.useSmalldebuff then
					self.cantcast.stop = now-0.2
				end
			end
			self:RemoveTicksAfter(now)
			self.aurasegment = nil
			self.stacks:SetText()
		end
	end
	self:UpdateDoT(addnew, source, now, start, expirationTime, name)
end

local SpellFrame_PLAYER_TARGET_CHANGED = function (self)
	if self.auraunit ~= 'target' then return end
	--print"PTC"
	if self.aurasegment then
		for i = #self.indicators,1,-1 do
			local ind = self.indicators[i]
			if typeids[ind.typeid] then
				self:Remove(i)
			end
		end
		self.aurasegment = nil
		self.nexttick = nil
		self.stacks:SetText()
	end
	
	if UnitExists('target') then
		self:UNIT_AURA('target')
	end
end

local SpellFrame_RemoveTicksAfter = function (self, min)
	local indicators = self.indicators
	for i = #indicators,1,-1 do
		local ind = indicators[i]
		if ind.typeid == 'tick' and ind.time>min then
			self:Remove(i)
		end
	end
	self.nexttick = nil
end

local mainframe_CLEU_OtherInterestingSpell = function (self, time, event, srcguid, srcname, srcflags, destguid, destname, destflags, spellid, spellname)
	local now = GetTime()

	if EventHorizon.otherIDs[spellname] then
		local id = EventHorizon.otherIDs[spellname]
		if event == 'SPELL_CAST_SUCCESS' or event == 'SPELL_DAMAGE' and id.isGlyph then		-- Glyph refresh
			if id.last and (now < (id.last + 0.9)) then		-- Throttle heavily, don't want stacks getting blown
				--debug("Ignoring "..event.." from "..spellname.." at "..now)
				return
			else
				--debug("Interesting spell potentially not in frame detected! Spell: "..spellname,event)
				id.last = now
				local bar
				local bf = EventHorizon.frames.frames
				for i in pairs(bf) do
					local gr = bf[i].glyphrefresh or nil
					local gs = bf[i].glyphstacks or nil
					if gr and (gr[3] == spellname) then
						if gs[destguid] then
							gs[destguid] = gs[destguid] - 1
							bf[i].stacks:SetText(gs[destguid] > 0 and gs[destguid] or nil)
						end
						--debug("SUCCESS! "..gr[3].." has triggered "..frame[i].auraname)
					end
				end
			end
		end
	end
end

local SpellFrame_COMBAT_LOG_EVENT_UNFILTERED = function (self, time, event, srcguid,srcname,srcflags, destguid,destname,destflags, spellid,spellname)
	local now = GetTime()
	
	--debug(event, spellname, spellid)
	if event == 'SPELL_AURA_REMOVED' then
		if self.glyphrefresh then
			self.glyphstacks[destguid] = 0
		end
	end
	
	if event == 'SPELL_CAST_SUCCESS' then
		--debug('SPELL_CAST_SUCCESS',destguid)
		self.castsuccess[destguid] = now

		if self.glyphrefresh then
			for i = 1,6 do
				if EventHorizon.glyphs[i] == self.glyphrefresh[2] then
					self.glyphstacks[destguid] = self.glyphrefresh[1]
					self.stacks:SetText(self.glyphstacks[destguid])
				end
			end
		end
	elseif tickevents[event] then
		if UnitGUID(self.auraunit or 'target')==destguid then
			local tick = self:AddIndicator('tick', 'tick', now)
			tick.happened = true
			
			if (self.dot and (self.stop and self.stop ~= nil)) then
				if self.isHasted and self.ticks then
					self.dotMod = now - self.ticks.last
					self.ticks.last = now
				end
				self:RemoveTicksAfter(now) -- Reconstruct ticks from spellframe info
				local nexttick = now+(self.dotMod or self.dot)
				self.nexttick = nil
				while nexttick<=(self.stop+0.2) do -- Account for lag
					if now+future<nexttick then
						-- The next tick is not visible yet.
						self.nexttick = nexttick
						self.lasttick = self.stop
						break
					end
					if now+past<=nexttick then
						-- The next tick is visible.
						local tick = self:AddIndicator('tick', 'tick', nexttick)
						if nexttick<=now then
							tick.happened = true
						end
						self.latesttick = nexttick
					end
					nexttick=nexttick+(self.dotMod or self.dot)
				end	
			end
		end
	end
end

local SpellFrame_UNIT_AURA_refreshable = function (self, unitid)
	if unitid~=self.auraunit then return end
	local name, rank, icon, count, debuffType, duration, expirationTime, source, _, _, spellID = self.AuraFunction(self.auraunit, self.auraname)
	local afflicted = name and (self.unique or source=='player') and (not self.minstacks or count>=self.minstacks)
	local addnew, refresh
	local now = GetTime()
	local guid = UnitGUID(self.auraunit or 'target')
	-- First find out if the debuff was refreshed.
	local start
	
	if self.uniqueID and self.uniqueID ~= spellID then
		return
	end
	
	if self.aurasegment and expirationTime == 0 and duration == 0 then	-- Timeless aura, bar exists (Overkill)
		for i = #self.indicators,1,-1 do
			self:Remove(i)
		end
		self.aurasegment = nil
		self.nexttick = nil
		self.stacks:SetText()
		return
	end
	
	if expirationTime == 0 then
		return
	end
	
	if afflicted then
		start = expirationTime-duration
		if icon and not(self.cast or self.slotID or self.keepIcon) then self.icon:SetTexture(icon) end
		if self.targetdebuff then
			if self.targetdebuff.stop == expirationTime then
				start = self.targetdebuff.start
			else
				-- Check for refresh. 
				if start < self.targetdebuff.stop then
					local totalduration = self.targetdebuff.stop - self.targetdebuff.start
					local lasttick = self.targetdebuff.stop - math.fmod(totalduration, self.dotMod or self.dot)
					local success = self.castsuccess[guid]
					local not_recast = true -- Poisons are never actually recast, so we default to true here, because success will always be nil.
					if success then
						not_recast = math.abs(success-start)>0.5
					end
					if not_recast and start < lasttick then
						-- The current debuff was refreshed.
						start = self.targetdebuff.start
						refresh = true
					end
				end
			end
		end
		if self.aurasegment then
			if expirationTime~=self.aurasegment.stop and not refresh then
				-- The current debuff was replaced.
				self.aurasegment.stop = start-0.2
				self:RemoveTicksAfter(start)

				--debug('replaced')
				addnew = true
			end
		else
			addnew = true
		end
		if count>0 then
			self.stacks:SetFormattedText('%d',count)
		end
	else
		if self.aurasegment then
			if math.abs(self.aurasegment.stop - now)>0.3 then
				-- The current debuff ended.
				self.aurasegment.stop = now
			end
			self:RemoveTicksAfter(now)
			self.aurasegment = nil
			self.targetdebuff = nil
			self.stacks:SetText()
		end
	end
	self:UpdateDoT(addnew, source, now, start, expirationTime, name, refresh, guid)
end

local SpellFrame_UpdateDoT = function (self, addnew, source, now, start, expirationTime, name, refresh, guid)
	local addticks
	local isHasted
	local checkDoT = self.auranamePrimary or name
	local isPrimary = checkDoT == name or nil
	
	local targ = UnitName(self.auraunit)
	if addnew then
		--debug('addnew', start, expirationTime)
		local typeid = (source=='player' and self.isType) or (self.isType == 'debuffmine' and source~='player' and 'debuff')
		if self.cast and self.useSmalldebuff then
			self.aurasegment = self:AddSegment(typeid, 'smalldebuff', start, expirationTime)
			local hastedcasttime = select(7, GetSpellInfo(self.spellname))/1000
			self.cantcast = self:AddSegment(typeid, 'cantcast', start, expirationTime-hastedcasttime)
			self.aurasegment.lastunit = targ
		else
			self.aurasegment = self:AddSegment(typeid, 'default', start, expirationTime)
			self.aurasegment.lastunit = targ
		end
		-- Add visible ticks.
		if self.dot and isPrimary then
			addticks = start
		end
		if self.debuffs then
			-- Refreshable only.
			self.targetdebuff = {start=start, stop=expirationTime}
			self.debuffs[guid] = self.targetdebuff
		end
	elseif refresh then
		-- debug('refresh', start, expirationTime)
		-- Note: refresh requires afflicted and self.targetdebuff. Also, afflicted and not self.debuff implies addnew.
		-- So we can get here only if afflicted and self.debuff and self.targetdebuff.
		self.aurasegment.stop = expirationTime
		self.targetdebuff.stop = expirationTime
		if self.latesttick then
			addticks = self.latesttick
		end
	end
	if addticks then
		local nexttick = addticks+(self.dotMod or self.dot)
		self.nexttick = nil
		
		if self.hasted then
			if type(self.hasted) == 'number' then
				for i = 1,6 do
					if EventHorizon.glyphs[i] == self.hasted then isHasted = true end
				end
			elseif type(self.hasted) == 'table' then
				isHasted = (select(5,GetTalentInfo(self.hasted[1],self.hasted[2]))) > 0 or nil
			end
		end
		
		if isHasted and self.ticks then					-- Tick-process haste handling
				local tooShort = self.ticks.last and (now - self.ticks.last < 1.5) and true or nil
				self.ticks.last = self.ticks.last and ((now - self.ticks.last < 3) and not tooShort) and self.ticks.last or now
				self.isHasted = true
		elseif isHasted and self.expectedTicks then		-- Using expectedTicks
				self.dotMod = (expirationTime - start)/self.expectedTicks
				local name, rank,_,_,_,_,_ = UnitBuff(self.auraunit, "Mage Armor")
				if self.dot and (rank and (rank == "Rank 5" or rank == "Rank 6")) and self.dotMod <= 1.5 then self.dotMod = self.dotMod * 2 end		-- Adjust for mage armor rank 5+ 50% duration reduction, use number comparison to make sure we're not changing something that shouldn't be.
		end
		
		while nexttick<=expirationTime do
			if now+future<nexttick then
				-- The next tick is not visible yet.
				self.nexttick = nexttick
				self.lasttick = expirationTime
				break
			end
			if now+past<=nexttick then
				-- The next tick is visible.
				local tick = self:AddIndicator('tick', 'tick', nexttick)
				if nexttick<=now then
					tick.happened = true
				end
				self.latesttick = nexttick
			end
			nexttick=nexttick+(self.dotMod or self.dot)
		end
	end
	self.start, self.stop = start, expirationTime
end

local SpellFrame_PLAYER_REGEN_ENABLED = function (self)
	local thresh = GetTime() - 10
	local remove = {}
	for guid,data in pairs(self.debuffs) do
		if data.stop < thresh then
			tinsert(remove, guid)
		end
	end
	for _,guid in ipairs(remove) do
		--debug('removing',guid,self.spellname)
		self.debuffs[guid]=nil
	end
end

local SpellFrame_PLAYER_TARGET_CHANGED_refreshable = function (self)
	--debug(self.spellname, 'PLAYER_TARGET_CHANGED_refreshable')
	if self.auraunit ~= 'target' then return end
	if self.aurasegment then
		--debug(self.spellname, 'removing old')
		for i = #self.indicators,1,-1 do
			local ind = self.indicators[i]
			if typeids[ind.typeid] then
				self:Remove(i)
			end
		end
		self.aurasegment = nil
		self.targetdebuff = nil
		self.nexttick = nil
		self.stacks:SetText()
	end

	if UnitExists('target') then
		if UnitIsDead('target') then
			self.debuffs[UnitGUID('target')] = nil
		else
			self.targetdebuff = self.debuffs[UnitGUID('target')]
			--if self.targetdebuff then debug(self.spellname, 'have old') end
			self:UNIT_AURA('target')
			--if self.aurasegment then debug(self.spellname, 'added new') end
			if self.glyphstacks and self.aurasegment then
				if self.glyphstacks[UnitGUID('target')] and (self.glyphstacks[UnitGUID('target')] > 0) then
					self.stacks:SetText(self.glyphstacks[UnitGUID('target')])
				end
			end
		end
	end
end

local SpellFrame_SPELL_UPDATE_COOLDOWN = function (self)
	local start, duration, enabled = self.CooldownFunction(self.cooldownID or self.spellname)
	local ready = enabled==1 and start~=0 and duration and start+duration
	if ready and duration>1.5 then
		-- The spell is on cooldown, but not just because of the GCD.
		if self.cooldown ~= ready then
			--if self.coolingdown and (self.coolingdown.stop>start or self.coolingdown.start<ready) then debug('overlapping cooldown', self.spellname, start, ready) end
			self.coolingdown = self:AddSegment('cooldown', 'cooldown', start, ready)
			self.cooldown = ready
		end
	else
		if self.coolingdown then
			-- The spell was on cooldown, but now it's not (or it's on cooldown, but just because of the GCD).
			local now = GetTime()
			-- See when the cooldown is ready. If the spell is currently on GCD, check the GCD end; otherwise check now.
			if self.cooldown > (ready or now) then
				-- The cooldown ended earlier.
				self.coolingdown.stop = now
			end
			self.coolingdown = nil
		end
		self.cooldown = nil
	end
end

local lastEQC
local SpellFrame_PLAYER_EQUIPMENT_CHANGED = function (self)
	if not self.slotID then return end
	
	local now = GetTime()
	if self.lastEQC and ((now - self.lastEQC) < 0.1) then return end -- Kill the function if the last equipcheck was less than 100ms ago.
	self.lastEQC = now
	
	--if self.aurasegment then	-- Get rid of any active cds if needed...
		for i = #self.indicators,1,-1 do
			self:Remove(i)
		end
		self.aurasegment = nil
		self.nexttick = nil
		self.stacks:SetText()
	--end
	self.cooldown = 0
	--for k,v in ipairs(self.indicators) do print(k,v) end
	
	local name,tex,_
	local itemID = GetInventoryItemID('player',self.slotID)
	name,_,_,_,_,_,_,_,_,tex,_ = GetItemInfo(itemID or 12846) -- Dirty tricks 101: Blacklist the unknown.
	if itemID and not(EventHorizon.trinkets.blacklist[name]) then
		self.spellname = name
		self.playerbuff = 50246	-- Goblin binary. One of those "just in case" things.
		self.icon:SetTexture(tex)
		self.internalcooldown = true
		
		self.stance = true -- Yeah, I know. Lazy.
		
		if EventHorizon.trinkets[name] then
			if type(EventHorizon.trinkets[name]) == 'number' then
				self.playerbuff = EventHorizon.trinkets[name]
			elseif type(EventHorizon.trinkets[name]) == 'table' then
				self.playerbuff = EventHorizon.trinkets[name][1]
				self.internalcooldown = EventHorizon.trinkets[name][2]
			end
		elseif self.slotID == 10 then
			self.playerbuff = 54758		-- Engy gloves
		elseif self.slotID == 8 then
			self.playerbuff = 54861		-- Nitro Boosts
		end
		
		if type(self.playerbuff)=='number' then
			self.auraname = (GetSpellInfo(self.playerbuff))
		elseif type(self.playerbuff)=='table' then
			self.auraname = {}
			self.auranamePrimary = (GetSpellInfo(self.playerbuff[1]))
			for i,id in ipairs(self.playerbuff) do
				tinsert(self.auraname, (GetSpellInfo(id)))
			end
			self.AuraFunction = UnitBuffUnique
		else
			self.auraname = self.spellname
		end
		
	else
		self.stance = 50 -- We just really don't want this showing. This is the really lazy way of doing it.
		self.spellname = nil
		self.auraname = "01001000"
		self.internalcooldown = true
		self.icon:SetTexture(0,0,0,0)
	end
	
	mainframe:UPDATE_SHAPESHIFT_FORM()
	self:SPELL_UPDATE_COOLDOWN()
end

--[[
Things get ugly again here.
UNIT_AURA does not fire for mouseover units, so we need to emulate it.
UPDATE_MOUSEOVER_UNIT does not fire when a mouseover unit is cleared, so we need to emulate that as well.
The UMU check is unthrottled by necessity. UNIT_AURA doesn't really need to be run more than 10 times per second, so it gets throttled to save cycles.
]]--
local TTL,TSLU = 0.1,0
local UpdateMouseover = function (self,elapsed)
	TSLU = TSLU+elapsed
	if not(UnitExists('mouseover')) then
		EventHorizon:CheckMouseover()
		frame:SetScript('OnUpdate',nil)
	else
		while(TSLU >= TTL) do
			for i,spellframe in ipairs(EventHorizon.frames.mouseover) do
				spellframe:UNIT_AURA('mouseover')
				TSLU = TSLU-TTL
			end
		end
	end
end

local SpellFrame_UPDATE_MOUSEOVER_UNIT = function (self)
	--print("UPDATE_MOUSEOVER_UNIT")
	if UnitExists('mouseover') then
		isMouseover = true
		self.auraunit = 'mouseover'
	else
		isMouseover = nil
		self.auraunit = self.baseunit
	end
	frame:SetScript('OnUpdate',UpdateMouseover)
	
	if self.aurasegment then
		for i = #self.indicators,1,-1 do
			local ind = self.indicators[i]
			if typeids[ind.typeid] then
				self:Remove(i)
			end
		end
		self.aurasegment = nil
		self.nexttick = nil
		self.stacks:SetText()
	end
	
	if self.refreshable then
		if UnitExists(self.auraunit) then
			if UnitIsDead(self.auraunit) then
				self.debuffs[UnitGUID(self.auraunit)] = nil
			else
				self.targetdebuff = self.debuffs[UnitGUID(self.auraunit)]
				--if self.targetdebuff then debug(self.spellname, 'have old') end
				self:UNIT_AURA(self.auraunit)
				--if self.aurasegment then debug(self.spellname, 'added new') end
				if self.glyphstacks and self.aurasegment then
					if self.glyphstacks[UnitGUID(self.auraunit)] and (self.glyphstacks[UnitGUID(self.auraunit)] > 0) then
						self.stacks:SetText(self.glyphstacks[UnitGUID(self.auraunit)])
					end
				end
			end
		end
	elseif UnitExists(self.auraunit) then
		self:UNIT_AURA(self.auraunit)
	end
end

-- A SpellFrame is active (i.e. listening to events) iff the talent requirements are met.
-- The table EventHorizon.frames.active contains all the active frames.
-- If the stance requirement is not met, the frame is hidden, but still active.
local SpellFrame_Deactivate = function (self)
	if not self.isActive then return end
	--debug('unregistering events for', self.spellname)
	self:UnregisterAllEvents()
	if self.interestingCLEU then
		mainframe.framebyspell[self.spellname] = nil
	end
	self:Hide()
	for index=#self.indicators,1,-1 do
		self:Remove(index)
	end
	self.isActive = nil
end

local SpellFrame_Activate = function (self)
	if self.isActive then return end
	--debug('registering events for', self.spellname)
	for event in pairs(self.interestingEvent) do
		self:RegisterEvent(event)
	end
	if self.interestingCLEU then
		mainframe.framebyspell[self.spellname] = self
	end

	self:Show()
	self.isActive = true
end

local mainframe_PLAYER_TALENT_UPDATE = function (self)
	--debug('PLAYER_TALENT_UPDATE')
	EventHorizon:CheckTalents()
end


local HaveRequiredTalent = function (config)
	local result = true
	if config.requiredTalent then
		-- If requiredPoints is present, currentRank==requiredPoints is required.
		-- Otherwise, currentRank>0 is required.
		for i,req in ipairs(config.requiredTalent) do
			local tab,index,requiredPoints = unpack(req)
			local currentRank = (select(5,GetTalentInfo(tab,index))) or 0
			if requiredPoints then
				result = currentRank == requiredPoints
			else
				result = currentRank > 0
			end
			if not result then
				break
			end
		end
	end
	return result
end

local HaveRequiredGlyph = function (config)
	local result = true
	if config.requiredGlyph then
		result = nil
		for i = 1, 6 do
			local enabled,_,gsID,_ = GetGlyphSocketInfo(i)
			if enabled and gsID then
				if gsID == config.requiredGlyph then
					result = true
					--debug("Required glyph detected: ",gsID,EventHorizon.glyphs[gsID])
				end
			end
		end
	end
	return result
end

function EventHorizon:SetFrameDimensions()
	local left,right,top,bottom = 0.07, 0.93, 0.07, 0.93
	local barheight2 = self.config.height
	local modHeight = self.config.height
	
	if self.config.staticheight and type(self.config.staticheight) == 'number' then	
		mainframe:SetHeight(self.config.staticheight)
		barheight = (self.config.staticheight - (barspacing*(numframes - 1)))/numframes
		modHeight = barheight
		local ratio = barheight/barheight2
		ratio = math.abs( (1-(1/ratio))/2 )	-- Yes, this was a bitch to figure out.
		if barheight > barheight2 then	-- icon is taller than it is wide
			left = left + ratio
			right = right - ratio
		else
			top = top + ratio
			bottom = bottom - ratio
		end
	else
		barheight = barheight2
		mainframe:SetHeight(numframes * (barheight+barspacing) - barspacing)
	end
	
	local sfi = self.config.hideIcons
	local nowleft = -past/(future-past)*barwidth-0.5 + (sfi and 0 or self.config.height)
	if nowIndicator then
		nowIndicator:SetPoint('BOTTOM',mainframe,'BOTTOM')
		nowIndicator:SetPoint('TOPLEFT',mainframe,'TOPLEFT', nowleft, 0)
		nowIndicator:SetWidth(onepixelwide)
		nowIndicator:SetTexture(unpack(self.colors.nowLine))
	end
	
	for i,spellframe in ipairs(EventHorizon.frames.shown) do
		--spellframe:ClearAllPoints()
		spellframe:SetHeight(barheight)
		spellframe:SetWidth(barwidth)
		
		spellframe.icon:ClearAllPoints()
		spellframe:SetPoint('RIGHT', mainframe, 'RIGHT')
		if i == 1 then
			spellframe:SetPoint('TOPLEFT', mainframe, 'TOPLEFT', sfi and 0 or barheight2, 0)
		else
			spellframe:SetPoint('TOPLEFT', EventHorizon.frames.shown[i-1], 'BOTTOMLEFT', 0, -barspacing)
		end
		if not(sfi) then
			spellframe.icon:SetPoint('TOPRIGHT',spellframe,'TOPLEFT')
			spellframe.icon:SetWidth(barheight2)
			spellframe.icon:SetHeight(modHeight)
			spellframe.icon:SetTexCoord(left,right,top,bottom)
		end

		for i,indicator in ipairs(spellframe.indicators) do
			local ndtex, ndcol
			local typeid = indicator.typeid
			local layoutid = indicator.layoutid
			local usetexture
			
			if not(exemptColors[typeid]) and self.bartexture then ndtex = self.bartexture end
			if typeid and customColors[typeid] then
				usetexture = true
				if spellframe.barcolorunique and typeid == 'debuff' then
					ndcol = spellframe.barcolorunique
				elseif spellframe.barcolor then
					ndcol = spellframe.barcolor
				end
			elseif typeid == 'cooldown' then
				usetexture = true
			end
			usetexture = usetexture and texturedbars
			
			-- Layout
			local layouts = EventHorizon.layouts
			local layout = layouts[layoutid] or layouts.default
			local color = ndcol or EventHorizon.colors[typeid] or EventHorizon.colors.default
			
			if layoutid == 'frameline' then
				color = typeid == 'sent' and EventHorizon.colors.castLine or EventHorizon.colors[typeid]
				indicator:SetPoint('TOP',EventHorizon.mainframe)
				indicator:SetPoint('BOTTOM',EventHorizon.mainframe)
			else
				indicator:SetPoint('TOP',spellframe, 'TOP', 0, -layout.top*barheight)
				indicator:SetPoint('BOTTOM',spellframe, 'TOP', 0, -layout.bottom*barheight)
			end
			
			if usetexture then
				indicator:SetTexture(ndtex or bartexture)
				indicator:SetTexCoord(unpack(layout.texcoords))
			else
				indicator:SetTexture(1,1,1,1)
			end
			indicator:SetVertexColor(unpack(ndcol or color))
		end
	end
end

function EventHorizon:CheckTalents()
	table.wipe(self.frames.active)
	table.wipe(self.frames.mouseover)
	for i,config in ipairs(self.frames.config) do
		local frameNeeded = HaveRequiredTalent(config) and HaveRequiredGlyph(config) or nil
		-- Check if there already is a frame
		local spellframe = self.frames.frames[i]
		local frameExists = spellframe~=nil
		--debug('checking frame',i,': frameExists',frameExists,', frameNeeded ',frameNeeded)

		if frameNeeded then
			if frameExists then
				spellframe:Activate()
			else
				spellframe = self:CreateSpellBar(config)
				self.frames.frames[i] = spellframe
			end
			table.insert(self.frames.active, spellframe)
			if spellframe.usemouseover then
				table.insert(self.frames.mouseover, spellframe)
			end
		else
			if frameExists then
				spellframe:Deactivate()
			end
		end
	end

	local activate = #self.frames.active > 0
	self:Activate(activate)
	if activate then
		mainframe:UPDATE_SHAPESHIFT_FORM()
	end
end

local mainframe_UPDATE_SHAPESHIFT_FORM = function (self)
	--debug('UPDATE_SHAPESHIFT_FORM', 'GetShapeshiftForm()',GetShapeshiftForm(),'GetShapeshiftForm(true)',GetShapeshiftForm(true), 'GetNumShapeshiftForms()',GetNumShapeshiftForms())
	local stance = GetShapeshiftForm()
	-- On PLAYER_LOGIN, GetShapeshiftForm() sometimes returns a bogus value (2 on a priest with 1 form). No need to act upon it.
	if not stance or (GetNumShapeshiftForms() and stance>GetNumShapeshiftForms()) then return end
	mainframe:SetHeight(1)
	numframes = 0
	table.wipe(EventHorizon.frames.shown)
	
	EventHorizon.glyphs = {}
	for i = 1, 6 do
		local enabled,_,gsID,_ = GetGlyphSocketInfo(i)
		if enabled and gsID then
			EventHorizon.glyphs[i] = gsID
		else
			EventHorizon.glyphs[i] = nil
		end
	end
	for i,spellframe in ipairs(EventHorizon.frames.active) do
		local shown = spellframe:IsShown()
		
		if spellframe.stance then
			shown = false
			if type(spellframe.stance) == 'table' then
				shown = false
				for i in spellframe.stance do
					if spellframe.stance[i] == stance then
						shown = true
					end
				end
			elseif spellframe.stance == true then
				shown = true
			elseif spellframe.stance == stance and not shown then
				shown = true
			elseif spellframe.stance and spellframe.stance ~= stance and shown then
				shown = false
			end
		end
		
		if spellframe.notstance then
			shown = true
			if spellframe.notstance and type(spellframe.notstance) == 'table' then
				for i in spellframe.notstance do
					if spellframe.notstance[i] == stance then
						shown = false
					end
				end
			elseif spellframe.notstance == stance then
				shown = false
			end
		end

		if shown then
			spellframe:Show()
			numframes = numframes+1
			table.insert(EventHorizon.frames.shown,spellframe)
		else
			spellframe:Hide()
			for i,indicator in ipairs(spellframe.indicators) do
				indicator:Hide()
			end
		end	
	end
	
	if numframes>0 then
		EventHorizon:SetFrameDimensions()
		if EventHorizon.isActive == true and visibleFrame then
			mainframe:Show()
		end
	else
		mainframe:Hide()
	end
	
	return true
end

function EventHorizon:CheckMouseover()
	for i,spellframe in ipairs(self.frames.mouseover) do
		spellframe:UPDATE_MOUSEOVER_UNIT()
	end
end

-- GCD indicator
local mainframe_SPELL_UPDATE_COOLDOWN = function (self)
	if gcdIndicator then
		local start, duration = GetSpellCooldown(gcdSpellName)
		local sfi = EventHorizon.config.hideIcons
		if start and duration and duration>0 then
			gcdend = start+duration
			mainframe:SetScript('OnUpdate', function (self, elapsed)
				if gcdend then
					local now = GetTime()
					if gcdend<=now then
						gcdend = nil
						gcdIndicator:Hide()
					else
						local diff = now+past
						local p = (gcdend-diff)*scale
						if p<=1 then
							gcdIndicator:SetPoint('RIGHT', self, 'RIGHT',(p-1)*barwidth+onepixelwide, 0)
							gcdIndicator:Show()
						end
					end
				end
			end)
		else
			gcdend = nil
			gcdIndicator:Hide()
			mainframe:SetScript('OnUpdate', nil)
		end
	end
end

-- Dispatch the CLEU.
local mainframe_COMBAT_LOG_EVENT_UNFILTERED = function (self,time, event, srcguid,srcname,srcflags, destguid,destname,destflags, spellid,spellname)
	if srcguid~=playerguid or event:sub(1,5)~='SPELL' then return end
	local spellframe = self.framebyspell[spellname]
	if EventHorizon.otherIDs[spellname] then
		mainframe:CLEU_OtherInterestingSpell(time, event, srcguid,srcname,srcflags, destguid,destname,destflags, spellid,spellname)
	end
	if spellframe then
		if spellframe.interestingCLEU[event] then 
			spellframe:COMBAT_LOG_EVENT_UNFILTERED(time, event, srcguid,srcname,srcflags, destguid,destname,destflags, spellid,spellname) 
		end
	end
end

function EventHorizon:LoadClassModule()
	local class = select(2,UnitClass('player'))
	
	class = class:sub(1,1)..class:sub(2):lower() -- 'WARLOCK' -> 'Warlock'
	
	local name, _, _, enabled, loadable = GetAddOnInfo('EventHorizon_'..class)

	DisableAddOn('EventHorizon_Redshift')
	DisableAddOn('EventHorizon_Lines')
	
	if not enabled or not loadable then 
		return 
	end
	local loaded, reason = LoadAddOn(name)
	if loaded and self.InitializeClass then
		return true
	end
end

--[[
spellid: number, rank doesn't matter
abbrev: string
config: table
{
	cast = <boolean>,
	channeled = <boolean>,
	numhits = <number of hits per channel>,
	cooldown = <boolean>,
	debuff = <boolean>,
	dot = <tick interval in s, requires debuff>,
	refreshable = <boolean>,
}
--]]
function EventHorizon:NewSpell(config)
	local spellid = config.spellID or config.itemID or config.slotID
	if type(spellid)~='number' then 
		return 
	end

	-- Make requiredTalent a list of required talents if only one is specified.
	if config.requiredTalent and type(config.requiredTalent[1])~='table' then
		config.requiredTalent = {config.requiredTalent}
	end

	table.insert(self.frames.config, config)
end

--Set spellframe attributes separately from bar creation. Helps keep things tidy and all, y'know?
local function SetSpellAttributes(spellframe,config)
	local interestingEvent = {}
	local config = config
	local otherids = EventHorizon.otherIDs
	local spellname = spellframe.spellname
	interestingEvent['UNIT_SPELLCAST_SENT'] = true
	
	if config.itemID or config.slotID then
		spellframe.cooldown = true	-- Not getting out of this one. It's an item, what else do you watch?
		spellframe.CooldownFunction = GetItemCooldown
		interestingEvent['SPELL_UPDATE_COOLDOWN'] = true
		interestingEvent['BAG_UPDATE_COOLDOWN'] = true
		if config.slotID then
			config.playerbuff = true
			config.internalcooldown = true	-- Failsafe
			interestingEvent['PLAYER_EQUIPMENT_CHANGED'] = true
		end
	end
	
	if config.channeled then
		interestingEvent['UNIT_SPELLCAST_CHANNEL_START'] = true
		interestingEvent['UNIT_SPELLCAST_CHANNEL_STOP'] = true
		interestingEvent['UNIT_SPELLCAST_CHANNEL_UPDATE'] = true
		if config.numhits then
			-- Register for the CLEU tick event.
			spellframe.interestingCLEU = {SPELL_DAMAGE=true}
			spellframe.numhits = config.numhits
		end
	elseif config.cast then
		spellframe.cast = config.cast
		interestingEvent['UNIT_SPELLCAST_START'] = true
		interestingEvent['UNIT_SPELLCAST_STOP'] = true
		interestingEvent['UNIT_SPELLCAST_DELAYED'] = true
		if ((config.debuff or config.playerbuff) and type(config.debuff or config.playerbuff) == 'boolean') then
			spellframe.useSmalldebuff = true
		end
	end

	if config.cooldown then
		if type(config.cooldown) == 'number' then
			spellframe.cooldownID = GetSpellInfo(config.cooldown)
			spellframe.cooldown = true
		else
			spellframe.cooldown = config.cooldown
		end
		spellframe.CooldownFunction = GetSpellCooldown
		interestingEvent['SPELL_UPDATE_COOLDOWN'] = true
	end
		

	if config.stance then
		spellframe.stance = config.stance
	end
	
	if config.notstance then
		spellframe.notstance = config.notstance
	end

	if config.debuff then
		spellframe.isType = 'debuffmine'
		spellframe.AuraFunction = UnitDebuff
		spellframe.auraunit = config.auraunit or 'target'
		if spellframe.auraunit == 'mouseover' then
			interestingEvent['UPDATE_MOUSEOVER_UNIT'] = true
			spellframe.usemouseover = true
			spellframe.baseunit = config.baseunit or 'target'
		end
		if type(config.debuff)=='number' then
			spellframe.auraname = (GetSpellInfo(config.debuff))
		elseif type(config.debuff)=='table' then
			spellframe.auranamePrimary = (GetSpellInfo(config.spellID))
			spellframe.auraname = {}
			for i,id in ipairs(config.debuff) do
				tinsert(spellframe.auraname, (GetSpellInfo(id)))
			end
			spellframe.AuraFunction = UnitDebuffUnique
		else
			spellframe.auraname = spellname
		end
		interestingEvent['UNIT_AURA'] = true
		interestingEvent['PLAYER_TARGET_CHANGED'] = true
		spellframe.minstacks = config.minstacks
		if config.dot then
			spellframe.dot = config.dot
			spellframe.interestingCLEU = {SPELL_PERIODIC_DAMAGE=true}
			if config.refreshable then
				spellframe.refreshable = true
				spellframe.UNIT_AURA = SpellFrame.UNIT_AURA_refreshable
				spellframe.PLAYER_TARGET_CHANGED = SpellFrame.PLAYER_TARGET_CHANGED_refreshable
				interestingEvent['PLAYER_REGEN_ENABLED'] = true
				spellframe.interestingCLEU.SPELL_CAST_SUCCESS=true
				spellframe.debuffs = {}
				spellframe.castsuccess = {}
			end
			if config.hasted then
				spellframe.hasted = config.hasted
				if config.expectedTicks and type(config.expectedTicks) == "number" then
					spellframe.expectedTicks = config.expectedTicks
				else
					spellframe.ticks = {}
				end
			end
		end
	elseif config.playerbuff then
		spellframe.isType = 'playerbuff'
		spellframe.AuraFunction = UnitBuff
		spellframe.auraunit = config.auraunit or 'player'
		if config.auraunit then
			interestingEvent['PLAYER_TARGET_CHANGED'] = true
		end
		if spellframe.auraunit == 'mouseover' then
			interestingEvent['UPDATE_MOUSEOVER_UNIT'] = true
			spellframe.usemouseover = true
			spellframe.baseunit = config.baseunit or 'target'
		end
		spellframe.alwaysrefresh = true
		interestingEvent['UNIT_AURA'] = true
		if type(config.playerbuff)=='number' then
			spellframe.auraname = (GetSpellInfo(config.playerbuff))
		elseif type(config.playerbuff)=='table' then
			spellframe.auraname = {}
			spellframe.auranamePrimary = (GetSpellInfo(config.spellID))
			for i,id in ipairs(config.playerbuff) do
				tinsert(spellframe.auraname, (GetSpellInfo(id)))
			end
			spellframe.AuraFunction = UnitBuffUnique
		else
			spellframe.auraname = spellname
		end
		
		if config.internalcooldown then
			spellframe.internalcooldown = config.internalcooldown
		end
		
		if config.dot then		-- Register for periodic effect intervals.
			spellframe.dot = config.dot
			spellframe.interestingCLEU = {SPELL_PERIODIC_HEAL=true}
			if config.refreshable then
				spellframe.refreshable = true
				spellframe.UNIT_AURA = SpellFrame.UNIT_AURA_refreshable
				spellframe.PLAYER_TARGET_CHANGED = SpellFrame.PLAYER_TARGET_CHANGED_refreshable
				interestingEvent['PLAYER_REGEN_ENABLED'] = true
				spellframe.interestingCLEU.SPELL_CAST_SUCCESS=true
				spellframe.debuffs = {}
				spellframe.castsuccess = {}
			end
			if config.hasted then
				spellframe.hasted = config.hasted
				if config.expectedTicks and type(config.expectedTicks) == "number" then
					spellframe.expectedTicks = config.expectedTicks
				else
					spellframe.ticks = {}
				end
			end
		end
	end
	
	if config.cleu or config.event then -- Register custom CLEU events.
		if config.event then -- Optional alias for the forgetful.
			config.cleu = config.event
		end
		if not spellframe.interestingCLEU then
			spellframe.interestingCLEU = {}
		end
		if type(config.cleu) == 'string' then -- Single event
			spellframe.interestingCLEU[config.cleu] = true
		elseif type(config.cleu) == 'table' then
			for i in pairs(config.cleu) do -- Multiple events
				spellframe.interestingCLEU[ config.cleu[i] ] = true
			end
		end
	end	
	
	if config.glyphrefresh and type(config.glyphrefresh) == "table" then
		spellframe.glyphrefresh = config.glyphrefresh
		spellframe.glyphstacks = {}
		if not otherids[config.glyphrefresh[3]] then
			otherids[config.glyphrefresh[3]] = {}
		end
		otherids[config.glyphrefresh[3]][spellname] = true
		otherids[config.glyphrefresh[3]].isGlyph = true
		spellframe.interestingCLEU["SPELL_AURA_REMOVED"] = true
	end
	
	if config.reactive then
		-- Future reactive spell support.
	end
	
	if config.bartexture and type(config.bartexture) == 'string' then
		spellframe.bartexture = config.bartexture
	end
	
	if config.barcolor and type(config.barcolor) == 'table' then
		spellframe.barcolor = config.barcolor
	end
	
	if config.barcolorunique and type(config.barcolorunique) == 'table' then
		spellframe.barcolorunique = config.barcolorunique
	end
	
	if config.unique then
		spellframe.unique = config.unique
	end
	
	if config.uniqueID then
		spellframe.uniqueID = config.uniqueID
	end
	
	if config.keepIcon then
		spellframe.keepIcon = config.keepIcon
	end
	
	return interestingEvent
end


function EventHorizon:CreateSpellBar(config)
	local spellid = config.spellID
	local invid = config.itemID
	local csid = config.slotID
	local slotname, spellname, tex, _
	
	local spellframe = CreateFrame('Frame', nil, mainframe)
	mainframe.numframes = mainframe.numframes+1
	
	if spellid then
		spellname, _, tex = GetSpellInfo(spellid)
	elseif invid then
		spellname,_,_,_,_,_,_,_,_,tex,_ = GetItemInfo(invid)
	elseif csid then
		slotname = GetSlotName(csid)
		spellframe.slotID = csid
		spellframe.slotName = slotname
		local itemID = GetInventoryItemID('player',csid)
		if itemID then
			spellname,_,_,_,_,_,_,_,_,tex,_ = GetItemInfo(itemID)
		else
			spellname = slotName
			tex = nil
		end
	end
	local basename = slotname or spellname
	--debug('creating frame for ',spellname)
	spellframe.spellname = spellname

	-- Create the bar.
	spellframe.indicators = {}
	spellframe:SetBackdrop{bgFile = bartexture}
	spellframe:SetBackdropColor(unpack(barbgcolor))

	-- Create and set the spell icon.
	spellframe.icon = spellframe:CreateTexture(nil, 'BORDER')
	spellframe.icon:SetTexture(tex)

	spellframe.stacks = spellframe:CreateFontString(nil, 'OVERLAY')
	local sf = self.config.stackFont and type(self.config.stackFont) == 'string' and {self.config.stackFont, (self.config.stackFontSize and type(self.config.stackFontSize) == 'number') and self.config.stackFontSize or 12, (self.config.stackFontOutline and type(self.config.stackFontOutline) == 'string') and self.config.stackFontOutline or nil}
	local sfs = self.config.stackFontShadow and (type(self.config.stackFontShadow) == 'table' and self.config.stackFontShadow or {0,0,0,0.5}) or nil
	local sfso = (self.config.stackFontShadowOffset and type(self.config.stackFontShadowOffset) == 'table') and self.config.stackFontShadowOffset or {1,-1}
	local sfc = (self.config.stackFontColor and type(self.config.stackFontColor) == 'table') and self.config.stackFontColor or {1,1,1,1}
	if not(sf) then
		spellframe.stacks:SetFontObject('NumberFontNormalSmall')
	else
		spellframe.stacks:SetFont(unpack(sf))
		if sfs then
			spellframe.stacks:SetShadowColor(unpack(sfs))
			spellframe.stacks:SetShadowOffset(unpack(sfso))
		end
	end
	spellframe.stacks:SetVertexColor(unpack(sfc))

	for k,v in pairs(SpellFrame) do
		if not spellframe[k] then spellframe[k] = v end
	end
	
	spellframe.interestingEvent = SetSpellAttributes(spellframe,config)
	
	spellframe:SetScript('OnEvent', EventHandler)
	spellframe:SetScript('OnUpdate', spellframe.OnUpdate)
	
	local sfi = self.config.hideIcons
	local sor = self.config.stackOnRight
	-- Layout
	spellframe.stacks:SetPoint((sfi and not(sor)) and 'BOTTOMLEFT' or 'BOTTOMRIGHT', (sfi or sor) and spellframe or spellframe.icon, (sfi and not(sor)) and 'BOTTOMLEFT' or 'BOTTOMRIGHT')
	spellframe.stacks:SetJustifyH(sor and 'LEFT' or 'RIGHT')

	spellframe:Activate()
	
	if config.slotID then
		spellframe:PLAYER_EQUIPMENT_CHANGED()	-- Initialize trinkets and such if needed.
	end
	
	return spellframe
end

function EventHorizon:ActivateModule(module,slash)
	if EventHorizonDB[module].isActive ~= true then
		self.modules[module].isActive = true
		EventHorizonDB[module].isActive = true
		if not(self.modules[module].isReady == true) then self.modules[module].Init() end
		self.modules[module].Enable(slash)
	end
end

function EventHorizon:DeactivateModule(module,slash)
	if EventHorizonDB[module].isActive == true then
		self.modules[module].isActive = false
		EventHorizonDB[module].isActive = false
		if not(self.modules[module].isReady == true) then self.modules[module].Init() end
		self.modules[module].Disable(slash)
	end
end

function EventHorizon:ToggleModule(module,slash)
	if EventHorizonDB[module].isActive ~= true then
		self:ActivateModule(module,slash)
	else
		self:DeactivateModule(module,slash)
	end
end

function EventHorizon:Activate(...)
	local activate = select('#',...) == 0 or ...
	--debug('Activate',activate, ...)
	if not activate then
		return self:Deactivate()
	end

	if self.isActive then
		return
	end

	for k,v in pairs(mainframeEvents) do
		mainframe:RegisterEvent(k)
	end	
	
	if self.modules.redshift and self.modules.redshift.isActive ~= true then visibleFrame = true end
	if visibleFrame then mainframe:Show() end
	
	self.isActive = true
end

function EventHorizon:Deactivate()
	if self.isActive==false then
		return
	end
	mainframe:UnregisterAllEvents()
	mainframe:RegisterEvent('PLAYER_TALENT_UPDATE')

	mainframe:Hide()
	
	self.isActive = false
end

--[[
Should only be called after the DB is loaded and spell and talent information is available.
--]]
function EventHorizon:Initialize()
	-- Make sure this function is called only once.
	self.Initialize = nil

	--debug('GetTalentInfo(1,1)',GetTalentInfo(1,1))
	playerguid = UnitGUID('player')
	if not EventHorizonDB then EventHorizonDB = self.defaultDB end
		-- Upgrade DB.
	if EventHorizonDB and not EventHorizonDB.version then
		EventHorizonDB.version = 2
		EventHorizonDB.isActive = true
	end
	if EventHorizonDB.version ~= EventHorizon.defaultDB.version then
		print('Your savedvariables have been reset due to potential conflicts with older versions.')
		table.wipe(EventHorizonDB)
		EventHorizonDB = Clone(EventHorizon.defaultDB)
	end
	self.db = EventHorizonDB

	-- Create the main and spell frames.
	mainframe:SetHeight(1)
	mainframe.numframes = 0
	mainframe.framebyspell= {}
	mainframe:SetScript('OnEvent', EventHandler)
	mainframe:SetScale(self.config.scale or 1)

	if not self:LoadClassModule() then
		return
	end

	self:ApplyConfig()

	self:InitializeClass()
	if self.config.showTrinketBars and self.config.showTrinketBars == true then
		self:NewSpell({slotID = 13})
		self:NewSpell({slotID = 14})
	end
	
	local sfi = self.config.hideIcons
	mainframe:SetWidth(barwidth + (sfi and 0 or self.config.height))
	
	self:CheckTalents()
	self:SetupStyleFrame()		-- Spawn backdrop frame.
		
	-- Create the indicator for the current time.
	-- Bugfix: When the UI scale is at a very low setting, textures with a width of 1
	-- were not visible in some resolutions.
	local effectiveScale = mainframe:GetEffectiveScale()
	if effectiveScale then
		onepixelwide = 1/effectiveScale
	end
	nowI = CreateFrame('Frame',nil,mainframe)
	nowI:SetFrameLevel(20)
	nowIndicator = nowI:CreateTexture('EventHorizonNowIndicator', 'OVERLAY')
	
	local nowleft = -past/(future-past)*barwidth-0.5 + (sfi and 0 or self.config.height)
	nowIndicator:SetPoint('BOTTOM',mainframe,'BOTTOM')
	nowIndicator:SetPoint('TOPLEFT',mainframe,'TOPLEFT', nowleft, 0)
	nowIndicator:SetWidth(onepixelwide)
	nowIndicator:SetTexture(unpack(self.colors.nowLine))

	local anchor = self.config.anchor or {'TOPRIGHT', 'EventHorizonHandle', 'BOTTOMRIGHT'}
	if anchor[2]=='EventHorizonHandle' then
		-- Create the handle to reposition the frame.
		handle = CreateFrame('Frame', 'EventHorizonHandle', mainframe)
		handle:SetFrameStrata('HIGH')
		handle:SetWidth(10)
		handle:SetHeight(5)
		handle:EnableMouse(true)
		handle:SetClampedToScreen(1)
		handle:RegisterForDrag('LeftButton')
		handle:SetScript('OnDragStart', function(handle, button) handle:StartMoving() end)
		handle:SetScript('OnDragStop', function(handle) 
			handle:StopMovingOrSizing()
			local a,b,c,d,e = handle:GetPoint(1)
			if type(b)=='frame' then
				b=b:GetName()
			end
			EventHorizonDB.point = {a,b,c,d,e}
		end)
		handle:SetMovable(true)

		mainframe:SetPoint(unpack(anchor))
		handle:SetPoint(unpack(EventHorizonDB.point))

		handle.tex = handle:CreateTexture(nil, 'BORDER')
		handle.tex:SetAllPoints()
		handle:SetScript('OnEnter',function(frame) frame.tex:SetTexture(1,1,1,1) end)
		handle:SetScript('OnLeave',function(frame) frame.tex:SetTexture(1,1,1,0.1) end)
		handle.tex:SetTexture(1,1,1,0.1)
	end

	gcdSpellName = self.config.gcdSpellID and (GetSpellInfo(self.config.gcdSpellID))
	if gcdSpellName and self.config.gcdStyle then
		-- Create the GCD indicator, register cooldown event.
		gcdIndicator = mainframe:CreateTexture('EventHorizonGCDIndicator', 'BORDER')
		local nowleft = -past/(future-past)*barwidth-0.5 + barheight
		gcdIndicator:SetPoint('BOTTOM',mainframe,'BOTTOM')
		gcdIndicator:SetPoint('TOP',mainframe,'TOP')
		gcdIndicator:Hide()

		if self.config.gcdStyle == 'line' then
			gcdIndicator:SetWidth(onepixelwide)
		else
			gcdIndicator:SetPoint('LEFT',mainframe,'LEFT', nowleft, 0)
		end

		local gcdColor = self.colors.gcdColor or {.5,.5,.5,.3}
		gcdIndicator:SetTexture(unpack(gcdColor))
	end

	mainframe:SetPoint(unpack(anchor))

	SLASH_EVENTHORIZON1 = '/eventhorizon'
	SLASH_EVENTHORIZON2 = '/ehz'
	SlashCmdList['EVENTHORIZON'] = function(msg)
		if string.lower(msg) == 'help' then
			print'Use /eventhorizon or /ehz to enable or disable me.'
			print'If you want to toggle a plugin, "use /ehz PluginName" without the quotes.'
			print"If I'm lost, use \"/ehz reset\" to put me back in the middle of the screen."
			print('Currently installed plugins:')
			for i in pairs(self.modules) do print(i) end
		elseif string.lower(msg) == 'reset' then
			if anchor[2]=='EventHorizonHandle' then
				print'Resetting EventHorizon\'s position.'
				EventHorizonHandle:SetPoint(unpack(self.defaultDB.point))
				self:CheckTalents()
			else
				print'config.anchor in [my]config.lua is set to something other than EventHorizonHandle.'
				print"I've moved it for now, but you probably need to fix your config."
				mainframe:ClearAllPoints()
				mainframe:SetPoint('TOPLEFT',UIParent,'CENTER')
				self:CheckTalents()
			end
		elseif self.modules[string.lower(msg)] then
			self:ToggleModule(string.lower(msg))
			print(string.lower(msg)..' has been turned '..((self.modules[string.lower(msg)].isActive == true) and 'ON' or 'OFF')..'.')
		elseif self.isActive then
			print('Deactivating EventHorizon. Use "/ehz help" to see what else you can do.')
			self:Deactivate()
			mainframe:UnregisterEvent('PLAYER_TALENT_UPDATE')
		else
			print('Activating EventHorizon. Use "/ehz help" to see what else you can do.')
			self:Activate()
			self:CheckTalents()
		end
		EventHorizonDB.isActive = self.isActive
	end

	if not EventHorizonDB.isActive then
		self:Deactivate()
		mainframe:UnregisterEvent('PLAYER_TALENT_UPDATE')
	end
	
	for i,module in pairs(self.modules) do
		if not EventHorizonDB[i] then EventHorizonDB[i] = { isActive = true } end
		if EventHorizonDB[i] and EventHorizonDB[i].isActive == true then
			if not(self.modules[i].Enable) then self.modules[i].Enable = function () end end
			if not(self.modules[i].Disable) then self.modules[i].Disable = function () end end
			self.modules[i].Init()
		end
	end
	
	self.isReady = true
end

function EventHorizon:ApplyConfig()
	past = self.config.past or -3	-- We really don't want config.past to be positive.
	future = self.config.future or 9
	barheight = self.config.height or 18
	barwidth = self.config.width or 150
	barspacing = self.config.spacing or 0
	scale = 1/(future-past)
	bartexture = self.config.bartexture or 'Interface\\Addons\\EventHorizon\\Smooth'
	barbgcolor = self.config.barbgcolor or {1,1,1,0.1}
	texturedbars = self.config.texturedbars
	local texturealpha = self.config.texturealphamultiplier or 1
	classburn = self.config.classburn or 0.7
	classalpha = self.config.classalpha or 0.3
	castLine = self.config.castLine and ((type(self.config.castLine) == 'number' and self.config.castLine) or self.config.castLine == true and 0) or nil
	
	local classcolors = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
	self.classcolor = Clone(classcolors[select(2,UnitClass('player'))])

	for colorid,color in pairs(self.colors) do
		if color[1] == true then
			if color[2] then
				self.colors[colorid] = {self.classcolor.r * color[2], self.classcolor.g * color[2], self.classcolor.b * color[2], color[3] or classalpha}		-- For really bad reasons, this took a very long time to get right...
			else
				self.colors[colorid] = {self.classcolor.r, self.classcolor.g, self.classcolor.b, classalpha}
			end
		end
	end
	
	if texturedbars then
		for colorid,color in pairs(self.colors) do
			if color[4] and not(exemptColors[colorid]) then
				color[4] = texturealpha*color[4]
			end
		end
	end

	local layouts = self.layouts
	layouts.frameline = {
		top = 0,
		bottom = 1,
	}
	local default = layouts.default
	for typeid,layout in pairs(layouts) do
		if typeid~='default' then
			for k,v in pairs(default) do
				if layout[k]==nil then
					layout[k] = v
				end
			end
		end
		layout.texcoords = {0, 1, layout.top, layout.bottom}
	end
end

function EventHorizon:UpdateConfig()
	if not(self.isReady) then return end
	self:ApplyConfig()

	mainframe:SetScale(self.config.scale or 1)
	local effectiveScale = mainframe:GetEffectiveScale()
	if effectiveScale then
		onepixelwide = 1/effectiveScale
	end
	
	self:SetupStyleFrame()		-- Spawn backdrop frame.
	
	local nowleft = -past/(future-past)*barwidth-0.5 + self.config.height
	nowI:SetFrameLevel(20)
	nowIndicator:SetPoint('BOTTOM',mainframe,'BOTTOM')
	nowIndicator:SetPoint('TOPLEFT',mainframe,'TOPLEFT', nowleft, 0)
	nowIndicator:SetTexture(unpack(self.colors.nowLine))

	local anchor = self.config.anchor or {'TOPRIGHT', 'EventHorizonHandle', 'BOTTOMRIGHT'}
	if anchor[2]=='EventHorizonHandle' then
		-- Create the handle to reposition the frame.
		handle = handle or CreateFrame('Frame', 'EventHorizonHandle', mainframe)
		handle:SetFrameStrata('HIGH')
		handle:SetWidth(10)
		handle:SetHeight(5)
		handle:EnableMouse(true)
		handle:SetClampedToScreen(1)
		handle:RegisterForDrag('LeftButton')
		handle:SetScript('OnDragStart', function(handle, button) handle:StartMoving() end)
		handle:SetScript('OnDragStop', function(handle) 
			handle:StopMovingOrSizing()
			local a,b,c,d,e = handle:GetPoint(1)
			if type(b)=='frame' then
				b=b:GetName()
			end
			EventHorizonDB.point = {a,b,c,d,e}
		end)
		handle:SetMovable(true)

		mainframe:SetPoint(unpack(anchor))
		handle:SetPoint(unpack(EventHorizonDB.point))

		handle.tex = handle:CreateTexture(nil, 'BORDER')
		handle.tex:SetAllPoints()
		handle:SetScript('OnEnter',function(frame) frame.tex:SetTexture(1,1,1,1) end)
		handle:SetScript('OnLeave',function(frame) frame.tex:SetTexture(1,1,1,0.1) end)
		handle.tex:SetTexture(1,1,1,0.1)
	end

	gcdSpellName = self.config.gcdSpellID and (GetSpellInfo(self.config.gcdSpellID))
	if gcdSpellName and self.config.gcdStyle then
		-- Create the GCD indicator, register cooldown event.
		gcdIndicator = mainframe:CreateTexture('EventHorizonGCDIndicator', 'BORDER')
		local nowleft = -past/(future-past)*barwidth-0.5 + barheight
		gcdIndicator:SetPoint('BOTTOM',mainframe,'BOTTOM')
		gcdIndicator:SetPoint('TOP',mainframe,'TOP')
		gcdIndicator:Hide()

		if self.config.gcdStyle == 'line' then
			gcdIndicator:SetWidth(onepixelwide)
		else
			gcdIndicator:SetPoint('LEFT',mainframe,'LEFT', nowleft, 0)
		end

		local gcdColor = self.colors.gcdColor or {.5,.5,.5,.3}
		gcdIndicator:SetTexture(unpack(gcdColor))
	end
	
	mainframe:SetPoint(unpack(anchor))
	self:SetFrameDimensions()
end

local glyphCheck = function ()
	if EventHorizon.isActive == true then
		EventHorizon:CheckTalents()
	end	
end

function EventHorizon:SetupStyleFrame()
	local c = self.config.backdrop
	if c then
		if not(self.styleframe) then self.styleframe = CreateFrame('Frame',nil,mainframe) end
	else
		if self.styleframe then self.styleframe:Hide() end
		return
	end
	
	local styleframe = self.styleframe
	local stylebg = self.config.bg or 'Interface\\ChatFrame\\ChatFrameBackground'
	local styleborder = self.config.border or 'Interface\\Tooltips\\UI-Tooltip-Border'
	local stylebgcolor = self.colors.bgcolor or {0,0,0,0.6}
	local stylebordercolor = self.colors.bordercolor or {1,1,1,1}
	local styleinset = self.config.inset or {top = 2, bottom = 2, left = 2, right = 2}
	local stylepadding = self.config.padding or 3
	local styleedge = self.config.edgesize or 8

	styleframe:SetFrameStrata('BACKGROUND')
	styleframe:SetPoint('TOPRIGHT', mainframe, 'TOPRIGHT', stylepadding, stylepadding)
	styleframe:SetPoint('BOTTOMLEFT', mainframe, 'BOTTOMLEFT', -stylepadding, -stylepadding)
	styleframe:SetBackdrop({
		bgFile = stylebg,
		edgeFile = styleborder, tileSize = 0, edgeSize = styleedge,
		insets = styleinset,
	})
	styleframe:SetBackdropColor(unpack(stylebgcolor))
	styleframe:SetBackdropBorderColor(unpack(stylebordercolor))
end

function EventHorizon:RegisterModule(module,namespace)
	if not(module and namespace) then
		print("Module registration failed. Usage: EventHorizon:RegisterModule(module,namespace)")
	end
	local module = string.lower(module)
	self.modules[module] = namespace
end


frame:SetScript('OnEvent', EventHandler)
frame:RegisterEvent('PLAYER_LOGIN')

frame.PLAYER_ALIVE = function (self)
	self:SetScript('OnUpdate', UpdateMouseover)
	frame2:SetScript('OnEvent', EventHandler)
	for k,v in pairs(reloadEvents) do
		frame2:RegisterEvent(k)
		frame2[k] = glyphCheck
	end
	EventHorizon:Initialize()
	self:UnregisterEvent('PLAYER_ALIVE')
end
	
frame.PLAYER_LOGIN = function (self)
	local talents = GetTalentInfo(1,1)
	if talents then
		self:UnregisterEvent('PLAYER_LOGIN')
		self:SetScript('OnUpdate', UpdateMouseover)
		frame2:SetScript('OnEvent', EventHandler)
		for k,v in pairs(reloadEvents) do
			frame2:RegisterEvent(k)
			frame2[k] = glyphCheck
		end
		EventHorizon:Initialize()
	else
		self:UnregisterEvent('PLAYER_LOGIN')
		self:RegisterEvent('PLAYER_ALIVE')
	end
end

mainframe.CLEU_OtherInterestingSpell = mainframe_CLEU_OtherInterestingSpell
mainframe.PLAYER_TALENT_UPDATE = mainframe_PLAYER_TALENT_UPDATE
mainframe.UPDATE_SHAPESHIFT_FORM = mainframe_UPDATE_SHAPESHIFT_FORM
mainframe.SPELL_UPDATE_COOLDOWN = mainframe_SPELL_UPDATE_COOLDOWN
mainframe.COMBAT_LOG_EVENT_UNFILTERED = mainframe_COMBAT_LOG_EVENT_UNFILTERED
mainframe.UPDATE_SHAPESHIFT_FORMS = mainframe_UPDATE_SHAPESHIFT_FORM

SpellFrame.NotInteresting = SpellFrame_NotInteresting
SpellFrame.AddSegment = SpellFrame_AddSegment
SpellFrame.AddIndicator = SpellFrame_AddIndicator
SpellFrame.Remove = SpellFrame_Remove
SpellFrame.RemoveTicksAfter = SpellFrame_RemoveTicksAfter
SpellFrame.OnUpdate = SpellFrame_OnUpdate
SpellFrame.UpdateDoT = SpellFrame_UpdateDoT
SpellFrame.Activate = SpellFrame_Activate
SpellFrame.Deactivate = SpellFrame_Deactivate

SpellFrame.UNIT_AURA = SpellFrame_UNIT_AURA
SpellFrame.UNIT_AURA_refreshable = SpellFrame_UNIT_AURA_refreshable
SpellFrame.COMBAT_LOG_EVENT_UNFILTERED = SpellFrame_COMBAT_LOG_EVENT_UNFILTERED
SpellFrame.UNIT_SPELLCAST_SENT = SpellFrame_UNIT_SPELLCAST_SENT
SpellFrame.UNIT_SPELLCAST_CHANNEL_START = SpellFrame_UNIT_SPELLCAST_CHANNEL_START
SpellFrame.UNIT_SPELLCAST_CHANNEL_UPDATE = SpellFrame_UNIT_SPELLCAST_CHANNEL_UPDATE
SpellFrame.UNIT_SPELLCAST_CHANNEL_STOP = SpellFrame_UNIT_SPELLCAST_CHANNEL_STOP
SpellFrame.UNIT_SPELLCAST_START = SpellFrame_UNIT_SPELLCAST_START
SpellFrame.UNIT_SPELLCAST_STOP = SpellFrame_UNIT_SPELLCAST_STOP
SpellFrame.UNIT_SPELLCAST_DELAYED = SpellFrame_UNIT_SPELLCAST_DELAYED
SpellFrame_UNIT_SPELLCAST_SUCCEEDED = SpellFrame_UNIT_SPELLCAST_SUCCEEDED
SpellFrame.PLAYER_TARGET_CHANGED = SpellFrame_PLAYER_TARGET_CHANGED
SpellFrame.PLAYER_TARGET_CHANGED_refreshable = SpellFrame_PLAYER_TARGET_CHANGED_refreshable
SpellFrame.PLAYER_REGEN_ENABLED = SpellFrame_PLAYER_REGEN_ENABLED
SpellFrame.SPELL_UPDATE_COOLDOWN = SpellFrame_SPELL_UPDATE_COOLDOWN
SpellFrame.BAG_UPDATE_COOLDOWN = SpellFrame_SPELL_UPDATE_COOLDOWN
SpellFrame.PLAYER_EQUIPMENT_CHANGED = SpellFrame_PLAYER_EQUIPMENT_CHANGED
SpellFrame.UPDATE_MOUSEOVER_UNIT = SpellFrame_UPDATE_MOUSEOVER_UNIT

local Redshift = {}
Redshift.Check = function (self)
	if not(EventHorizon.isActive == true) then return end
	
	if not(Redshift.frame) then
		Redshift.frame = CreateFrame("FRAME",nil,UIParent)
		Redshift.frame:SetScript("OnEvent",EventHandler)
		for k,v in pairs(Redshift.Events) do
			if v then
				Redshift.frame:RegisterEvent(k)
				Redshift.frame[k] = Redshift.Check
			end
		end
	end
	
	local s = Redshift.states
	
	showState = nil
	
	local attackable = UnitCanAttack("player","target")
	local targeting = UnitExists("target")
	local focusing = UnitExists("focus")
	local classify = UnitClassification("target")
	local dead = UnitIsDeadOrGhost("target")
	local vehicle = UnitHasVehicleUI("player")
	
	if(s.showCombat and UnitAffectingCombat("player")) then 
		showState = true
	end
	
	if (s.showFocus and UnitExists("focus")) then
		showState = true
	end
	
	if targeting then
		if(s.showHelp and not attackable) and not dead then
			showState = true
		end
		if(s.showHarm and attackable) and not dead then
			showState = true
		end
		if(s.showBoss and classify == "worldboss") and not dead then
			showState = true
		end
	end
	
	if (s.hideVehicle and UnitHasVehicleUI("player")) then
		showState = nil
	end
	
	if showState then
		visibleFrame = true
		mainframe:Show()
		if EventHorizon_VitalsFrame and s.hideVitals then
			EventHorizon_VitalsFrame:Show()
		end
	else
		visibleFrame = false
		mainframe:Hide()
		if EventHorizon_VitalsFrame and s.hideVitals then
			EventHorizon_VitalsFrame:Hide()
		end
	end
end

Redshift.Init = function ()
	local c = EventHorizon.config.enableRedshift
	local db = EventHorizonDB.redshift.isActive == true
	if not (c and db) then return end
	
	Redshift.states = {}
	Redshift.Events = {
		["PLAYER_REGEN_DISABLED"] = true,
		["PLAYER_REGEN_ENABLED"] = true,
		["PLAYER_TARGET_CHANGED"] = true,
		["PLAYER_GAINS_VEHICLE_DATA"] = true,
		["PLAYER_LOSES_VEHICLE_DATA"] = true,
		["UNIT_ENTERED_VEHICLE"] = true,
		["UNIT_EXITED_VEHICLE"] = true,
		["UNIT_ENTERING_VEHICLE"] = true,
		["UNIT_EXITING_VEHICLE"] = true,
		["VEHICLE_PASSENGERS_CHANGED"] = true,
	}
	
	for k,v in pairs(EventHorizon.config.Redshift) do
		if v then
			Redshift.states[k] = true
		end
	end
	
	Redshift.Enable = function ()
		Redshift:Check()
		Redshift.frame:SetScript('OnEvent',EventHandler)
	end

	Redshift.Disable = function ()
		visibleFrame = true
		if Redshift.frame then Redshift.frame:SetScript('OnEvent',nil) end
		if EventHorizon.isActive == true then mainframe:Show() end
	end
	
	if (EventHorizonDB.redshift.isActive == true) then Redshift:Check() end
	Redshift.isReady = true
end

local Lines = {}
Lines.CreateLines = function ()
	if Lines.frame then return end
	local c = EventHorizon.config.Lines
	local db = EventHorizonDB.lines.isActive == true
	if not(c and db) then return
	elseif type(c) == 'number' then c = {c}	-- Turn numbers into delicious tables.
	elseif type(c) ~= 'table' then return	-- Turn away everything else.
	end
	
	Lines.frame = CreateFrame('Frame',nil,UIParent)
	Lines.line = {}
	
	local scale = 1/(future-past)
	local effectiveScale = mainframe:GetEffectiveScale()
	if effectiveScale then
		onepixelwide = 1/effectiveScale
	end
	
	local multicolor
	local color = EventHorizon.config.LinesColor
	if color and type(color) == 'table' then
		if type(color[1]) == 'table' then
			multicolor = true	-- trying not to further complicate things
			for i,v in ipairs(c) do
				if not(color[i]) then
					color[i] = color[i-1] -- if we have more lines than colors, we need moar colors
				end
			end
		end
	else
		color = {1,1,1,0.5}
	end
	
	local now = -past/(future-past)*barwidth-0.5 + barheight
	local pps = (barwidth+barheight-now)/future
	
	for i = 1, #c do
		local seconds = c[i]
		local position = now+(pps*seconds)
		Lines.line[i] = mainframe:CreateTexture(nil,"OVERLAY")
		Lines.line[i]:SetPoint('TOPLEFT', mainframe, 'TOPLEFT', position, 0)
		if multicolor then
			Lines.line[i]:SetTexture(unpack(color[i]))
		else
			Lines.line[i]:SetTexture(unpack(color))
		end
		Lines.line[i]:SetWidth(onepixelwide)
		Lines.line[i]:SetPoint('BOTTOM', mainframe, 'BOTTOM')
	end
	
	Lines.Enable = function ()
		for i = 1,#Lines.line do
			Lines.line[i]:Show()
		end
	end
	
	Lines.Disable = function ()
		for i = 1,#Lines.line do
			Lines.line[i]:Hide()
		end
	end
end

Lines.Init = function ()
	Lines.CreateLines()
	Lines.isReady = true
end

EventHorizon:RegisterModule('lines',Lines)
EventHorizon:RegisterModule('redshift',Redshift)
