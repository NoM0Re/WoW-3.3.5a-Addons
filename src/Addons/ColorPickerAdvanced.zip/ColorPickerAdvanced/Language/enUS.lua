--[[ ==========================================================================
	© Feyawen Ariana 2011-2015
		If you use my code, please give me credit.
========================================================================== ]]--
local myName, me = ...
local L = me.L


L[myName] = "|cff0088ffColorPickerAdvanced|cff808080: |r"	-- Provide a "friendly name" of our AddOn to prefix any output messages.


--[[

]]--
