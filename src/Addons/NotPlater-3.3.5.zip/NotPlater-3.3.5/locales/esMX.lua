if GetLocale() ~= "esMX" then
	return
end

NotPlaterLocals = setmetatable({
}, {__index = NotPlaterLocals})