# Redeemer 3.3.5a
 This AddOn makes you say humorous messages whenever you cast a resurrection spell and serves purely to entertain you and annoy others.

Redeemer
by Ryplinn-Kargath(US)
Updated by Lightball-Icecrown (Warmane)

Welcome to Redeemer! This AddOn makes you say humorous messages whenever you cast a resurrection spell and serves purely to entertain you and annoy others.

Enjoy!

To select which channels to send Redeemer quotes to, use the /redeemer command.

If you'd like to add in your own messages, feel free to edit the RedeemerQuotes.lua file. Make sure to strictly follow the guidelines at the beginning of the RedeemerQuotes.lua file.

Quotes? Questions? Bug reports? Submit them to https://github.com/Dequint6/Redeemer-3.3.5a . Be sure to include the word "Redeemer" in your subject line.

Changelog

v1.0 23/08/2019
-Added quotes
-Updated .toc for version 3.3.5a