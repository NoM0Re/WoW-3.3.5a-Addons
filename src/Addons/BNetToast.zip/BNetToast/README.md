# BNetToast
3.3.5a port of Bonho's FriendsFrame addon from Valkery-WoW 1.12.1, thanks to [Bunny67](https://github.com/Bunny67)  (mastermind of the [ElvUI](https://github.com/ElvUI) backport for 3.3.5a).

**I _DO NOT_ take any credit for this addon. All credit goes to [Bonho](https://valkyrie-wow.org/boards/index.php?showtopic=791), the original author, and [Bunny67](https://github.com/Bunny67) for making this happen!**

ElvUI skin availabale as well. Download latest ElvUI: https://github.com/ElvUI/ElvUI

![world of warcraft 5_10_2016 12_02_33 pm](https://cloud.githubusercontent.com/assets/7307335/15155327/9bf7ddac-16a7-11e6-9893-cb5c306dc1ec.png)
![wowscrnshot_051016_075537](https://cloud.githubusercontent.com/assets/7307335/15147283/7ba1cfda-1685-11e6-81b5-97d64413cfb5.jpg)
![wowscrnshot_051016_075525](https://cloud.githubusercontent.com/assets/7307335/15147284/7e91397e-1685-11e6-823b-a8c4f444ac1c.jpg)
