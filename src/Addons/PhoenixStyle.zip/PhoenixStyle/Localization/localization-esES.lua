﻿if GetLocale() == "esES" then

function pslocalezone()
pszonecoliseum				= "Prueba del Cruzado"
pszoneulduar				= "Ulduar"
pszoneicecrowncit			= "Ciudadela de la Corona de Hielo"

end

function pslocale()

end

function pslocaleui()

end

function pslocaletimers()

end

end