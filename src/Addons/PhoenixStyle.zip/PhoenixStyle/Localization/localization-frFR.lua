﻿if GetLocale() == "frFR" then

function pslocalezone()
pszonecoliseum				= "L'épreuve du croisé"
pszoneulduar				= "Ulduar"
pszoneicecrowncit			= "Citadelle de la Couronne de glace"

end

function pslocale()

end

function pslocaleui()

end

function pslocaletimers()

end

end