﻿if GetLocale() == "koKR" then

function pslocalezone()
pszonecoliseum				= "십자군의 시험장"
pszoneulduar				= "울두아르"
pszoneicecrowncit			= "얼음왕관 성채"

end

function pslocale()

end

function pslocaleui()

end

function pslocaletimers()

end

end