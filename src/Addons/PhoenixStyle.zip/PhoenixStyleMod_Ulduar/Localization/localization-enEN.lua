﻿

function pslocaleuldaboss()


psulgeneralvezax			= "General Vezax"
psulsaronite				= "Saronite Animus"
psulleviafanchik			= "Flame Leviathan"
psulalgalon				= "Algalon the Observer"
psyoggfail1				= "Brain of Yogg-Saron"
psyoggfail2				= "Yogg-Saron"
psyoggfail3				= "Sara"
psyoggfail4				= "Guardian of Yogg-Saron"
psultorim				= "Thorim"


end



function pslocaleulduar()

psulalgalon1				= "has entered portal not in time."
psulxttext1				= "Failed with Death Ray: "
psulxttext2				= "Failed with laughing skulls: "
psulxttext3				= "Failed with Lunatic Gaze of Yogg-Saron (sec.): "
psultorimtext1				= "failed with Lightning Charge!"
psultorimtext2				= "Got Lightning Charge: "
psulalgalon3				= "Failed at portals: "
psulsovetbuff				= "Fusion Punch"
psulsovetfrom				= "from"
psulsovetnotd				= "WAS NOT DISPELLED and lasted for"
psulsovetsnyal				= "dispelled debuff"
psulsovetin				= "in"
psulhodir1				= "got Flash Freeze!"
psulnapalmgot				= "Napalm got"
psulvezax1				= "there was no healing reduction debuff!"
psulvezax2				= "healed boss for"
psulvezax3				= "(no -50% heal debuff)"
psulvezax4				= "fail from"
psulvezax5				= "3 worst Mark of the Faceless runs:"
psulvezax6				= "Got Shadowcrashed: "
psulyoggguard1				= "Needed to kill Guardians:"
psulyoggguard2				= "PHASE #2"
psulyoggguard3				= "Guardian was killed not near Sara!"


end



function pslocaleulduarui()

psululda				= "    Ulduar"
psulmimiron				= "Mimiron"
psulsovet				= "Assembly of Iron"
psulhodir				= "Hodir"
psulalgalon2				= "Algalon"
psulxt02				= "Yogg-Saron"
psulthorim2				= "Thorim"
psulbossinfo1				= "- show who gets Shadowcrashed and amount of boss healing from Mark of the Faceless."
psulbossinfo2				= "- show who get 2 or more napalms simultaneously."
psulbossinfo3				= "- MT's debuff dispell time."
psulbossinfo4				= "- show who gets Flash Freezed + mark them."
psulbossinfo5				= "- show who enters portals without Big Bang being cast."
psulbossinfo6				= "- show some fails at the end of the fight + count Guadians needed to kill."
psulbossinfo7				= "- show get damage from Lightning Charge."
psulleviafan				= "Leviathan"
psulyoggsaron				= "Yogg-Saron"
psulonlyattheendyogg1			= "- don't count Guardians needed to phase change"


--леви
psullevi1				= "    Ulduar - Flame Leviathan - 25"
psulleviinfo1				= "group 1: siege engine drivers."
psulleviinfo2				= "group 2: demolisher drivers."
psulleviinfo3				= "- throw people"
psulleviinfo4				= "group 3: choppers."
psulleviinfo5				= "- demolisher passengers (don't throw)"
psulleviinfo6				= "group 4: defense Turrets team."
psulleviinfo7				= "group 5: siege engine passengers."
psulleviinfo8				= "- member of defense Turrets team"
psulleviinfo9				= "Landing #1:"
psulleviinfo10				= "Landing #2:"
psulleviinfo11				= "Choppers:"
psullevito				= "to"
psullevibut1				= "Load raid changes"
psullevibut2				= "Send raiders role by /w to all"
psullevibut3				= "Enable Levi-bot"
psullevibut4				= "DISABLE Levi-bot"
pslevibot1				= "Levi-bot"
pslevibotoff				= "disabled!"
psleviboton				= "enabled!"
psleviboton2				= "Warnings of landing and automarking is enebled."
psleviboterr1				= "Your raid is very low for this module!"
psleviboterr2				= "This module can be turned ON only |cffff0000not in combat|r."
psleviboterr3				= "You have no rights to use this module, ask Raid Leader to promote you."
pslevibotwin				= "Leviathan |cff00ff00defeated!|r Levi-bot is now disabled!"
pslevibotwipe				= "|cffff0000Wipe on Leviathan|r. Levi-bot is ready for next try. Good luck!"
psullevibesure				= "Be sure that module is good for your tactic! We use 2 landings, 3+3 flying people from 3 catapults with marks."


--йогг
psulyogg				= "    Ulduar - Yogg-Saron - 25"
psulgrport				= "choose groups into portals:"
psulyoggboss				= "BOSS"
psulyoggprim				= "Note:"
psulyoggprim2				= "Note:"
psulyogginfo1				= "Send all messages to channel:"
psulyogginfo2				= "Send to chat pictures:"
psulyogginfo3				= "/w pictures to:"
psulyoggload				= "Load raid"
psulyoggresetall			= "Reset all"
psulyoggsendnick			= "Send nick list"
psulyoggimg1				= "Boss and portals"
psulyoggimg2				= "Stormwind"
psulyoggimg3				= "Icecrown"
psulyoggimg4				= "Dragonblight"
psulyoggparty1				= "group 1"
psulyoggparty2				= "group 2"
psulyoggparty3				= "group 3"
psulyoggparty4				= "group 4"
psulyoggparty5				= "group 5"
psulyoggempty				= "empty"



end

function pslocaleuldalevi()
psullevitxt1				= "group 1 - siege engine drivers"
psullevitxt2				= "group 2 - demolisher drivers"
psullevitxt3				= "group 3 - choppers"
psullevitxt4				= "group 4 - defense Turrets team"
psullevitxt5				= "group 5 - siege engine passengers."
psullevitxt6				= "Landing #1"
psullevitxt7				= "Landing #2"
psullevitxt8				= "into catapult now"
pslevirol1				= "you are siege engine driver, you ram lashers, interrupt boss cast (if RL doesn't give other priority)"
pslevirol2				= "you are demolisher driver (without mark), you will have 1 passenger (do not throw him)."
pslevirol3				= "you are siege engine passenger, kill lashers, force down pyrite."
pslevirol4				= "you are demolisher driver with mark"
pslevirol5				= "throw people from catapult, hold stack of pyrite on boss."
pslevirol6				= "you are passenger of demolisher without mark, force down pyrite and reload it with it, help killing lashers."
pslevirol7				= "you are bike driver, deliver raid member with mark"
pslevirol8				= "on demolisher"
pslevirol9				= "you will be thrown on 1 landing, take demolisher with mark"
pslevirol10				= "you will be thrown on 2 landing, take demolisher with mark"
pslevirol11				= "(in catapult now), you will be delivered back by"
pslevirol12				= "(NOT IN catapult), you will be delivered back by"
pslevirol13				= "on bike."
pslevidesgogo				= "GOGOGO!"
pslevitimetodie				= "Time for your landing! load yourself into catapult!"
end