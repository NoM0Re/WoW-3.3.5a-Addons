﻿if GetLocale() == "esMX" then

function pslocaleuldaboss()


psulgeneralvezax			= "General Vezax"
psulsaronite				= "Animus de saronita"
psulleviafanchik			= "Leviatán de llamas"
psulalgalon				= "Algalon the Observer"
psyoggfail1				= "Cerebro de Yogg-Saron"
psyoggfail2				= "Yogg-Saron"
psyoggfail3				= "Sara"
psyoggfail4				= "Guardián de Yogg-Saron"
psultorim				= "Thorim"

end



end