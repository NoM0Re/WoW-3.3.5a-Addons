﻿if GetLocale() == "frFR" then

function pslocaleuldaboss()


psulgeneralvezax			= "Général Vezax"
psulsaronite				= "Animus de saronite"
psulleviafanchik			= "Léviathan des flammes"
psulalgalon				= "Algalon l'Observateur"
psyoggfail1				= "Cerveau de Yogg-Saron"
psyoggfail2				= "Yogg-Saron"
psyoggfail3				= "Sara"
psyoggfail4				= "Gardien de Yogg-Saron"
psultorim				= "Thorim"

end



end