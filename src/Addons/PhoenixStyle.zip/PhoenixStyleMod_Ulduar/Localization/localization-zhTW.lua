﻿if GetLocale() == "zhTW"then

function pslocaleuldaboss()


psulgeneralvezax			= "威札斯將軍"
psulsaronite				= "薩倫聚惡體"
psulleviafanchik			= "烈焰戰輪"
psulalgalon				= "『觀察者』艾爾加隆"
psyoggfail1				= "尤格薩倫的腦部"
psyoggfail2				= "尤格薩倫"
psyoggfail3				= "薩拉"
psyoggfail4				= "尤格薩倫守護者"
psultorim				= "索林姆"

end


function pslocaleulduar()

psulalgalon1 = "在不正確的時機進入黑洞。"
psulxttext1 = "失誤於死亡射線: "
psulxttext2 = "失誤於獰笑骷髏: "
psulxttext3 = "失誤於尤格薩倫的癡狂凝視(秒): "
psultorimtext1 = "失誤於閃電充能!"
psultorimtext2 = "被閃電充能擊中: "
psulalgalon3 = "誤入黑洞: "
psulsovetbuff = "熔能拳擊"
psulsovetfrom = "在"
psulsovetnotd = "身上沒被驅散而持續了"
psulsovetsnyal = "驅散了"
psulsovetin = "在"
psulhodir1 = "中了閃霜!"
psulnapalmgot = "凝汽彈擊中"
psulvezax1 = "沒有致死效果!"
psulvezax2 = "治療守領"
psulvezax3 = "(沒有致死50%狀態)"
psulvezax4 = "失誤於"
psulvezax5 = "無面者印記跑最糟的3個:"
psulvezax6 = "被暗影暴擊打中:"
psulyoggguard1 = "需要擊殺的守護者:"
psulyoggguard2 = "第二階段"
psulyoggguard3 = "守護者沒有在薩拉附近被擊殺!"


end


function pslocaleulduarui()

psululda = "    奧杜亞"
psulmimiron = "彌米倫"
psulsovet = "鐵之集會"
psulhodir = "霍迪爾"
psulalgalon2 = "艾爾加隆"
psulxt02 = "尤格薩倫"
psulthorim2 = "索林姆"
psulbossinfo1 = "- 通告誰被暗影暴擊炸到以及守領從無面者印記獲得的治療量。"
psulbossinfo2 = "- 通告哪些人同時被凝汽彈擊中。"
psulbossinfo3 = "- 主坦熔能拳擊驅散時間。"
psulbossinfo4 = "- 通告誰中了閃霜並標記他們。"
psulbossinfo5 = "- 通告誰不是在大霹靂施放時進入黑洞。"
psulbossinfo6 = "- 戰鬥結束時通告某些失誤並計數還要擊殺的尤格薩倫守護者數量。"
psulbossinfo7 = "- 通告誰中了閃電充能。"
psulleviafan = "烈焰戰輪"
psulyoggsaron = "尤格薩倫"
psulonlyattheendyogg1 = "- 不要計數進入第二階段前需要擊殺的守護者數量"



--леви
psullevi1				= "    Ulduar - Flame Leviathan - 25"
psulleviinfo1				= "group 1: siege engine drivers."
psulleviinfo2				= "group 2: demolisher drivers."
psulleviinfo3				= "- throw people"
psulleviinfo4				= "group 3: choppers."
psulleviinfo5				= "- demolisher passengers (don't throw)"
psulleviinfo6				= "group 4: defense Turrets team."
psulleviinfo7				= "group 5: siege engine passengers."
psulleviinfo8				= "- member of defense Turrets team"
psulleviinfo9				= "Landing #1:"
psulleviinfo10				= "Landing #2:"
psulleviinfo11				= "Choppers:"
psullevito				= "to"
psullevibut1				= "Load raid changes"
psullevibut2				= "Send raiders role by /w to all"
psullevibut3				= "Enable Levi-bot"
psullevibut4				= "DISABLE Levi-bot"
pslevibot1				= "Levi-bot"
pslevibotoff				= "disabled!"
psleviboton				= "enabled!"
psleviboton2				= "Warnings of landing and automarking is enebled."
psleviboterr1				= "Your raid is very low for this module!"
psleviboterr2				= "This module can be turned ON only |cffff0000not in combat|r."
psleviboterr3				= "You have no rights to use this module, ask Raid Leader to promote you."
pslevibotwin				= "Leviathan |cff00ff00defeated!|r Levi-bot is now disabled!"
pslevibotwipe				= "|cffff0000Wipe on Leviathan|r. Levi-bot is ready for next try. Good luck!"
psullevibesure				= "Be sure that module is good for your tactic! We use 2 landings, 3+3 flying people from 3 catapults with marks."


--йогг
psulyogg				= "    Ulduar - Yogg-Saron - 25"
psulgrport				= "choose groups into portals:"
psulyoggboss				= "BOSS"
psulyoggprim				= "Note:"
psulyoggprim2				= "Note:"
psulyogginfo1				= "Send all messages to channel:"
psulyogginfo2				= "Send to chat pictures:"
psulyogginfo3				= "/w pictures to:"
psulyoggload				= "Load raid"
psulyoggresetall			= "Reset all"
psulyoggsendnick			= "Send nick list"
psulyoggimg1				= "Boss and portals"
psulyoggimg2				= "Stormwind"
psulyoggimg3				= "Icecrown"
psulyoggimg4				= "Dragonblight"
psulyoggparty1				= "group 1"
psulyoggparty2				= "group 2"
psulyoggparty3				= "group 3"
psulyoggparty4				= "group 4"
psulyoggparty5				= "group 5"
psulyoggempty				= "empty"



end


end