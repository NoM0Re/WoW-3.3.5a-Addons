﻿if GetLocale() == "ruRU" then 

function pslocaleuldaboss()


psulgeneralvezax			= "Генерал Везакс"
psulsaronite				= "Саронитовый враг"
psulleviafanchik			= "Огненный Левиафан"
psulalgalon				= "Алгалон Наблюдатель"
psyoggfail1				= "Мозг Йогг-Сарона"
psyoggfail2				= "Йогг-Сарон"
psyoggfail3				= "Сара"
psyoggfail4				= "Страж Йогг-Сарона"
psultorim				= "Торим"


end



function pslocaleulduar()

psulalgalon1				= "попал(а) в портал не вовремя."
psulxttext1				= "Попали в лучи смерти: "
psulxttext2				= "Попали под взгляд смеющегося черепа (раз): "
psulxttext3				= "Не отвернулись от Взгляда безумца (сек.): "
psultorimtext1				= "не отбежал от Разряда Молний!"
psultorimtext2				= "Получили урон от Разряда Молний: "
psulalgalon3				= "Заход в портал не вовремя: "
psulsovetbuff				= "Энергетический удар"
psulsovetfrom				= "с"
psulsovetnotd				= "НЕ БЫЛ СНЯТ, дебаф провисел:"
psulsovetsnyal				= "снял дебаф"
psulsovetin				= "за"
psulhodir1				= "попал в ледяную заморозку!"
psulnapalmgot				= "Напалм словили"
psulvezax1				= "на боссе не было -50% дебафа к хилу!"
psulvezax2				= "восстановил(а) боссу"
psulvezax3				= "(без -50% дебафа к хилу)"
psulvezax4				= "фейл от"
psulvezax5				= "Тройка самых худших выбеганий за бой (по отхилу босса, за 1 марку):"
psulvezax6				= "Под сокрушение попали: "
psulyoggguard1				= "До второй фазы осталось стражей:"
psulyoggguard2				= "ФАЗА 2"
psulyoggguard3				= "Страж убит далеко от Сары!"

end



function pslocaleulduarui()

psululda				= "    Ульдуар"
psulmimiron				= "Мимирон"
psulsovet				= "Железный совет"
psulhodir				= "Ходир"
psulalgalon2				= "Алгалон"
psulxt02				= "Йогг-Сарон"
psulthorim2				= "Торим"
psulbossinfo1				= "- получение урона от Темного сокрушения и количество отхила босса от Метки безликого."
psulbossinfo2				= "- получение более 1 дебафа Напалма одновременно."
psulbossinfo3				= "- время диспела дебафа с МТ."
psulbossinfo4				= "- попадание в мгновенную заморозку + марка."
psulbossinfo5				= "- заход в портал не во время каста Сурового удара."
psulbossinfo6				= "- некоторые ошибки по окончанию боя + счет Стражей для смены фазы."
psulbossinfo7				= "- получение урона от Разряда молний."
psulleviafan				= "Левиафан"
psulyoggsaron				= "Йогг-Сарон"
psulonlyattheendyogg1			= "- не считать Стражей до смены фазы"


--леви
psullevi1				= "    Ульдуар - Огненный Левиафан - 25"
psulleviinfo1				= "1 гр.: водят осадные машины."
psulleviinfo2				= "2 гр.: водят разрушители."
psulleviinfo3				= "- бросают десант"
psulleviinfo4				= "3 гр.: водят мотоциклы."
psulleviinfo5				= "- пассажиры разрушителей без марок (не десант)"
psulleviinfo6				= "4 гр.: десант."
psulleviinfo7				= "5 гр.: пассажиры осадных машин."
psulleviinfo8				= "- десантник"
psulleviinfo9				= "Десант #1:"
psulleviinfo10				= "Десант #2:"
psulleviinfo11				= "Мотоциклы:"
psullevito				= "на"
psullevibut1				= "Загрузить изменения рейда"
psullevibut2				= "Сообщ. всем в приват их роль"
psullevibut3				= "Включить Леви-бот"
psullevibut4				= "ОТКЛЮЧИТЬ Леви-бот"
pslevibot1				= "Леви-бот"
pslevibotoff				= "отключен!"
psleviboton				= "запущен!"
psleviboton2				= "Включено объявление высадок десанта и автомаркование."
psleviboterr1				= "Ваш рейд слишком мал, для запуска этого модуля!"
psleviboterr2				= "Данный модуль может быть запущен только |cffff0000НЕ в бою|r."
psleviboterr3				= "У вас нет прав для запуска этого модуля, обратитесь к Рейд Лидеру за промоутом."
pslevibotwin				= "Левиафан |cff00ff00побежден!|r Отключаю Леви-бот и модуль босса!"
pslevibotwipe				= "|cffff0000Вайп на левиафане|r. Леви-бот готов к следующему траю! Удачи!"
psullevibesure				= "Проверьте, подходит ли этот модуль под Вашу тактику! (2 высадки по 3 человека с 3 маркованых катапульт)"

--йогг
psulyogg				= "    Ульдуар - Йогг-Сарон - 25"
psulgrport				= "выбор групп в порталы:"
psulyoggboss				= "БОСС"
psulyoggprim				= "Прим.:"
psulyoggprim2				= "Примечание:"
psulyogginfo1				= "Все сообщения идут в канал:"
psulyogginfo2				= "Отправить в чат картинки:"
psulyogginfo3				= "отправлять картинки в приват:"
psulyoggload				= "загрузить рейд"
psulyoggresetall			= "обнулить все"
psulyoggsendnick			= "Отправить список ников"
psulyoggimg1				= "Босс с порталами"
psulyoggimg2				= "Штормград"
psulyoggimg3				= "Ледяная корона"
psulyoggimg4				= "Драконий погост"
psulyoggparty1				= "группа 1"
psulyoggparty2				= "группа 2"
psulyoggparty3				= "группа 3"
psulyoggparty4				= "группа 4"
psulyoggparty5				= "группа 5"
psulyoggempty				= "пусто"



end

function pslocaleuldalevi()
psullevitxt1				= "1 группа - Водят осадные машины."
psullevitxt2				= "2 группа - Водят разрушители"
psullevitxt3				= "3 группа - Водят мотоциклы"
psullevitxt4				= "4 группа - Десант."
psullevitxt5				= "5 группа - Пассажиры осадных машин."
psullevitxt6				= "Высадка #1"
psullevitxt7				= "Высадка #2"
psullevitxt8				= "сейчас в ковш"
pslevirol1				= "вы водите осадную машину, тараните цветы и по возможности сбиваете каст боссу (если РЛ не скажет другой приоритет)"
pslevirol2				= "вы водите разрушитель без марки, у вас будет 1 пассажир (не десантник)."
pslevirol3				= "вы пассажир осадной машины, ваша цель: убивать растения, сбивать пирит."
pslevirol4				= "вы водите разрушитель с маркой"
pslevirol5				= "бросаете десант, держите стак пирита на боссе."
pslevirol6				= "Вы пассажир разрушителя, на которой нет марки, собираете пирит, сбиваете его и помогаете с убийством цветов."
pslevirol7				= "Вы водите мотоцикл и возите десант с маркой"
pslevirol8				= "на разрушитель"
pslevirol9				= "вы десантник с 1 высадки, садитесь в разрушитель с маркой"
pslevirol10				= "вы десантник с 2 высадки, садитесь в разрушитель с маркой"
pslevirol11				= "(сразу в ковш), вас будет возить"
pslevirol12				= "(пока НЕ в ковш), вас будет возить"
pslevirol13				= "на мотоцикле."
pslevidesgogo				= "ВПЕРЕД!"
pslevitimetodie				= "Время вашей высадки! В ковш!"


end

end