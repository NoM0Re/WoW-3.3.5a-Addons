﻿if GetLocale() == "koKR" then

function pslocaleuldaboss()


psulgeneralvezax			= "장군 베작스"
psulsaronite				= "사로나이트 원혼"
psulleviafanchik			= "거대 화염전차"
psulalgalon				= "관찰자 알갈론"
psyoggfail1				= "Brain of Yogg-Saron"
psyoggfail2				= "요그사론"
psyoggfail3				= "Sara"
psyoggfail4				= "Guardian of Yogg-Saron"
psultorim				= "토림"

end



end