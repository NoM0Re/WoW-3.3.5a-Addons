﻿function psfalgalon()

psunitisplayer(arg6,arg7)
if psunitplayertrue then

psfwipecheck()
if(psnumdead>3) then
else
wasornoalg=1

addtotwotables(arg7)
vezaxsort1()


if(bosspartul[5]==1 and bosspartul2[3]==1)then
pszapuskanonsa(whererepbossulda[5], "{rt7} "..algalonname.." "..psulalgalon1)
end
end end
end

function psfalgreport()

if(thisaddononoff and bosspartul[5]==1)then
strochkavezcrash="{rt7}"..psulalgalon3
reportafterboitwotab(whererepbossulda[5], true, vezaxname, vezaxcrash)
end

end

function psfalgrezetall()
wasornoalg=0
timetocheck=0
alginterr=0
table.wipe(vezaxname)
table.wipe(vezaxcrash)
end