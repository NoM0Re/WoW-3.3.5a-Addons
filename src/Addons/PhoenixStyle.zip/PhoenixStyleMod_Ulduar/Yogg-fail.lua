﻿function psfxtnoob()
psunitisplayer(arg6,arg7)
if psunitplayertrue then
wasornoxt=1
addtotwotables(arg7)
vezaxsort1()
end
end

function psfxtnoob2()
psunitisplayer(arg6,arg7)
if psunitplayertrue then
wasornoxt=1
addtotwotables2(arg7)
vezaxsort2()
end
end

function psfxtnoob3()
psunitisplayer(arg6,arg7)
if psunitplayertrue then
wasornoxt=1
addtotwotables3(arg7)
vezaxsort3()
end
end

function psfxtafterf()
if(thisaddononoff and bosspartul[6]==1)then
strochkavezcrash="{rt7}"..psulxttext1
reportafterboitwotab(whererepbossulda[6], true, vezaxname, vezaxcrash, 1, 10)
strochkavezcrash="{rt1}"..psulxttext2
reportafterboitwotab(whererepbossulda[6], true, vezaxname2, vezaxcrash2, 1, 10)
strochkavezcrash="{rt8}"..psulxttext3
reportafterboitwotab(whererepbossulda[6], true, vezaxname3, vezaxcrash3, 1, 10)
end

end


function psfxtresetall()
wasornoxt=0
timetocheck=0
xtboyinterr=0
table.wipe(vezaxname)
table.wipe(vezaxcrash)
table.wipe(vezaxname2)
table.wipe(vezaxcrash2)
table.wipe(vezaxname3)
table.wipe(vezaxcrash3)
end