﻿function psfhodirnoob()
if arg2 == "SPELL_AURA_APPLIED" then

psunitisplayer(arg6,arg7)
if psunitplayertrue then

psfwipecheck()
if(psnumdead>1) then
else
if(bosspartul[4])then
SetRaidTarget(arg7, 7)
pszapuskanonsa(whererepbossulda[4], "{rt7} "..arg7.." - "..psulhodir1)
end
end
end
end
if arg2 == "SPELL_AURA_REMOVED" then
SetRaidTarget(arg7, 0)
end end