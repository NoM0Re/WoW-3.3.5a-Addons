﻿if GetLocale() == "koKR" then

function pslocaleicecrownboss()

psicclordm				= "군주 매로우가르"
psiccdeathwhisper			= "여교주 데스위스퍼"
psiccsaurfang				= "죽음의 인도자 사울팽"
psiccsaurfadd				= "피의 괴물"
psiccfestergut				= "구린속"
psiccrotface				= "썩은얼굴"
psiccputricide				= "교수 퓨트리사이드"
psiccputricidepully			= "좋은 소식이에요, 여러분! 아제로스의 모든 생명체를 파괴할 역병을 완성했어요!"
psiccputricideadd1			= "일촉즉발 수액괴물"
psiccputricideadd2			= "가스 구름"
psiccbloodqueenlana			= "피의 여왕 라나텔"
psiccprofadd				= "Mutated Abomination"
psiccprincename				= "공작 탈다람"
psiccvalithria				= "발리스리아 드림워커"
psiccsindragosa				= "신드라고사"
psicclichking				= "리치 왕"
psiccsindraadd				= "얼음 무덤"
psiccvalitriapull			= "침입자들이 내부 성소로 들어왔다. 서둘러 녹색용을 파멸시켜라! 되살려 낼 때 쓸 뼈와 힘줄만 남겨라!"
psiccprincename2			= "공작 발라나르"
psiccprincename3			= "공작 켈레세스"

end

function pslocaleicecrownui()

end

end