﻿if GetLocale() == "esMX" then

function pslocaleicecrownboss()

psicclordm				= "Lord Tuétano"
psiccdeathwhisper			= "Lady Susurramuerte"
psiccsaurfang				= "Libramorte Colmillosauro"
psiccsaurfadd				= "Bestia de sangre"
psiccfestergut				= "Panzachancro"
psiccrotface				= "Carapútrea"
psiccputricide				= "Profesor Putricidio"
psiccputricidepully			= "¡Buenas noticias, amigos! Creo que he perfeccionado una plaga que destruirá toda la vida en Azeroth."
psiccputricideadd1			= "Moco volátil"
psiccputricideadd2			= "Nube de gas"
psiccbloodqueenlana			= "Reina de Sangre Lana'thel"
psiccprofadd				= "Abominación mutada"
psiccprincename				= "Príncipe Taldaram"
psiccvalithria				= "Valithria Caminasueños"
psiccsindragosa				= "Sindragosa"
psicclichking				= "El Rey Exánime"
psiccsindraadd				= "Tumba de hielo"
psiccvalitriapull			= "Han entrado intrusos en el Sagrario Interior. Apresuraos en acabar con el dragón verde. ¡Dejad solo huesos y tendones para la reanimación!"
psiccprincename2			= "Príncipe Valanar"
psiccprincename3			= "Príncipe Keleseth"

end

function pslocaleicecrownui()

end

end