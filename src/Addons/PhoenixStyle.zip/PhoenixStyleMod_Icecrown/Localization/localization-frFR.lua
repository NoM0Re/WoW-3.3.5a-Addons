﻿if GetLocale() == "frFR" then

function pslocaleicecrownboss()

psicclordm				= "Seigneur Gargamoelle"
psiccdeathwhisper			= "Dame Murmemort"
psiccsaurfang				= "Porte-mort Saurcroc"
psiccsaurfadd				= "Bête de sang"
psiccfestergut				= "Pulentraille"
psiccrotface				= "Trognepus"
psiccputricide				= "Professeur Putricide"
psiccputricidepully			= "mis au point une peste qui va"
psiccputricideadd1			= "Limon volatil"
psiccputricideadd2			= "Nuage de gaz"
psiccbloodqueenlana			= "Reine de sang Lana'thel"
psiccprofadd				= "Abomination mutée"
psiccprincename				= "Prince Taldaram"
psiccvalithria				= "Valithria Marcherêve"
psiccsindragosa				= "Sindragosa"
psicclichking				= "Le Roi Liche"
psiccsindraadd				= "Tombeau de glace"
psiccvalitriapull			= "Ne gardez que les os et les tendons"
psiccprincename2			= "Prince Valanar"
psiccprincename3			= "Prince Keleseth"

end

function pslocaleicecrownui()

end

end