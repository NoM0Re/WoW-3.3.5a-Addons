﻿if GetLocale() == "frFR" then

function pslocalecoliseumboss()

pscotwinsvalkyr				= "Fjola Plaie-lumineuse"
pscotwinsvalkyr2			= "Eydis Plaie-sombre"
pscojaraboss				= "Seigneur Jaraxxus"

end



end