﻿


function pslocalecoliseumboss()

pscotwinsvalkyr				= "Fjola Lightbane"
pscotwinsvalkyr2			= "Eydis Darkbane"
pscojaraboss				= "Lord Jaraxxus"


end


function pslocalecoliseum()

pscotwinsinfo				= "Got spheres of opposite color: "
pscotwinsinfo2				= "Got spheres of right color: "
psulzveri1				= "didn't run away from Icehowl's charge!"
pscoltwinshield1			= "interrupted cast in"
pscoltwinshield2			= "sec before it ends"
pscoltwinshield3			= "Boss healed, on shield remains"
pscoltwinshield4			= "HP."
pscoltwinshield5			= "Damage to another boss, no dots and aoe (damage - count): "
pscolshield				= "HP info"
pscolkick				= "kick!"
pscolnick				= "Nick"
pscoljaraloc1				= "Incinerate Flesh on"
pscoljaraloc2				= "Incinerate Flesh"
pscoljaraloc3				= "Incinerate Fleshs were healed by"
pscolwasnthealed			= "was NOT healed"
pscolhealili				= "Healed by"
pscolhealili2				= "was healed by"
pscolvalselectpl			= "select player"
pscolvalnxtabloc1			= "Next ability is"
pscolvalnxtabloc2			= "Shield of Darkness"
pscolvalnxtabloc3			= "Shield of Lights"
pscolvalbeprepare			= "Be prepare to attack"
pscolvalchntxt1				= "Damage in shield and time lost to change target (considering debuff color OFF): "
pscolvalchntxt2				= "Damage in shield and time lost to change target considering debuff: "
pscolnewveranoncet			= {"|cff00ff00Twin Val'kyr|r > if you install latest version of |cff00ff00TwinValkyr_shieldmonitor|r addon - you will target boss when click to 'HP-shield' frame!", "|cff00ff00Anub'arak|r > module added to save marks assignments for healers.", "|cff00ff00Twin Val'kyr|r > shows time taken to switch target, if raiders have to switch essence before changing target - |cff00ff00set this in options to control their debuff color!|r"}
pscoljaraloc44				= "Infernal's AoE attacks: "

end



function pslocalecoliseumui()

pscoliseum1				= "    Coliseum"
pscoliboss1				= "Twin Val'kyr"
pscoliboss2				= "Icehowl"
pscoliboss3				= "Lord Jaraxxus"
pscoliinfoboss1				= "- show shieldmonitor frame, and report to chat, also report who got spheres."
pscoliinfoboss2				= "- show who didn't run away from Icehowl's charge."
pscoliinfoboss3				= "- show who healed Incinerate Flesh + heal-needed monitor frame."
psulonlyattheendsharof			= "- don't report spheres info."
psulonlyattheendval2			= "- report info about damage into shield in chat."
psulrepjara				= "- report if was Burning Inferno."
pscolvalsmena				= "- consider target change only after color change."
pscolishildoptbut			= "shield options"
pstwbetween				= "between"
pstwand					= "and"
pstwmenu				= "    Shieldsmonitor options"
pstwchosew				= "set frame width:"
pstwchoseh				= "set frame height:"
pstwgalka1				= "show cast text info"
pstwgalka2				= "show shield text info"
pstwgalka3				= "show nick"
pstwapply				= "Apply"
pstwdefau				= "by default"
pscolishildinfobut			= "shields info"
pscolframevalinfo			= "    Twin Val'kyr shields info"
pscolfrmavalloc1			= "Information about damage to Valkyr's shields will be here."
pscolfrmavelloc2			= "- chat channel"
pscolvalinfloc1				= "Info - shield"
pscolvalinfloc2				= "Kicked in"
pscolvalinfloc3				= "sec. before it ends"
pscolvalinfloc4				= "Shield"
pscolvalinfloc5				= "was NOT kicked"
pscolvalinfloc6				= "Damage to another boss"
pscolanubtit				= "    Anub'arak, marks assignments"
pscolanubtit2				= "This module doesn't mark Penetration Cold, it only save marks assignments. To mark players use 'DBM', 'Penetrator' or other similar addon. It's not suggested to have 2 different addons in a raid, can cause disappearing of marks."
pscolanubmarkthem			= "Mark them"
pscolanubbut				= "Anub'arak"
pscoltwinvaladd				= "If you want to take boss in target after clicking 'HP-shield' frame - install latest version of |cff00ff00TwinValkyr_shieldmonitor|r addon."
pscolkiteanub				= "Kite phase:"

end


