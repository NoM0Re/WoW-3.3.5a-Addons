﻿if GetLocale() == "koKR" then

function pslocalecoliseumboss()

pscotwinsvalkyr				= "피욜라 라이트베인"
pscotwinsvalkyr2			= "아이디스 다크베인"
pscojaraboss				= "군주 자락서스"

end



end