﻿if GetLocale() == "zhTW" then

function pslocalecoliseumboss()

pscotwinsvalkyr				= "菲歐拉·光寂"
pscotwinsvalkyr2			= "艾狄絲·暗寂"
pscojaraboss				= "賈拉克瑟斯領主"

end



end