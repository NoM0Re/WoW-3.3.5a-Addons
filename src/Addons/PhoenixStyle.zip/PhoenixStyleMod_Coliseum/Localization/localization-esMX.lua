﻿if GetLocale() == "esMX" then

function pslocalecoliseumboss()

pscotwinsvalkyr				= "Fjola Penívea"
pscotwinsvalkyr2			= "Eydis Penaumbra"
pscojaraboss				= "Lord Jaraxxus"

end



end