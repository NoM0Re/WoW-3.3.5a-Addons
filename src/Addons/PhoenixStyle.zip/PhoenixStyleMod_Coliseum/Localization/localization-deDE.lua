﻿if GetLocale() == "deDE" then
--translated: EaDx

function pslocalecoliseumboss()

pscotwinsvalkyr				= "Fjola Lichtbann"
pscotwinsvalkyr2			= "Eydis Nachtbann"
pscojaraboss				= "Lord Jaraxxus"


end


function pslocalecoliseum()

pscotwinsinfo				= "Falsche Kugeln eingesammelt: "
pscotwinsinfo2				= "Richtige Kugeln eingesammelt: "
psulzveri1				= "ist nicht Eisheulers Ansturm ausgewichen!"
pscoltwinshield1			= "hat unterbrochen in"
pscoltwinshield2			= "Sek. vor Ende"
pscoltwinshield3			= "Zwilling wurde geheilt, Schild hatte noch"
pscoltwinshield4			= "HP."
pscoltwinshield5			= "Schaden auf anderen Zwilling: "
pscolshield				= "HP Info"
pscolkick				= "kick!"
pscolnick				= "Nick"
pscoljaraloc1				= "Fleisch ein\195\164schern auf"
pscoljaraloc2				= "Fleisch ein\195\164schern"
pscoljaraloc3				= "Fleisch ein\195\164schern wurde geheilt von"
pscolwasnthealed			= "wurde NICHT geheilt"
pscolhealili				= "Geheilt von"
pscolhealili2				= "wurde geheilt von"
pscolvalselectpl			= "Spieler ausw\195\164hlen"
pscolvalnxtabloc1			= "N\195\164chste F\195\164higkeit ist"
pscolvalnxtabloc2			= "Schild der Dunkelheit"
pscolvalnxtabloc3			= "Schild des Lichts"
pscolvalbeprepare			= "Bereitet euch vor"
pscolvalchntxt1				= "Schaden auf Schild und bis zum Wechsel vergangene Zeit (Debuff AUS): "
pscolvalchntxt2				= "Schaden auf Schild und bis zum Wechsel vergangene Zeit (Debuff AN): "
pscolnewveranoncet			= {"|cff00ff00Zwillingsval'kyr|r > wenn Sie die aktuelle Version vom AddOn |cff00ff00TwinValkyr_shieldmonitor|r haben, dann wird nach dem Klicken auf den Rahmen 'HP-Schild' - der Boss ausgew\195\164hlt.", "|cff00ff00Anub'arak|r > Das Modul f\195\188r das Speichern der Heilernamen und der Markierungen wurde hinzugef\195\188gt.", "|cff00ff00Zwillingsval'kyr|r > zeigt Zeit bis zum Wechsel an, wenn die Raider die Farbe wechseln m\195\188ssen - |cff00ff00setze diese Option ein!|r"}
pscoljaraloc44				= "Brennendes Inferno AoE: "

end



function pslocalecoliseumui()

pscoliseum1				= "    Kolloseum"
pscoliboss1				= "Zwillingsval'kyr"
pscoliboss2				= "Eisheuler"
pscoliboss3				= "Lord Jaraxxus"
pscoliinfoboss1				= "- zeigt Schildmonitor und gibt es im Raid aus. Gibt auch die Kugelinfo an."
pscoliinfoboss2				= "- zeigt, wer nicht Eisheulers Ansturm ausgewichen ist."
pscoliinfoboss3				= "- zeigt an, wer Fleisch ein\195\164schern geheilt hat und den Monitor-Frame dazu."
psulonlyattheendsharof			= "- zeige Kugelinfo nicht an."
psulonlyattheendval2			= "- Schaden auf Schild im Chat ausgeben."
psulrepjara				= "- zeige Brennendes Inferno."
pscolvalsmena				= "- beachte Zielwechsel nur NACH dem Farbwechsel."
pscolishildoptbut			= "Schild optionen"
pstwbetween				= "zwischen"
pstwand					= "und"
pstwmenu				= "    Schildmonitor Optionen"
pstwchosew				= "Breite:"
pstwchoseh				= "H\195\182he:"
pstwgalka1				= "Zeige Zauber"
pstwgalka2				= "Zeige Schild"
pstwgalka3				= "Zeige Name"
pstwapply				= "Okay"
pstwdefau				= "Standard"
pscolishildinfobut			= "Schild Info"
pscolframevalinfo			= "    Zwillingsval'kyr Schild Info"
pscolfrmavalloc1			= "Information zu den Zwillingsval'kyr Schilden."
pscolfrmavelloc2			= "- Chat Channel"
pscolvalinfloc1				= "Info - Schild"
pscolvalinfloc2				= "Unterbrochen in"
pscolvalinfloc3				= "Sek. vor Ende"
pscolvalinfloc4				= "Schild"
pscolvalinfloc5				= "wurde NICHT unterbrochen"
pscolvalinfloc6				= "Schaden auf anderen Zwilling"
pscolanubtit				= "    Anub'arak, Markenverteilung f\195\188r die Heiler"
pscolanubtit2				= "Dieses Modul zeichnet selbst nicht die Heiler mit einer Schlachtzugsmarke aus, es merkt nur die Namen von den Heilern. Benutzen Sie solche Add-ons wie 'DBM', 'Penetrator' oder ein funktions\195\164hnliches AddOn, um die Schlachtzugsmarken zu setzen. Es wird dringend empfohlen nicht verschiedene AddOns in einem Schlachtzug zu benutzen, da dadurch die Schlachtzugsmarken ausgeschaltet werden k\195\182nnen."
pscolanubmarkthem			= "markieren"
pscolanubbut				= "Anub'arak"
pscoltwinvaladd				= "Wenn Sie m\195\182chten, dass bei dem Klicken auf den Rahmen der Boss als Ziel ausgew\195\164hlt wird, dann sollten Sie das AddOn |cff00ff00TwinValkyr_shieldmonitor|r herunterladen."
pscolkiteanub				= "Kite Phase:"

end


end