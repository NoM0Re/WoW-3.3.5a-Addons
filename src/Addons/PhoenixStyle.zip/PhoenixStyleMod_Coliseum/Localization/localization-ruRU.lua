﻿if GetLocale() == "ruRU" then


function pslocalecoliseumboss()

pscotwinsvalkyr				= "Фьола Погибель Света"
pscotwinsvalkyr2			= "Эйдис Погибель Тьмы"
pscojaraboss				= "Лорд Джараксус"


end


function pslocalecoliseum()

pscotwinsinfo				= "Не свои шарики получили: "
pscotwinsinfo2				= "СВОИ шарики получили: "
psulzveri1				= "размазан по стенке Ледяным ревом!"
pscoltwinshield1			= "прервал каст хила за"
pscoltwinshield2			= "сек. до его завершения"
pscoltwinshield3			= "Хил прошел, на щите оставалось"
pscoltwinshield4			= "ХП."
pscoltwinshield5			= "Урон по другому боссу, без дот и аое (урон - кол-во атак): "
pscolshield				= "ХП инфо"
pscolkick				= "кик!"
pscolnick				= "Имя"
pscoljaraloc1				= "Испепеление плоти на"
pscoljaraloc2				= "Испепеление"
pscoljaraloc3				= "Испепеления лечили"
pscolwasnthealed			= "НЕ было отлечено"
pscolhealili				= "Лечили"
pscolhealili2				= "лечили"
pscolvalselectpl			= "выбрать игрока"
pscolvalnxtabloc1			= "След. способность"
pscolvalnxtabloc2			= "Тёмный щит"
pscolvalnxtabloc3			= "Светлый щит"
pscolvalbeprepare			= "Будьте готовы бить"
pscolvalchntxt1				= "Урон в щит и время смены цели (проверка дебафа откл): "
pscolvalchntxt2				= "Урон в щит и время на смену цели, с проверкой дебафа: "
pscolnewveranoncet			= {"|cff00ff00Валькирии|r > если Вы установите посл. версию аддона |cff00ff00TwinValkyr_shieldmonitor|r, то при нажатии на фрейм 'ХП щита' - босс будет браться в цель.", "|cff00ff00Ануб'арак|r > добавлен модуль для сохранения ников хилеров и их марок.", "|cff00ff00Валькирии|r > отображение затраченого времени на смену цели, если со сменой цели должен меняться и цвет - установите галочку в |cff00ff00настройках|r на проверку его смены."}
pscoljaraloc44				= "АоЕ инферналов задело: "

end



function pslocalecoliseumui()

pscoliseum1				= "    Колизей"
pscoliboss1				= "Валь'кир-близнецы"
pscoliboss2				= "Ледяной Рев"
pscoliboss3				= "Лорд Джараксус"
pscoliinfoboss1				= "- отображает мониторинг щита + сообщает в чат + сообщает кто ел шарики."
pscoliinfoboss2				= "- показывает кого Ледяной рев размазывает по стенке."
pscoliinfoboss3				= "- показывает кто лечит Испепеление плоти + мониторинг необходимого лечения."
psulonlyattheendsharof			= "- не показывать в чат инфо о полученных шариках."
psulonlyattheendval2			= "- сообщать в чат информацию об уроне в щит."
psulrepjara				= "- только неотлеч. Испепеление."
pscolvalsmena				= "- засчитывать смену цели только после смены цвета."
pscolishildoptbut			= "настройки щита"
pstwbetween				= "между"
pstwand					= "и"
pstwmenu				= "    Мониторинг щитов - настройки"
pstwchosew				= "изменить ширину:"
pstwchoseh				= "изменить высоту:"
pstwgalka1				= "цифры времени каста"
pstwgalka2				= "цифры урона/хила в щит"
pstwgalka3				= "отображение ника"
pstwapply				= "Применить"
pstwdefau				= "по умолчанию"
pscolishildinfobut			= "инфо по щитам"
pscolframevalinfo			= "    Twin Val'kyr информация о щитах"
pscolfrmavalloc1			= "Тут будет отображаться информация об уроне в щиты Валькирий."
pscolfrmavelloc2			= "- канал чата"
pscolvalinfloc1				= "Инфо по щиту"
pscolvalinfloc2				= "Сбит за"
pscolvalinfloc3				= "сек. до конца"
pscolvalinfloc4				= "Щит"
pscolvalinfloc5				= "НЕ сбит"
pscolvalinfloc6				= "Урон НЕ в щит"
pscolanubtit				= "    Ануб'арак, раздача меток хилерам"
pscolanubtit2				= "Этот модуль не вешает метки, а только запоминает ники хилеров. Чтобы вешать метки используйте 'DBM', 'Penetrator' или аналогичный аддон. Крайне не рекомендуется использовать разные аддоны, это может вызвать пропадание меток."
pscolanubmarkthem			= "Пометить"
pscolanubbut				= "Ануб'арак"
pscoltwinvaladd				= "Если Вы хотите чтобы при нажатии на фрейм 'ХП-щит' босс автоматически брался в цель - установите посл. версию аддона |cff00ff00TwinValkyr_shieldmonitor|r."
pscolkiteanub				= "Кайт-фаза:"

end


end