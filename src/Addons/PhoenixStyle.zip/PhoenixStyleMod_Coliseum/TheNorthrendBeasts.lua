﻿function zverinoobreport()
if(zveripart) then
pszapuskanonsa(wherereportzveri, "{rt8} "..arg7.." - "..psulzveri1)
end
end